package org.BABO.server.controller;

import org.BABO.shared.model.Book;
import org.BABO.server.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller REST per gestire le operazioni sui libri
 */
@RestController
@RequestMapping("/api/books")
@CrossOrigin(origins = "*")
public class BookController {

    @Autowired
    private BookService bookService;

    /**
     * Recupera tutti i libri
     * GET /api/books
     */
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        try {
            List<Book> books = bookService.getAllBooks();
            System.out.println("📚 Ritornati " + books.size() + " libri");
            return ResponseEntity.ok(books);
        } catch (Exception e) {
            System.err.println("❌ Errore nel recupero di tutti i libri: " + e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Recupera un libro specifico per ID
     * GET /api/books/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        try {
            Book book = bookService.getBookById(id);
            if (book != null) {
                System.out.println("📖 Ritornato libro: " + book.getTitle());
                return ResponseEntity.ok(book);
            } else {
                System.out.println("⚠️ Libro non trovato con ID: " + id);
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            System.err.println("❌ Errore nel recupero del libro " + id + ": " + e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Recupera libri in evidenza
     * GET /api/books/featured
     */
    @GetMapping("/featured")
    public ResponseEntity<List<Book>> getFeaturedBooks() {
        try {
            List<Book> books = bookService.getFeaturedBooks();
            System.out.println("⭐ Ritornati " + books.size() + " libri in evidenza");
            return ResponseEntity.ok(books);
        } catch (Exception e) {
            System.err.println("❌ Errore nel recupero dei libri in evidenza: " + e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Ricerca libri per titolo o autore
     * GET /api/books/search?q={query}
     */
    @GetMapping("/search")
    public ResponseEntity<List<Book>> searchBooks(@RequestParam String q) {
        try {
            if (q == null || q.trim().isEmpty()) {
                return ResponseEntity.badRequest().build();
            }

            List<Book> books = bookService.searchBooks(q);
            System.out.println("🔍 Ricerca '" + q + "': trovati " + books.size() + " risultati");
            return ResponseEntity.ok(books);
        } catch (Exception e) {
            System.err.println("❌ Errore nella ricerca '" + q + "': " + e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Recupera libri gratuiti
     * GET /api/books/free
     */
    @GetMapping("/free")
    public ResponseEntity<List<Book>> getFreeBooks() {
        try {
            List<Book> books = bookService.getFreeBooks();
            System.out.println("💰 Ritornati " + books.size() + " libri gratuiti");
            return ResponseEntity.ok(books);
        } catch (Exception e) {
            System.err.println("❌ Errore nel recupero dei libri gratuiti: " + e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Recupera nuove uscite
     * GET /api/books/new-releases
     */
    @GetMapping("/new-releases")
    public ResponseEntity<List<Book>> getNewReleases() {
        try {
            List<Book> books = bookService.getNewReleases();
            System.out.println("✨ Ritornati " + books.size() + " nuove uscite");
            return ResponseEntity.ok(books);
        } catch (Exception e) {
            System.err.println("❌ Errore nel recupero delle nuove uscite: " + e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Endpoint di test per verificare che il server funzioni
     * GET /api/books/health
     */
    @GetMapping("/health")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("✅ Book Service is running!");
    }
}