package org.BABO.server.service;

import org.BABO.shared.model.Book;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Servizio per gestire le operazioni sui libri
 * Connessione al database PostgreSQL con ricerca separata per titolo e autore
 */
@Service
public class BookService {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/DataProva";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "postgress";

    /**
     * Recupera tutti i libri dal database
     */
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        String query = "SELECT isbn, book_author, description, publi_year FROM books ORDER BY isbn";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            System.out.println("📊 Connessione al database riuscita");

            while (rs.next()) {
                String title = rs.getString("isbn");
                String author = rs.getString("book_author");
                String description = rs.getString("description");
                String year = rs.getString("publi_year"); // Aggiungi il campo anno
                String fileName = title.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";

                // Crea ID sequenziale per compatibilità
                Long id = (long) (books.size() + 1);

                // Crea Book con anno (dovrai aggiornare il model Book se necessario)
                Book book = new Book(id, title, author, description, fileName);
                // TODO: Aggiungi campo year al model Book se non esiste
                books.add(book);

                System.out.println("📖 Caricato: " + title + " di " + author + " (" + year + ")");
            }

            System.out.println("✅ Caricati " + books.size() + " libri dal database");

        } catch (SQLException e) {
            System.err.println("❌ Errore durante il recupero dei libri dal database: " + e.getMessage());
            e.printStackTrace();

            // Aggiungi libri di fallback se il database non è disponibile
            System.out.println("📚 Uso libri di fallback...");
            addFallbackBooks(books);
        }

        return books;
    }

    /**
     * Recupera un libro specifico per ID
     */
    public Book getBookById(Long id) {
        // Per semplicità, recuperiamo tutti i libri e filtriamo per ID
        List<Book> allBooks = getAllBooks();

        return allBooks.stream()
                .filter(book -> book.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    /**
     * Ricerca libri generica (per titolo o autore insieme)
     */
    public List<Book> searchBooks(String searchQuery) {
        System.out.println("🔍 Ricerca generica per: '" + searchQuery + "'");

        List<Book> books = new ArrayList<>();
        String query = "SELECT isbn, book_author, description, publi_year FROM books " +
                "WHERE LOWER(isbn) LIKE LOWER(?) OR LOWER(book_author) LIKE LOWER(?) " +
                "ORDER BY isbn";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            String searchPattern = "%" + searchQuery + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String title = rs.getString("isbn");
                String author = rs.getString("book_author");
                String description = rs.getString("description");
                String year = rs.getString("publi_year");
                String fileName = title.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";

                Long id = (long) (books.size() + 1);
                books.add(new Book(id, title, author, description, fileName));
            }

            System.out.println("🔍 Ricerca generica '" + searchQuery + "': trovati " + books.size() + " risultati nel database");

        } catch (SQLException e) {
            System.err.println("❌ Errore durante la ricerca nel database: " + e.getMessage());
            books = searchInFallbackBooks(searchQuery);
        }

        return books;
    }

    /**
     * Ricerca libri SOLO per titolo
     */
    public List<Book> searchBooksByTitle(String titleQuery) {
        System.out.println("📖 Ricerca per TITOLO: '" + titleQuery + "'");

        List<Book> books = new ArrayList<>();
        String query = "SELECT isbn, books_title, book_author, description, publi_year FROM books " +
                "WHERE LOWER(books_title) LIKE LOWER(?) " +
                "ORDER BY books_title";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            String searchPattern = "%" + titleQuery + "%";
            stmt.setString(1, searchPattern);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String title = rs.getString("isbn");
                String author = rs.getString("book_author");
                String description = rs.getString("description");
                String year = rs.getString("publi_year");
                String fileName = title.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";

                Long id = (long) (books.size() + 1);
                books.add(new Book(id, title, author, description, fileName));

                System.out.println("📖 Trovato titolo: " + title + " (" + year + ")");
            }

            System.out.println("📖 Ricerca titolo '" + titleQuery + "': trovati " + books.size() + " risultati");

        } catch (SQLException e) {
            System.err.println("❌ Errore durante la ricerca per titolo: " + e.getMessage());
            books = searchInFallbackBooksByTitle(titleQuery);
        }

        return books;
    }

    /**
     * Ricerca libri SOLO per autore
     */
    public List<Book> searchBooksByAuthor(String authorQuery) {
        System.out.println("👤 Ricerca per AUTORE: '" + authorQuery + "'");

        List<Book> books = new ArrayList<>();
        String query = "SELECT isbn, book_author, description, publi_year FROM books " +
                "WHERE LOWER(book_author) LIKE LOWER(?) " +
                "ORDER BY isbn";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            String searchPattern = "%" + authorQuery + "%";
            stmt.setString(1, searchPattern);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String title = rs.getString("isbn");
                String author = rs.getString("book_author");
                String description = rs.getString("description");
                String year = rs.getString("publi_year");
                String fileName = title.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";

                Long id = (long) (books.size() + 1);
                books.add(new Book(id, title, author, description, fileName));

                System.out.println("👤 Trovato autore: " + author + " - " + title + " (" + year + ")");
            }

            System.out.println("👤 Ricerca autore '" + authorQuery + "': trovati " + books.size() + " risultati");

        } catch (SQLException e) {
            System.err.println("❌ Errore durante la ricerca per autore: " + e.getMessage());
            books = searchInFallbackBooksByAuthor(authorQuery);
        }

        return books;
    }

    /**
     * Ricerca libri per autore e anno (ORA FUNZIONA DAVVERO!)
     * Parametri SEPARATI: prima filtra per autore, poi per anno se specificato
     */
    public List<Book> searchBooksByAuthorAndYear(String authorQuery, String year) {
        System.out.println("👤📅 Ricerca per AUTORE e ANNO: '" + authorQuery + "' (" + year + ")");

        List<Book> books = new ArrayList<>();
        String query;

        // Costruisci query in base ai parametri
        if (year != null && !year.trim().isEmpty()) {
            // RICERCA CON ENTRAMBI: autore E anno
            query = "SELECT isbn, book_author, description, publi_year FROM books " +
                    "WHERE LOWER(book_author) LIKE LOWER(?) AND CAST(publi_year AS TEXT) = ? " +
                    "ORDER BY isbn";
            System.out.println("📊 Query con FILTRO ANNO: " + query);
        } else {
            // RICERCA SOLO PER AUTORE
            query = "SELECT isbn, book_author, description, publi_year FROM books " +
                    "WHERE LOWER(book_author) LIKE LOWER(?) " +
                    "ORDER BY isbn";
            System.out.println("📊 Query SOLO AUTORE: " + query);
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            // Parametro 1: pattern autore
            String searchPattern = "%" + authorQuery + "%";
            stmt.setString(1, searchPattern);
            System.out.println("📝 Parametro 1 (autore): " + searchPattern);

            // Parametro 2: anno (se specificato)
            if (year != null && !year.trim().isEmpty()) {
                stmt.setString(2, year.trim());
                System.out.println("📝 Parametro 2 (anno): " + year.trim());
            }

            ResultSet rs = stmt.executeQuery();
            int count = 0;

            while (rs.next()) {
                String title = rs.getString("isbn");
                String author = rs.getString("book_author");
                String description = rs.getString("description");
                String dbYear = rs.getString("publi_year");
                String fileName = title.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";

                Long id = (long) (books.size() + 1);
                books.add(new Book(id, title, author, description, fileName));

                count++;
                if (count <= 3) { // Log primi 3 risultati
                    System.out.println("👤📅 Risultato " + count + ": " + author + " - " + title + " (" + dbYear + ")");
                }
            }

            System.out.println("👤📅 Ricerca autore-anno COMPLETATA: trovati " + books.size() + " risultati totali");

        } catch (SQLException e) {
            System.err.println("❌ Errore SQL durante la ricerca per autore e anno: " + e.getMessage());
            e.printStackTrace();

            // Fallback: cerca solo per autore se c'è errore con l'anno
            System.out.println("🔄 Fallback: ricerca solo per autore");
            books = searchBooksByAuthor(authorQuery);
        }

        return books;
    }

    /**
     * Ricerca nei libri di fallback (quando database non disponibile)
     */
    private List<Book> searchInFallbackBooks(String searchQuery) {
        List<Book> fallbackBooks = new ArrayList<>();
        addFallbackBooks(fallbackBooks);

        List<Book> results = new ArrayList<>();
        for (Book book : fallbackBooks) {
            if (book.getTitle().toLowerCase().contains(searchQuery.toLowerCase()) ||
                    book.getAuthor().toLowerCase().contains(searchQuery.toLowerCase())) {
                results.add(book);
            }
        }

        System.out.println("🔍 Ricerca fallback '" + searchQuery + "': trovati " + results.size() + " risultati");
        return results;
    }

    /**
     * Ricerca per titolo nei libri di fallback
     */
    private List<Book> searchInFallbackBooksByTitle(String titleQuery) {
        List<Book> fallbackBooks = new ArrayList<>();
        addFallbackBooks(fallbackBooks);

        List<Book> results = new ArrayList<>();
        for (Book book : fallbackBooks) {
            if (book.getTitle().toLowerCase().contains(titleQuery.toLowerCase())) {
                results.add(book);
            }
        }

        System.out.println("📖 Ricerca titolo fallback '" + titleQuery + "': trovati " + results.size() + " risultati");
        return results;
    }

    /**
     * Ricerca per autore nei libri di fallback
     */
    private List<Book> searchInFallbackBooksByAuthor(String authorQuery) {
        List<Book> fallbackBooks = new ArrayList<>();
        addFallbackBooks(fallbackBooks);

        List<Book> results = new ArrayList<>();
        for (Book book : fallbackBooks) {
            if (book.getAuthor().toLowerCase().contains(authorQuery.toLowerCase())) {
                results.add(book);
            }
        }

        System.out.println("👤 Ricerca autore fallback '" + authorQuery + "': trovati " + results.size() + " risultati");
        return results;
    }

    /**
     * Recupera libri in evidenza (primi 3)
     */
    public List<Book> getFeaturedBooks() {
        List<Book> allBooks = getAllBooks();
        int endIndex = Math.min(3, allBooks.size());
        return allBooks.subList(0, endIndex);
    }

    /**
     * Recupera libri gratuiti (primi 8)
     */
    public List<Book> getFreeBooks() {
        List<Book> allBooks = getAllBooks();
        int endIndex = Math.min(8, allBooks.size());
        return allBooks.subList(0, endIndex);
    }

    /**
     * Recupera nuove uscite (ultimi libri disponibili)
     */
    public List<Book> getNewReleases() {
        List<Book> allBooks = getAllBooks();
        if (allBooks.size() <= 8) {
            return allBooks;
        }

        // Prendi gli ultimi libri come "nuove uscite"
        int startIndex = Math.max(0, allBooks.size() - 8);
        return allBooks.subList(startIndex, allBooks.size());
    }

    /**
     * Aggiunge libri di fallback quando il database non è disponibile
     */
    private void addFallbackBooks(List<Book> books) {
        books.add(new Book(1L, "Il Nome della Rosa", "Umberto Eco",
                "Un affascinante thriller medievale ambientato in un'abbazia benedettina nel XIV secolo. Il frate francescano Guglielmo da Baskerville e il suo discepolo Adso da Melk indagano su una serie di misteriose morti in un'abbazia italiana.", "placeholder.jpg"));

        books.add(new Book(2L, "1984", "George Orwell",
                "Un romanzo distopico sul totalitarismo e la sorveglianza di massa. Winston Smith vive in un mondo dove il Grande Fratello controlla ogni aspetto della vita e dove la verità è manipolata dal Partito.", "placeholder.jpg"));

        books.add(new Book(3L, "Il Piccolo Principe", "Antoine de Saint-Exupéry",
                "Una fiaba poetica che ha conquistato il cuore di lettori di tutte le età. La storia di un giovane principe che viaggia di pianeta in pianeta, incontrando strani adulti e imparando lezioni sulla vita e sull'amore.", "placeholder.jpg"));

        books.add(new Book(4L, "Orgoglio e Pregiudizio", "Jane Austen",
                "Un classico romanzo romantico dell'epoca georgiana che esplora temi di amore, classe sociale e crescita personale attraverso la storia di Elizabeth Bennet e Mr. Darcy.", "placeholder.jpg"));

        books.add(new Book(5L, "Il Signore degli Anelli", "J.R.R. Tolkien",
                "L'epica avventura fantasy per eccellenza. Frodo Baggins e la Compagnia dell'Anello intraprendono un pericoloso viaggio per distruggere l'Unico Anello e sconfiggere il Signore Oscuro Sauron.", "placeholder.jpg"));

        books.add(new Book(6L, "To Kill a Mockingbird", "Harper Lee",
                "Un potente romanzo sulla giustizia e i diritti civili ambientato nel Sud degli Stati Uniti negli anni '30. La storia è narrata attraverso gli occhi della giovane Scout Finch.", "placeholder.jpg"));

        books.add(new Book(7L, "Il Grande Gatsby", "F. Scott Fitzgerald",
                "Un ritratto della società americana degli anni '20 attraverso la storia del misterioso milionario Jay Gatsby e del suo amore impossibile per Daisy Buchanan.", "placeholder.jpg"));

        books.add(new Book(8L, "Cento Anni di Solitudine", "Gabriel García Márquez",
                "Un capolavoro del realismo magico latinoamericano che narra la storia multigenerazionale della famiglia Buendía nel villaggio immaginario di Macondo.", "placeholder.jpg"));

        books.add(new Book(9L, "Harry Potter e la Pietra Filosofale", "J.K. Rowling",
                "Il primo libro della celebre saga che introduce Harry Potter, un giovane mago che scopre il suo destino nel mondo magico di Hogwarts.", "placeholder.jpg"));

        books.add(new Book(10L, "Il Codice da Vinci", "Dan Brown",
                "Un thriller che mescola arte, storia e mistero quando il professor Robert Langdon viene coinvolto in un'indagine su un omicidio al Louvre.", "placeholder.jpg"));
    }

    /**
     * Metodo di utilità per verificare la connessione al database
     */
    public boolean isDatabaseAvailable() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}