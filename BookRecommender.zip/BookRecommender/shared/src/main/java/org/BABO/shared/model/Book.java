package org.BABO.shared.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe che rappresenta un libro
 * Condivisa tra client e server per la serializzazione JSON
 * Aggiornata per gestire ISBN e titolo separatamente
 */
public class Book {

    // Attributi con annotazioni Jackson per JSON
    @JsonProperty("id")
    private Long id;

    @JsonProperty("isbn")
    private String isbn; // ISBN del libro

    @JsonProperty("title")
    private String title; // Titolo del libro

    @JsonProperty("author")
    private String author; // Autore del libro

    @JsonProperty("description")
    private String description; // Descrizione del libro

    @JsonProperty("imageUrl")
    private String imageUrl; // URL dell'immagine del libro

    @JsonProperty("publishYear")
    private String publishYear; // Anno di pubblicazione

    @JsonProperty("price")
    private Double price;

    @JsonProperty("isFree")
    private Boolean isFree;

    @JsonProperty("isNew")
    private Boolean isNew;

    // Costruttori
    public Book() {} // Costruttore vuoto per Jackson

    // Costruttore della classe Book (compatibile con il codice esistente)
    public Book(String title, String author, String description, String imageUrl) {
        this.title = title;
        this.author = author;
        this.description = description;
        this.imageUrl = imageUrl;
        this.isFree = true;
        this.isNew = false;
    }

    // Costruttore con ID (compatibile con codice esistente)
    public Book(Long id, String title, String author, String description, String imageUrl) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.description = description;
        this.imageUrl = imageUrl;
        this.isFree = true;
        this.isNew = false;
    }

    // Costruttore completo con ISBN e anno
    public Book(Long id, String isbn, String title, String author, String description, String publishYear, String imageUrl) {
        this.id = id;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.description = description;
        this.publishYear = publishYear;
        this.imageUrl = imageUrl;
        this.isFree = true;
        this.isNew = false;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Long getId() {
        return id;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getPublishYear() {
        return publishYear;
    }

    public Double getPrice() {
        return price;
    }

    public Boolean getIsFree() {
        return isFree;
    }

    public Boolean getIsNew() {
        return isNew;
    }

    // Setters
    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setPublishYear(String publishYear) {
        this.publishYear = publishYear;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public void setIsFree(Boolean isFree) {
        this.isFree = isFree;
    }

    public void setIsNew(Boolean isNew) {
        this.isNew = isNew;
    }

    // Metodi di utilità per compatibilità (usati nel codice esistente)
    public String title() {
        return this.title;
    }

    public String author() {
        return this.author;
    }

    public String imageUrl() {
        return this.imageUrl;
    }

    /**
     * Genera il nome del file immagine basato sull'ISBN
     * Se l'ISBN non è disponibile, usa il titolo come fallback
     */
    public String generateImageFileName() {
        if (isbn != null && !isbn.trim().isEmpty()) {
            return isbn.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";
        } else if (title != null && !title.trim().isEmpty()) {
            return title.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";
        } else {
            return "placeholder.jpg";
        }
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", isbn='" + isbn + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", description='" + description + '\'' +
                ", publishYear='" + publishYear + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", price=" + price +
                ", isFree=" + isFree +
                ", isNew=" + isNew +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return id != null ? id.equals(book.id) : book.id == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}