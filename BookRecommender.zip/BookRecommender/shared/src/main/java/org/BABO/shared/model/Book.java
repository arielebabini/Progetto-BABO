package org.BABO.shared.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe che rappresenta un libro
 * Condivisa tra client e server per la serializzazione JSON
 */
public class Book {

    // Attributi con annotazioni Jackson per JSON
    @JsonProperty("id")
    private Long id;

    @JsonProperty("title")
    String title; // Titolo del libro

    @JsonProperty("author")
    String author; // Autore del libro

    @JsonProperty("description")
    String description; // Descrizione del libro

    @JsonProperty("imageUrl")
    String imageUrl; // URL dell'immagine del libro

    @JsonProperty("price")
    private Double price;

    @JsonProperty("isFree")
    private Boolean isFree;

    @JsonProperty("isNew")
    private Boolean isNew;

    // Costruttori
    public Book() {} // Costruttore vuoto per Jackson

    // Costruttore della classe Book (compatibile con il codice esistente)
    public Book(String title, String author, String description, String imageUrl) {
        this.title = title; // Inizializza il titolo
        this.author = author; // Inizializza l'autore
        this.description = description; // Inizializza la descrizione
        this.imageUrl = imageUrl; // Inizializza l'URL dell'immagine
        this.isFree = true;
        this.isNew = false;
    }

    // Costruttore con ID
    public Book(Long id, String title, String author, String description, String imageUrl) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.description = description;
        this.imageUrl = imageUrl;
        this.isFree = true;
        this.isNew = false;
    }

    // Getters (mantengo compatibilità con codice esistente)
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Long getId() {
        return id;
    }

    public Double getPrice() {
        return price;
    }

    public Boolean getIsFree() {
        return isFree;
    }

    public Boolean getIsNew() {
        return isNew;
    }

    // Setters (mantengo compatibilità con codice esistente)
    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public void setIsFree(Boolean isFree) {
        this.isFree = isFree;
    }

    public void setIsNew(Boolean isNew) {
        this.isNew = isNew;
    }

    // Metodi di utilità per compatibilità (usati nel codice esistente)
    public String title() {
        return this.title;
    }

    public String author() {
        return this.author;
    }

    public String imageUrl() {
        return this.imageUrl;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", description='" + description + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", price=" + price +
                ", isFree=" + isFree +
                ", isNew=" + isNew +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return id != null ? id.equals(book.id) : book.id == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}