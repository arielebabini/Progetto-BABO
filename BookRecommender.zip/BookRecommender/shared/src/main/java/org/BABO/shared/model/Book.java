package org.BABO.shared.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe che rappresenta un libro
 * Condivisa tra client e server per la serializzazione JSON
 * AGGIORNATA: Aggiunta @JsonIgnoreProperties per ignorare campi sconosciuti
 */
@JsonIgnoreProperties(ignoreUnknown = true) // IMPORTANTE: Ignora campi sconosciuti nel JSON
public class Book {

    // Attributi con annotazioni Jackson per JSON
    @JsonProperty("id")
    private Long id;

    @JsonProperty("isbn")
    private String isbn;

    @JsonProperty("title")
    private String title;

    @JsonProperty("author")
    private String author;

    @JsonProperty("description")
    private String description;

    @JsonProperty("imageUrl")
    private String imageUrl;

    @JsonProperty("publishYear")
    private String publishYear;

    @JsonProperty("price")
    private Double price;

    @JsonProperty("isFree")
    private Boolean isFree;

    @JsonProperty("isNew")
    private Boolean isNew;

    // NUOVI CAMPI per gestire response dal server
    @JsonProperty("category")
    private String category;

    @JsonProperty("publisher")
    private String publisher;

    @JsonProperty("language")
    private String language;

    @JsonProperty("pages")
    private Integer pages;

    // Costruttori
    public Book() {} // Costruttore vuoto per Jackson

    public Book(String title, String author, String description, String imageUrl) {
        this.title = title;
        this.author = author;
        this.description = description;
        this.imageUrl = imageUrl;
        this.isFree = true;
        this.isNew = false;
    }

    public Book(Long id, String title, String author, String description, String imageUrl) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.description = description;
        this.imageUrl = imageUrl;
        this.isFree = true;
        this.isNew = false;
    }

    public Book(Long id, String isbn, String title, String author, String description, String publishYear, String imageUrl) {
        this.id = id;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.description = description;
        this.publishYear = publishYear;
        this.imageUrl = imageUrl;
        this.isFree = true;
        this.isNew = false;
    }

    // Getters esistenti
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Long getId() {
        return id;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getPublishYear() {
        return publishYear;
    }

    public Double getPrice() {
        return price;
    }

    public Boolean getIsFree() {
        return isFree;
    }

    public Boolean getIsNew() {
        return isNew;
    }

    public String getCategory() {
        return category;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getLanguage() {
        return language;
    }

    public Integer getPages() {
        return pages;
    }

    // Setters esistenti
    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setPublishYear(String publishYear) {
        this.publishYear = publishYear;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public void setIsFree(Boolean isFree) {
        this.isFree = isFree;
    }

    public void setIsNew(Boolean isNew) {
        this.isNew = isNew;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public void setPages(Integer pages) {
        this.pages = pages;
    }

    // Metodi di utilità per compatibilità
    public String title() {
        return this.title;
    }

    public String author() {
        return this.author;
    }

    public String imageUrl() {
        return this.imageUrl;
    }

    /**
     * Genera il nome del file immagine basato sull'ISBN
     */
    public String generateImageFileName() {
        if (isbn != null && !isbn.trim().isEmpty()) {
            return isbn.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";
        } else if (title != null && !title.trim().isEmpty()) {
            return title.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";
        } else {
            return "placeholder.jpg";
        }
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", isbn='" + isbn + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", description='" + description + '\'' +
                ", publishYear='" + publishYear + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", category='" + category + '\'' +
                ", publisher='" + publisher + '\'' +
                ", language='" + language + '\'' +
                ", pages=" + pages +
                ", price=" + price +
                ", isFree=" + isFree +
                ", isNew=" + isNew +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;

        // Confronta per ISBN se disponibile, altrimenti per ID
        if (isbn != null && book.isbn != null) {
            return isbn.equals(book.isbn);
        }
        return id != null ? id.equals(book.id) : book.id == null;
    }

    @Override
    public int hashCode() {
        // Usa ISBN se disponibile, altrimenti ID
        if (isbn != null) {
            return isbn.hashCode();
        }
        return id != null ? id.hashCode() : 0;
    }
}