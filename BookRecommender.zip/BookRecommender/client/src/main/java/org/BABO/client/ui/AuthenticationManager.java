package org.BABO.client.ui;

import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.DialogPane;
import javafx.scene.layout.StackPane;

/**
 * Gestisce l'autenticazione dell'utente
 */
public class AuthenticationManager {

    private boolean isAuthenticated = false;
    private String currentUsername = null;
    private AuthPanel authPanel;

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public String getCurrentUsername() {
        return currentUsername;
    }

    public void handleAuthButtonClick() {
        if (isAuthenticated) {
            showUserProfileOptions();
        } else {
            // Il pannello verrà mostrato dal MainWindow
        }
    }

    public void showAuthPanel(StackPane mainRoot) {
        authPanel = new AuthPanel();

        // Crea un overlay semi-trasparente
        StackPane overlay = new StackPane();
        overlay.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7);");

        // Centra il pannello di autenticazione
        overlay.getChildren().add(authPanel);
        StackPane.setAlignment(authPanel, Pos.CENTER);

        // Chiudi il pannello cliccando sullo sfondo
        overlay.setOnMouseClicked(e -> {
            if (e.getTarget() == overlay) {
                closeAuthPanel(mainRoot);
            }
        });

        // Previeni la chiusura cliccando sul pannello stesso
        authPanel.setOnMouseClicked(e -> e.consume());

        // Aggiungi l'overlay al root principale
        mainRoot.getChildren().add(overlay);

        System.out.println("🔑 Pannello autenticazione aperto");
    }

    private void closeAuthPanel(StackPane mainRoot) {
        if (mainRoot.getChildren().size() > 1) {
            mainRoot.getChildren().remove(mainRoot.getChildren().size() - 1);
        }
        System.out.println("🚪 Pannello autenticazione chiuso");
    }

    public void showUserProfileOptions() {
        Alert profileAlert = new Alert(Alert.AlertType.INFORMATION);
        profileAlert.setTitle("👤 Profilo Utente");
        profileAlert.setHeaderText("Gestione Profilo");
        profileAlert.setContentText(
                "• 📊 Visualizza statistiche di lettura\n" +
                        "• ⚙️ Modifica preferenze\n" +
                        "• 📚 Gestisci libreria personale\n" +
                        "• 🚪 Logout\n\n" +
                        "Funzionalità complete saranno implementate in versione futura."
        );

        // Styling dell'alert per mantenere coerenza con il tema
        DialogPane dialogPane = profileAlert.getDialogPane();
        dialogPane.setStyle(
                "-fx-background-color: #1e1e1e;" +
                        "-fx-text-fill: white;"
        );

        profileAlert.showAndWait();
    }

    /**
     * Aggiorna lo stato di autenticazione
     * Questo metodo sarà chiamato quando l'utente si autentica con successo
     */
    public void setAuthenticationState(boolean authenticated, String username) {
        this.isAuthenticated = authenticated;
        this.currentUsername = username;
        if (authenticated) {
            System.out.println("✅ Utente autenticato: " + username);
        } else {
            System.out.println("🚪 Utente disconnesso");
        }
    }

    /**
     * Effettua il logout dell'utente
     */
    public void logout() {
        setAuthenticationState(false, null);
    }

    /**
     * Verifica se l'utente ha i permessi per una determinata azione
     */
    public boolean hasPermission(String action) {
        if (!isAuthenticated) {
            return false;
        }

        // Qui potresti implementare una logica di permessi più complessa
        // basata sui ruoli dell'utente
        return true;
    }
}