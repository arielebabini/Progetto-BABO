package org.BABO.client.ui;

import org.BABO.shared.model.Book;
import org.BABO.client.service.BookService;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import java.util.List;
import java.util.ArrayList;
import java.util.function.Consumer;

/**
 * Gestisce l'area principale dei contenuti
 * AGGIORNATO: Navigazione contestuale per sezioni
 */
public class ContentArea {

    private final BookService bookService;
    private final boolean serverAvailable;
    private AuthenticationManager authManager;
    private VBox content;
    private Consumer<Book> bookClickHandler;
    private BookSectionFactory sectionFactory;
    private Consumer<List<Book>> cachedBooksCallback;

    // NUOVO: Cache per navigazione contestuale
    private List<Book> featuredBooks = new ArrayList<>();
    private List<Book> freeBooks = new ArrayList<>();
    private List<Book> newBooks = new ArrayList<>();
    private List<Book> searchResults = new ArrayList<>();
    private List<Book> advancedSearchResults = new ArrayList<>();

    public ContentArea(BookService bookService, boolean serverAvailable, AuthenticationManager authManager) {
        this.bookService = bookService;
        this.serverAvailable = serverAvailable;
        this.authManager = authManager;
        this.sectionFactory = new BookSectionFactory(bookService, serverAvailable);

        // NUOVO: Configura navigazione contestuale
        setupContextualNavigation();
    }

    public ContentArea(BookService bookService, boolean serverAvailable) {
        this.bookService = bookService;
        this.serverAvailable = serverAvailable;
        this.sectionFactory = new BookSectionFactory(bookService, serverAvailable);

        // NUOVO: Configura navigazione contestuale
        setupContextualNavigation();
    }

    // Setter alternativo se si preferisce non passare authManager nel costruttore
    public void setAuthManager(AuthenticationManager authManager) {
        this.authManager = authManager;
    }

    // NUOVO: Configura navigazione contestuale
    private void setupContextualNavigation() {
        // Configura callback per salvare libri per sezione
        this.sectionFactory.setFeaturedBooksCallback(books -> {
            this.featuredBooks = books;
            System.out.println("📚 Featured books salvati per navigazione: " + books.size());
        });

        this.sectionFactory.setFreeBooksCallback(books -> {
            this.freeBooks = books;
            System.out.println("🆓 Free books salvati per navigazione: " + books.size());
        });

        this.sectionFactory.setNewBooksCallback(books -> {
            this.newBooks = books;
            System.out.println("✨ New books salvati per navigazione: " + books.size());
        });

        this.sectionFactory.setSearchResultsCallback(books -> {
            this.searchResults = books;
            System.out.println("🔍 Search results salvati per navigazione: " + books.size());
        });
    }

    public ScrollPane createContentArea() {
        content = new VBox(20);
        content.setId("content");
        content.setPadding(new Insets(15, 20, 30, 20));
        content.setStyle("-fx-background-color: #1e1e1e;");

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");

        return scrollPane;
    }

    public void setBookClickHandler(Consumer<Book> handler) {
        this.bookClickHandler = handler;

        // AGGIORNATO: Usa handler contestuale invece di quello generico
        Consumer<Book> contextualHandler = book -> handleContextualBookClick(book);
        this.sectionFactory.setBookClickHandler(contextualHandler);
    }

    // NUOVO: Gestisce click contestuale in base alla sezione
    private void handleContextualBookClick(Book book) {
        List<Book> navigationBooks = determineNavigationContext(book);

        System.out.println("📖 Click su '" + book.getTitle() + "' - Navigazione tra " + navigationBooks.size() + " libri");

        // Crea popup con navigazione contestuale
        StackPane popup = BookDetailsPopup.createWithLibrarySupport(
                book,
                navigationBooks,
                () -> {
                    // Chiudi popup
                    closeTopPopup();
                },
                authManager
        );

        // Aggiungi al root principale
        StackPane mainRoot = findMainRoot();
        if (mainRoot != null) {
            mainRoot.getChildren().add(popup);
        }
    }

    // NUOVO: Determina il contesto di navigazione per un libro
    private List<Book> determineNavigationContext(Book book) {
        // Controlla in quale sezione si trova il libro
        if (featuredBooks.contains(book)) {
            System.out.println("📚 Libro trovato in Featured Books");
            return featuredBooks;
        }

        if (freeBooks.contains(book)) {
            System.out.println("🆓 Libro trovato in Free Books");
            return freeBooks;
        }

        if (newBooks.contains(book)) {
            System.out.println("✨ Libro trovato in New Books");
            return newBooks;
        }

        if (searchResults.contains(book)) {
            System.out.println("🔍 Libro trovato in Search Results");
            return searchResults;
        }

        if (advancedSearchResults.contains(book)) {
            System.out.println("🎯 Libro trovato in Advanced Search Results");
            return advancedSearchResults;
        }

        // Fallback: libro singolo
        System.out.println("📖 Libro non trovato in cache - navigazione singola");
        return List.of(book);
    }

    // NUOVO: Helper methods
    private StackPane findMainRoot() {
        if (content.getScene() != null && content.getScene().getRoot() instanceof StackPane) {
            return (StackPane) content.getScene().getRoot();
        }
        return null;
    }

    private void closeTopPopup() {
        StackPane mainRoot = findMainRoot();
        if (mainRoot != null && mainRoot.getChildren().size() > 1) {
            mainRoot.getChildren().remove(mainRoot.getChildren().size() - 1);
        }
    }

    public void setCachedBooksCallback(Consumer<List<Book>> callback) {
        this.cachedBooksCallback = callback;

        // AGGIORNATO: Callback che combina tutte le sezioni
        Consumer<List<Book>> combinedCallback = books -> {
            // Combina tutti i libri delle sezioni per backward compatibility
            List<Book> allBooks = new ArrayList<>();
            allBooks.addAll(featuredBooks);
            allBooks.addAll(freeBooks);
            allBooks.addAll(newBooks);
            allBooks.addAll(searchResults);
            allBooks.addAll(advancedSearchResults);

            // Rimuovi duplicati
            List<Book> uniqueBooks = allBooks.stream()
                    .distinct()
                    .toList();

            if (callback != null) {
                callback.accept(uniqueBooks);
            }
        };

        this.sectionFactory.setCachedBooksCallback(combinedCallback);
    }

    public void loadInitialContent() {
        // NUOVO: Reset cache
        featuredBooks.clear();
        freeBooks.clear();
        newBooks.clear();
        searchResults.clear();
        advancedSearchResults.clear();

        content.getChildren().clear();

        // Sezioni principali
        content.getChildren().addAll(
                sectionFactory.createFeaturedSection(),
                sectionFactory.createBookSection("📚 Libri gratuiti", "free"),
                sectionFactory.createBookSection("✨ Nuove uscite", "new")
        );

        // Carica categorie async
        sectionFactory.loadCategoriesAsync(content);
    }

    public void handleSearch(String query, Consumer<Book> clickHandler) {
        if (query == null || query.trim().isEmpty()) {
            loadInitialContent();
            return;
        }

        // AGGIORNATO: Reset cache precedenti e usa handler contestuale
        searchResults.clear();
        advancedSearchResults.clear();

        // Crea handler contestuale per la ricerca
        Consumer<Book> contextualSearchHandler = book -> handleContextualBookClick(book);

        sectionFactory.performSearch(query, content, contextualSearchHandler);
    }

    public void showSearchResults(AdvancedSearchPanel.SearchResult searchResult) {
        content.getChildren().clear();

        // NUOVO: Salva risultati ricerca avanzata
        advancedSearchResults = searchResult.getBooks();
        searchResults.clear(); // Pulisci ricerca normale

        System.out.println("🎯 Advanced search results salvati: " + advancedSearchResults.size() + " libri");

        // AGGIORNATO: Usa handler contestuale
        Consumer<Book> contextualHandler = book -> handleContextualBookClick(book);

        VBox resultsSection = sectionFactory.createAdvancedSearchResultsSection(
                searchResult.getDescription(),
                searchResult.getBooks(),
                contextualHandler
        );

        content.getChildren().add(resultsSection);
    }
}