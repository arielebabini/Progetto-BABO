package org.BABO.client.ui;

import org.BABO.shared.model.Book;
import org.BABO.client.service.BookService;
import javafx.geometry.Insets;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import java.util.List;
import java.util.function.Consumer;

/**
 * Gestisce l'area principale dei contenuti
 */
public class ContentArea {

    private final BookService bookService;
    private final boolean serverAvailable;
    private VBox content;
    private Consumer<Book> bookClickHandler;
    private BookSectionFactory sectionFactory;
    private Consumer<List<Book>> cachedBooksCallback;

    public ContentArea(BookService bookService, boolean serverAvailable) {
        this.bookService = bookService;
        this.serverAvailable = serverAvailable;
        this.sectionFactory = new BookSectionFactory(bookService, serverAvailable);
    }

    public ScrollPane createContentArea() {
        content = new VBox(20);
        content.setId("content");
        content.setPadding(new Insets(15, 20, 30, 20));
        content.setStyle("-fx-background-color: #1e1e1e;");

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");

        return scrollPane;
    }

    public void setBookClickHandler(Consumer<Book> handler) {
        this.bookClickHandler = handler;
        this.sectionFactory.setBookClickHandler(handler);
    }

    public void setCachedBooksCallback(Consumer<List<Book>> callback) {
        this.cachedBooksCallback = callback;
        this.sectionFactory.setCachedBooksCallback(callback);
    }

    public void loadInitialContent() {
        content.getChildren().clear();

        // Sezioni principali
        content.getChildren().addAll(
                sectionFactory.createFeaturedSection(),
                sectionFactory.createBookSection("📚 Libri gratuiti", "free"),
                sectionFactory.createBookSection("✨ Nuove uscite", "new")
        );

        // Carica categorie async
        sectionFactory.loadCategoriesAsync(content);
    }

    public void handleSearch(String query, Consumer<Book> clickHandler) {
        if (query == null || query.trim().isEmpty()) {
            loadInitialContent();
            return;
        }

        sectionFactory.performSearch(query, content, clickHandler);
    }
}