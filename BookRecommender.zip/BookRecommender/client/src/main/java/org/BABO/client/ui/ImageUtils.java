package org.BABO.client.ui;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.InputStream;

/**
 * Utility class per la gestione delle immagini dei libri
 * Gestisce il caricamento sicuro delle immagini con fallback
 */
public class ImageUtils {

    /**
     * Crea un ImageView sicuro con gestione degli errori
     * Cerca prima l'immagine nelle risorse, poi usa placeholder
     */
    public static ImageView createSafeImageView(String imageFileName, double width, double height) {
        Image image = loadSafeImage(imageFileName);
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(width);
        imageView.setFitHeight(height);
        imageView.setPreserveRatio(true);
        imageView.setSmooth(true);
        return imageView;
    }

    /**
     * Carica un'immagine in modo sicuro con fallback automatico
     */
    public static Image loadSafeImage(String imageFileName) {
        Image image;
        try {
            // Cerca nelle risorse del progetto
            InputStream stream = ImageUtils.class.getResourceAsStream("/books_covers/" + imageFileName);
            if (stream == null) {
                System.out.println("⚠️ File immagine non trovato: " + imageFileName + " - uso placeholder");
                return createPlaceholderImage();
            }

            image = new Image(stream);
            if (image.isError()) {
                System.out.println("⚠️ Errore caricamento immagine: " + imageFileName + " - uso placeholder");
                return createPlaceholderImage();
            }

            System.out.println("✅ Immagine caricata: " + imageFileName);
            return image;

        } catch (Exception e) {
            System.out.println("❌ Eccezione caricamento immagine " + imageFileName + ": " + e.getMessage() + " - uso placeholder");
            return createPlaceholderImage();
        }
    }

    /**
     * Crea un'immagine placeholder quando l'immagine originale non è disponibile
     */
    private static Image createPlaceholderImage() {
        try {
            // Prova a caricare un'immagine placeholder dalle risorse
            InputStream placeholderStream = ImageUtils.class.getResourceAsStream("/books_covers/placeholder.jpg");
            if (placeholderStream != null) {
                Image placeholderImage = new Image(placeholderStream);
                if (!placeholderImage.isError()) {
                    return placeholderImage;
                }
            }

            // Se non c'è placeholder locale, usa un placeholder online
            return new Image("https://via.placeholder.com/140x210/333333/FFFFFF?text=Libro", 140, 210, true, true);

        } catch (Exception e) {
            System.out.println("❌ Errore creazione placeholder: " + e.getMessage());
            // Ultima risorsa: crea un'immagine vuota
            return new Image("https://via.placeholder.com/140x210/666666/FFFFFF?text=N/A", 140, 210, true, true);
        }
    }

    /**
     * Verifica se un file immagine esiste nelle risorse
     */
    public static boolean imageExists(String imageFileName) {
        try {
            InputStream stream = ImageUtils.class.getResourceAsStream("/books_covers/" + imageFileName);
            if (stream != null) {
                stream.close();
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Genera il nome del file immagine basato su ISBN o titolo
     */
    public static String generateImageFileName(String isbn, String title) {
        if (isbn != null && !isbn.trim().isEmpty()) {
            return isbn.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";
        } else if (title != null && !title.trim().isEmpty()) {
            return title.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";
        } else {
            return "placeholder.jpg";
        }
    }
}