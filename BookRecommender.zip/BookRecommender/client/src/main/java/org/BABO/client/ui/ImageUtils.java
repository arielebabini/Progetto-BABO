package org.BABO.client.ui;

import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import java.io.InputStream;

/**
 * Utility per la gestione sicura delle immagini
 */
public class ImageUtils {

    /**
     * Crea un ImageView sicuro che gestisce gli errori di caricamento delle immagini.
     */
    public static ImageView createSafeImageView(String isbnFileName, double width, double height) {
        Image image;
        try {
            InputStream stream = ImageUtils.class.getResourceAsStream("/books_covers/" + isbnFileName);
            if (stream == null) {
                throw new IllegalArgumentException("File non trovato: " + isbnFileName);
            }
            image = new Image(stream, width, height, true, true);
            if (image.isError()) {
                throw new Exception("Errore nel caricamento dell'immagine.");
            }
        } catch (Exception e) {
            // Fallback su placeholder locale
            image = createPlaceholderImage(width, height);
        }

        ImageView imageView = new ImageView(image);

        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.rgb(0, 0, 0, 0.5));
        shadow.setOffsetY(3);
        shadow.setRadius(5);
        imageView.setEffect(shadow);

        return imageView;
    }

    /**
     * Crea un'immagine placeholder locale sicura
     */
    private static Image createPlaceholderImage(double width, double height) {
        try {
            // Prova a caricare placeholder locale
            InputStream placeholderStream = ImageUtils.class.getResourceAsStream("/books_covers/placeholder.jpg");
            if (placeholderStream != null) {
                return new Image(placeholderStream, width, height, true, true);
            }
        } catch (Exception e) {
            System.err.println("Impossibile caricare placeholder locale: " + e.getMessage());
        }

        // Fallback finale: crea un'immagine vuota
        return new Image("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==", width, height, true, true);
    }

    /**
     * Crea un clip rettangolare con angoli arrotondati
     */
    public static Rectangle createRoundedClip(double width, double height) {
        Rectangle clip = new Rectangle(width, height);
        clip.setArcWidth(8);
        clip.setArcHeight(8);
        return clip;
    }

    /**
     * Crea un clip rettangolare con angoli arrotondati personalizzati
     */
    public static Rectangle createRoundedClip(double width, double height, double arcWidth, double arcHeight) {
        Rectangle clip = new Rectangle(width, height);
        clip.setArcWidth(arcWidth);
        clip.setArcHeight(arcHeight);
        return clip;
    }

    /**
     * Applica un'ombra standard a un ImageView
     */
    public static void applyStandardShadow(ImageView imageView) {
        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.rgb(0, 0, 0, 0.5));
        shadow.setOffsetY(3);
        shadow.setRadius(5);
        imageView.setEffect(shadow);
    }

    /**
     * Applica un'ombra personalizzata a un ImageView
     */
    public static void applyCustomShadow(ImageView imageView, Color color, double offsetX, double offsetY, double radius) {
        DropShadow shadow = new DropShadow();
        shadow.setColor(color);
        shadow.setOffsetX(offsetX);
        shadow.setOffsetY(offsetY);
        shadow.setRadius(radius);
        imageView.setEffect(shadow);
    }

    /**
     * Verifica se un'immagine è valida
     */
    public static boolean isImageValid(Image image) {
        return image != null && !image.isError() && image.getWidth() > 0 && image.getHeight() > 0;
    }

    /**
     * Carica un'immagine con gestione errori
     */
    public static Image loadImageSafely(String resourcePath) {
        try {
            InputStream stream = ImageUtils.class.getResourceAsStream(resourcePath);
            if (stream == null) {
                return null;
            }
            Image image = new Image(stream);
            return isImageValid(image) ? image : null;
        } catch (Exception e) {
            System.err.println("Errore caricamento immagine: " + resourcePath + " - " + e.getMessage());
            return null;
        }
    }
}