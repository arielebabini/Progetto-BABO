package org.BABO.client;

import org.BABO.client.ui.AppleBooksClient;

/**
 * Punto di ingresso principale per il client JavaFX
 * Avvia l'applicazione Apple Books client
 */
public class ClientApplication {

    public static void main(String[] args) {
        System.out.println("🚀 Avviando Apple Books Client...");
        System.out.println("📡 Verifica connessione server su http://localhost:8080");

        try {
            // Avvia l'applicazione JavaFX
            AppleBooksClient.launch(AppleBooksClient.class, args);
        } catch (Exception e) {
            System.err.println("❌ Errore durante l'avvio del client: " + e.getMessage());
            e.printStackTrace();
        }
    }
}