package org.BABO.client.ui;

import org.BABO.client.service.BookService;
import org.BABO.shared.model.Book;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.util.List;

/**
 * Classe principale dell'applicazione Apple Books Client
 * CORRETTO: Usa MainWindow esistente con PopupManager integrato
 */
public class AppleBooksClient extends Application {

    private BookService bookService;
    private Stage primaryStage;
    private boolean serverAvailable = false;
    private MainWindow mainWindow;

    @Override
    public void init() {
        System.out.println("🔧 Inizializzazione client...");
        bookService = new BookService();

        // Verifica disponibilità server
        serverAvailable = bookService.isServerAvailable();
        if (serverAvailable) {
            System.out.println("✅ Server raggiungibile");
        } else {
            System.out.println("⚠️ Server non raggiungibile - modalità offline");
        }
    }

    @Override
    public void start(Stage stage) {
        System.out.println("🚀 Avvio AppleBooksClient con PopupManager integrato");

        try {
            // 1. REGISTRA ApplicationProtection
            ApplicationProtection.registerMainStage(stage);
            System.out.println("🛡️ Protezione applicazione attivata");

            this.primaryStage = stage;

            // 2. Crea la finestra principale (usa la tua MainWindow esistente)
            System.out.println("🎨 Creazione interfaccia utente...");
            mainWindow = new MainWindow(bookService, serverAvailable);
            StackPane root = mainWindow.createMainLayout();

            // 3. INIZIALIZZA PopupManager con il root di MainWindow
            PopupManager popupManager = PopupManager.getInstance();
            popupManager.initialize(root);
            System.out.println("✅ PopupManager inizializzato con MainWindow");

            // 4. Setup scena
            Scene scene = new Scene(root, 1100, 750);

            // Carica CSS se disponibile
            try {
                scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
            } catch (Exception e) {
                System.out.println("⚠️ CSS non trovato, uso stili default");
            }

            stage.setScene(scene);
            stage.setTitle("📚 Apple Books Client " + (serverAvailable ? "🌐" : "📴"));
            stage.setMinWidth(1000);
            stage.setMinHeight(600);

            // 5. GESTIONE CHIUSURA MIGLIORATA
            stage.setOnCloseRequest(e -> {
                System.out.println("👋 Richiesta chiusura applicazione...");
                handleApplicationClose();
            });

            // 6. Setup eventi post-mostrazione
            stage.setOnShown(e -> {
                System.out.println("✅ Interfaccia avviata con successo!");

                // Debug iniziale
                if (isDebugMode()) {
                    ApplicationProtection.debugApplicationState();
                    popupManager.debugFullState();
                    testPopupManagerSetup();
                }
            });

            // 7. Mostra applicazione
            stage.show();
            stage.centerOnScreen();

            System.out.println("🎉 AppleBooksClient avviato con successo");

        } catch (Exception e) {
            System.err.println("❌ Errore fatale nell'avvio: " + e.getMessage());
            e.printStackTrace();

            // Mostra errore all'utente
            showStartupError(e);
            Platform.exit();
        }
    }

    /**
     * Gestisce la chiusura dell'applicazione
     */
    private void handleApplicationClose() {
        try {
            System.out.println("🔒 Inizio procedura chiusura...");

            // 1. Chiudi tutti i popup tramite PopupManager
            PopupManager popupManager = PopupManager.getInstance();
            if (popupManager.hasActivePopups()) {
                System.out.println("🔒 Chiusura popup aperti...");
                popupManager.closeAllPopups();

                // Attendi un momento per la chiusura
                Platform.runLater(() -> {
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                    }
                    finalizeApplicationClose();
                });
            } else {
                finalizeApplicationClose();
            }

        } catch (Exception e) {
            System.err.println("⚠️ Errore durante chiusura: " + e.getMessage());
            finalizeApplicationClose();
        }
    }

    /**
     * Finalizza la chiusura dell'applicazione
     */
    private void finalizeApplicationClose() {
        try {
            // Cleanup cache immagini
            ImageUtils.clearImageCache();

            // Cleanup MainWindow se ha metodi di cleanup
            if (mainWindow != null) {
                // MainWindow ha AuthenticationManager che può fare cleanup
                if (mainWindow.getAuthManager() != null) {
                    mainWindow.getAuthManager().shutdown();
                }
                System.out.println("🧹 MainWindow cleanup completato");
            }

            System.out.println("✅ Chiusura completata correttamente");
            Platform.exit();

        } catch (Exception e) {
            System.err.println("⚠️ Errore nella finalizzazione: " + e.getMessage());
            Platform.exit();
        }
    }

    @Override
    public void stop() {
        System.out.println("🛑 Stop applicazione...");

        try {
            // Cleanup servizi
            if (bookService != null) {
                bookService.shutdown();
            }

            // Cleanup finale PopupManager
            PopupManager.getInstance().emergencyReset();

        } catch (Exception e) {
            System.err.println("⚠️ Errore durante stop: " + e.getMessage());
        }

        System.out.println("✅ Stop completato");
    }

    /**
     * Test del setup PopupManager
     */
    private void testPopupManagerSetup() {
        System.out.println("🧪 Test setup PopupManager");

        try {
            PopupManager popupManager = PopupManager.getInstance();

            if (popupManager.isInitialized()) {
                System.out.println("✅ PopupManager correttamente inizializzato");
                popupManager.runIntegrityCheck();
            } else {
                System.err.println("❌ PopupManager NON inizializzato!");
            }

        } catch (Exception e) {
            System.err.println("❌ Errore test PopupManager: " + e.getMessage());
        }
    }

    /**
     * Verifica se siamo in modalità debug
     */
    private boolean isDebugMode() {
        return Boolean.getBoolean("debug") ||
                System.getProperty("app.debug") != null ||
                "development".equals(System.getProperty("app.environment"));
    }

    /**
     * Mostra errore di avvio
     */
    private void showStartupError(Exception e) {
        Platform.runLater(() -> {
            try {
                javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                        javafx.scene.control.Alert.AlertType.ERROR);
                alert.setTitle("Errore Avvio");
                alert.setHeaderText("Errore durante l'avvio dell'applicazione");
                alert.setContentText("Errore: " + e.getMessage() +
                        "\n\nL'applicazione verrà chiusa.");

                alert.showAndWait();
            } catch (Exception alertError) {
                System.err.println("❌ Errore anche nel mostrare alert: " + alertError.getMessage());
            }
        });
    }

    // =====================================================
    // METODI PUBBLICI STATICI PER POPUP MANAGER
    // =====================================================

    /**
     * METODO PRINCIPALE per aprire dettagli libro con PopupManager
     * DA USARE al posto di BookDetailsPopup.create()
     */
    public static void openBookDetails(Book book, List<Book> collection, AuthenticationManager authManager) {
        if (book == null) {
            System.err.println("❌ openBookDetails: libro null");
            return;
        }

        System.out.println("📖 Apertura dettagli libro: " + book.getTitle());

        try {
            PopupManager popupManager = PopupManager.getInstance();

            if (!popupManager.isInitialized()) {
                System.err.println("❌ PopupManager non inizializzato!");
                return;
            }

            popupManager.showBookDetails(book, collection, authManager);
            System.out.println("✅ Popup libro aperto tramite PopupManager");

        } catch (Exception e) {
            System.err.println("❌ Errore apertura popup: " + e.getMessage());
            e.printStackTrace();

            // Fallback: mostra errore
            showError("Errore nell'apertura dei dettagli del libro: " + e.getMessage());
        }
    }

    /**
     * METODO per aprire popup raccomandazione
     */
    public static void openRecommendationDetails(Book book, List<Book> collection, AuthenticationManager authManager) {
        if (book == null) {
            System.err.println("❌ openRecommendationDetails: libro null");
            return;
        }

        System.out.println("💡 Apertura raccomandazione: " + book.getTitle());

        try {
            PopupManager popupManager = PopupManager.getInstance();

            if (!popupManager.isInitialized()) {
                System.err.println("❌ PopupManager non inizializzato!");
                return;
            }

            popupManager.showRecommendationDetails(book, collection, authManager);
            System.out.println("✅ Popup raccomandazione aperto tramite PopupManager");

        } catch (Exception e) {
            System.err.println("❌ Errore apertura popup raccomandazione: " + e.getMessage());
            e.printStackTrace();
            showError("Errore nell'apertura dei dettagli della raccomandazione: " + e.getMessage());
        }
    }

    /**
     * Mostra errore generico
     */
    private static void showError(String message) {
        Platform.runLater(() -> {
            try {
                javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                        javafx.scene.control.Alert.AlertType.ERROR);
                alert.setTitle("Errore");
                alert.setHeaderText(null);
                alert.setContentText(message);

                javafx.scene.control.DialogPane dialogPane = alert.getDialogPane();
                dialogPane.setStyle("-fx-background-color: #2b2b2b; -fx-text-fill: white;");

                alert.showAndWait();
            } catch (Exception e) {
                System.err.println("❌ Errore nel mostrare alert: " + e.getMessage());
            }
        });
    }

    // =====================================================
    // METODI DI DEBUG E UTILITÀ
    // =====================================================

    /**
     * DEBUG completo dello stato dell'applicazione
     */
    public static void debugApplicationState() {
        System.out.println("🔍 ===== DEBUG APPLICAZIONE COMPLETO =====");

        try {
            // Debug ApplicationProtection
            System.out.println("\n--- PROTEZIONE APPLICAZIONE ---");
            ApplicationProtection.debugApplicationState();

            // Debug PopupManager
            System.out.println("\n--- POPUP MANAGER ---");
            PopupManager popupManager = PopupManager.getInstance();
            popupManager.debugFullState();

            // Debug finestre sistema
            System.out.println("\n--- FINESTRE SISTEMA ---");
            debugSystemWindows();

        } catch (Exception e) {
            System.err.println("❌ Errore durante debug: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("🔍 ===== FINE DEBUG COMPLETO =====");
    }

    /**
     * Debug delle finestre di sistema
     */
    private static void debugSystemWindows() {
        try {
            javafx.collections.ObservableList<javafx.stage.Window> windows =
                    javafx.stage.Stage.getWindows();

            System.out.println("Finestre totali: " + windows.size());

            for (int i = 0; i < windows.size(); i++) {
                javafx.stage.Window window = windows.get(i);
                if (window instanceof Stage) {
                    Stage stage = (Stage) window;
                    System.out.println("  Finestra " + i + ": '" + stage.getTitle() + "'");
                    System.out.println("    Showing: " + stage.isShowing());
                    System.out.println("    Focused: " + stage.isFocused());
                    System.out.println("    Modal: " + stage.getModality());

                    if (stage.getScene() != null && stage.getScene().getRoot() instanceof StackPane) {
                        StackPane root = (StackPane) stage.getScene().getRoot();
                        System.out.println("    Children nel root: " + root.getChildren().size());
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("❌ Errore debug finestre: " + e.getMessage());
        }
    }

    /**
     * EMERGENZA: Chiude tutti i popup
     */
    public static void emergencyCloseAllPopups() {
        System.out.println("🚨 EMERGENZA: Chiusura di tutti i popup");

        try {
            PopupManager popupManager = PopupManager.getInstance();
            popupManager.emergencyReset();
            System.out.println("✅ Popup di emergenza chiusi");

        } catch (Exception e) {
            System.err.println("❌ Errore chiusura emergenza: " + e.getMessage());
        }
    }

    /**
     * Test dell'integrazione PopupManager
     */
    public static void testPopupManagerIntegration() {
        System.out.println("🧪 Test integrazione PopupManager");

        try {
            PopupManager popupManager = PopupManager.getInstance();

            if (popupManager.isInitialized()) {
                popupManager.runIntegrityCheck();
                System.out.println("✅ Test integrazione superato");
            } else {
                System.err.println("❌ PopupManager non inizializzato per test");
            }

        } catch (Exception e) {
            System.err.println("❌ Errore test integrazione: " + e.getMessage());
        }
    }

    // =====================================================
    // GETTERS PER ACCESSO AI COMPONENTI
    // =====================================================

    /**
     * Ottiene il MainWindow
     */
    public MainWindow getMainWindow() {
        return mainWindow;
    }

    /**
     * Ottiene il BookService
     */
    public BookService getBookService() {
        return bookService;
    }

    /**
     * Verifica se il server è disponibile
     */
    public boolean isServerAvailable() {
        return serverAvailable;
    }

    /**
     * Ottiene lo stage principale
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }

    /**
     * Ottiene il container principale (tramite MainWindow)
     */
    public StackPane getMainContainer() {
        return mainWindow != null ? mainWindow.getMainRoot() : null;
    }

    /**
     * Verifica se l'applicazione è completamente inizializzata
     */
    public boolean isFullyInitialized() {
        return primaryStage != null &&
                mainWindow != null &&
                PopupManager.getInstance().isInitialized();
    }
}