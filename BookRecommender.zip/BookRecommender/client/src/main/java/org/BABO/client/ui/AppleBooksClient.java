package org.BABO.client.ui;

import org.BABO.client.service.BookService;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * Classe principale dell'applicazione Apple Books Client
 * Gestisce solo l'inizializzazione e il lifecycle dell'app
 */
public class AppleBooksClient extends Application {

    private BookService bookService;
    private Stage primaryStage;
    private boolean serverAvailable = false;
    private MainWindow mainWindow;

    @Override
    public void init() {
        System.out.println("🔧 Inizializzazione client...");
        bookService = new BookService();

        // Verifica disponibilità server
        serverAvailable = bookService.isServerAvailable();
        if (serverAvailable) {
            System.out.println("✅ Server raggiungibile");
        } else {
            System.out.println("⚠️ Server non raggiungibile - modalità offline");
        }
    }

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        System.out.println("🎨 Avvio interfaccia utente...");

        // Crea la finestra principale
        mainWindow = new MainWindow(bookService, serverAvailable);
        StackPane root = mainWindow.createMainLayout();

        Scene scene = new Scene(root, 1100, 750);
        stage.setScene(scene);
        stage.setTitle("📚 Apple Books Client " + (serverAvailable ? "🌐" : "📴"));
        stage.setOnCloseRequest(e -> {
            System.out.println("👋 Chiusura applicazione...");
            Platform.exit();
        });
        stage.show();

        System.out.println("✅ Interfaccia avviata con successo!");
    }

    @Override
    public void stop() {
        System.out.println("🛑 Chiusura client...");
        if (bookService != null) {
            bookService.shutdown();
        }
    }
}