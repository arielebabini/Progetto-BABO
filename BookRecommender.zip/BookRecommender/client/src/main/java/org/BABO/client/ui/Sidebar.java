package org.BABO.client.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * Gestisce la sidebar dell'applicazione
 */
public class Sidebar {

    private final boolean serverAvailable;
    private final AuthenticationManager authManager;
    private final MainWindow mainWindow;

    public Sidebar(boolean serverAvailable, AuthenticationManager authManager, MainWindow mainWindow) {
        this.serverAvailable = serverAvailable;
        this.authManager = authManager;
        this.mainWindow = mainWindow;
    }

    public VBox createSidebar() {
        VBox sidebar = new VBox(15);
        sidebar.setPrefWidth(200);
        sidebar.setPrefHeight(700);
        sidebar.setStyle("-fx-background-color: #2c2c2e;");

        // Header
        Label sidebarHeader = new Label("📚 Libreria");
        sidebarHeader.setFont(Font.font("System", FontWeight.BOLD, 16));
        sidebarHeader.setTextFill(Color.WHITE);
        sidebarHeader.setPadding(new Insets(20, 0, 5, 20));

        // Menu items
        VBox menuItemsBox = createMenuItems();

        // Spacer
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        // Status server
        Label serverStatus = new Label(serverAvailable ? "🟢 Server Online" : "🔴 Modalità Offline");
        serverStatus.setTextFill(serverAvailable ? Color.LIGHTGREEN : Color.ORANGE);
        serverStatus.setFont(Font.font("System", 12));
        serverStatus.setPadding(new Insets(10, 20, 10, 20));

        // Auth button
        Button authButton = createAuthButton();

        sidebar.getChildren().addAll(sidebarHeader, menuItemsBox, spacer, serverStatus, authButton);
        return sidebar;
    }

    private VBox createMenuItems() {
        VBox menuItemsBox = new VBox(5);
        menuItemsBox.setPadding(new Insets(10, 0, 0, 15));

        String[] menuItems = {"🏠 Home", "🏪 Book Store", "🎧 Audiobook Store",
                "📖 Tutto", "📝 Da leggere", "✅ Letti", "📄 PDF"};

        for (int i = 0; i < menuItems.length; i++) {
            HBox itemBox = createMenuItem(menuItems[i], i == 0);
            menuItemsBox.getChildren().add(itemBox);
        }

        return menuItemsBox;
    }

    private HBox createMenuItem(String text, boolean isActive) {
        HBox itemBox = new HBox(10);
        Label label = new Label(text);
        label.setTextFill(isActive ? Color.WHITE : Color.LIGHTGRAY);
        label.setFont(Font.font("System", 14));

        itemBox.getChildren().add(label);
        itemBox.setAlignment(Pos.CENTER_LEFT);
        itemBox.setPadding(new Insets(8, 10, 8, 10));
        itemBox.setStyle("-fx-cursor: hand;");

        if (isActive) {
            itemBox.setStyle("-fx-background-color: #3a3a3c; -fx-background-radius: 5; -fx-cursor: hand;");
        }

        // Hover effects
        final int index = 1;
        itemBox.setOnMouseEntered(e ->
                itemBox.setStyle("-fx-background-color: #3a3a3c; -fx-background-radius: 5; -fx-cursor: hand;"));
        itemBox.setOnMouseExited(e -> {
            if (index != 0) { // Solo il primo elemento rimane attivo
                itemBox.setStyle("-fx-cursor: hand;");
            }
        });

        return itemBox;
    }

    private Button createAuthButton() {
        Button authButton = new Button(authManager.isAuthenticated() ?
                "👤 Profilo Utente" : "🔑 Accedi / Registrati");

        authButton.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #4a86e8;" +
                        "-fx-border-color: #4a86e8;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-cursor: hand;" +
                        "-fx-padding: 8 15;" +
                        "-fx-font-size: 12px;"
        );
        authButton.setMaxWidth(Double.MAX_VALUE);
        authButton.setAlignment(Pos.CENTER);

        // Event handler
        authButton.setOnAction(e -> {
            if (authManager.isAuthenticated()) {
                authManager.showUserProfileOptions();
            } else {
                mainWindow.showAuthPanel();
            }
        });

        // Hover effects
        setupButtonHoverEffects(authButton);

        VBox.setMargin(authButton, new Insets(0, 15, 15, 15));
        return authButton;
    }

    private void setupButtonHoverEffects(Button button) {
        String baseStyle =
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #4a86e8;" +
                        "-fx-border-color: #4a86e8;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-cursor: hand;" +
                        "-fx-padding: 8 15;" +
                        "-fx-font-size: 12px;";

        String hoverStyle = baseStyle.replace("transparent", "rgba(74, 134, 232, 0.1)");
        String pressStyle = baseStyle.replace("#4a86e8", "derive(#4a86e8, -20%)");

        button.setOnMouseEntered(e -> button.setStyle(hoverStyle));
        button.setOnMouseExited(e -> button.setStyle(baseStyle));
        button.setOnMousePressed(e -> button.setStyle(pressStyle));
        button.setOnMouseReleased(e -> button.setStyle(baseStyle));
    }
}