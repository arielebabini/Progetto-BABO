package org.BABO.client.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * Gestisce la sidebar dell'applicazione
 */
public class Sidebar {

    private final boolean serverAvailable;
    private final AuthenticationManager authManager;
    private final MainWindow mainWindow;
    private VBox menuItemsBox;
    private int activeMenuIndex = 0;

    public Sidebar(boolean serverAvailable, AuthenticationManager authManager, MainWindow mainWindow) {
        this.serverAvailable = serverAvailable;
        this.authManager = authManager;
        this.mainWindow = mainWindow;
    }

    public VBox createSidebar() {
        VBox sidebar = new VBox(15);
        sidebar.setPrefWidth(200);
        sidebar.setPrefHeight(700);
        sidebar.setStyle("-fx-background-color: #2c2c2e;");

        // Header
        Label sidebarHeader = new Label("📚 Libreria");
        sidebarHeader.setFont(Font.font("System", FontWeight.BOLD, 16));
        sidebarHeader.setTextFill(Color.WHITE);
        sidebarHeader.setPadding(new Insets(20, 0, 5, 20));

        // Menu items
        menuItemsBox = createMenuItems();

        // Spacer
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        // Status server
        Label serverStatus = new Label(serverAvailable ? "🟢 Server Online" : "🔴 Modalità Offline");
        serverStatus.setTextFill(serverAvailable ? Color.LIGHTGREEN : Color.ORANGE);
        serverStatus.setFont(Font.font("System", 12));
        serverStatus.setPadding(new Insets(10, 20, 10, 20));

        // Auth button
        Button authButton = createAuthButton();

        sidebar.getChildren().addAll(sidebarHeader, menuItemsBox, spacer, serverStatus, authButton);
        return sidebar;
    }

    private VBox createMenuItems() {
        VBox menuBox = new VBox(5);
        menuBox.setPadding(new Insets(10, 0, 0, 15));

        String[] menuItems = {"🏠 Home", "🏪 Book Store", "🎧 Audiobook Store",
                "📖 Tutto", "🔍 Ricerca Avanzata", "✅ Letti", "📄 PDF"};

        for (int i = 0; i < menuItems.length; i++) {
            HBox itemBox = createMenuItem(menuItems[i], i == 0);
            final int index = i;

            // Aggiungi click handler per i menu items
            if (menuItems[i].contains("Home")) {
                itemBox.setOnMouseClicked(e -> {
                    System.out.println("🏠 Click su Home");
                    updateActiveMenuItem(index);
                    try {
                        mainWindow.showHomePage();
                    } catch (Exception ex) {
                        System.err.println("❌ Errore showHomePage: " + ex.getMessage());
                    }
                });
            } else if (menuItems[i].contains("Ricerca Avanzata")) {
                itemBox.setOnMouseClicked(e -> {
                    System.out.println("🔍 Click su Ricerca Avanzata");
                    updateActiveMenuItem(index);
                    try {
                        mainWindow.showAdvancedSearch();
                    } catch (Exception ex) {
                        System.err.println("❌ Errore showAdvancedSearch: " + ex.getMessage());
                    }
                });
            } else {
                // Altri menu items - per ora solo log
                int finalI = i;
                itemBox.setOnMouseClicked(e -> {
                    System.out.println("📋 Click su: " + menuItems[finalI]);
                    updateActiveMenuItem(index);
                });
            }

            menuBox.getChildren().add(itemBox);
        }

        return menuBox;
    }

    private HBox createMenuItem(String text, boolean isActive) {
        HBox itemBox = new HBox(10);
        Label label = new Label(text);
        label.setTextFill(isActive ? Color.WHITE : Color.LIGHTGRAY);
        label.setFont(Font.font("System", 14));

        itemBox.getChildren().add(label);
        itemBox.setAlignment(Pos.CENTER_LEFT);
        itemBox.setPadding(new Insets(8, 10, 8, 10));
        itemBox.setStyle("-fx-cursor: hand;");

        if (isActive) {
            itemBox.setStyle("-fx-background-color: #3a3a3c; -fx-background-radius: 5; -fx-cursor: hand;");
        }

        // Hover effects semplificati
        itemBox.setOnMouseEntered(e -> {
            if (!itemBox.getStyle().contains("#3a3a3c")) {
                itemBox.setStyle("-fx-background-color: rgba(58, 58, 60, 0.5); -fx-background-radius: 5; -fx-cursor: hand;");
            }
        });

        itemBox.setOnMouseExited(e -> {
            // Non modificare se è l'elemento attivo
            if (!isActiveItem(itemBox)) {
                itemBox.setStyle("-fx-cursor: hand;");
            }
        });

        return itemBox;
    }

    private boolean isActiveItem(HBox itemBox) {
        return itemBox.getStyle().contains("#3a3a3c") && !itemBox.getStyle().contains("rgba");
    }

    private Button createAuthButton() {
        Button authButton = new Button(authManager.isAuthenticated() ?
                "👤 Profilo Utente" : "🔑 Accedi / Registrati");

        authButton.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #4a86e8;" +
                        "-fx-border-color: #4a86e8;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-cursor: hand;" +
                        "-fx-padding: 8 15;" +
                        "-fx-font-size: 12px;"
        );
        authButton.setMaxWidth(Double.MAX_VALUE);
        authButton.setAlignment(Pos.CENTER);

        // Event handler
        authButton.setOnAction(e -> {
            if (authManager.isAuthenticated()) {
                authManager.showUserProfileOptions();
            } else {
                mainWindow.showAuthPanel();
            }
        });

        // Hover effects
        setupButtonHoverEffects(authButton);

        VBox.setMargin(authButton, new Insets(0, 15, 15, 15));
        return authButton;
    }

    private void setupButtonHoverEffects(Button button) {
        String baseStyle =
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #4a86e8;" +
                        "-fx-border-color: #4a86e8;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-cursor: hand;" +
                        "-fx-padding: 8 15;" +
                        "-fx-font-size: 12px;";

        String hoverStyle = baseStyle.replace("transparent", "rgba(74, 134, 232, 0.1)");
        String pressStyle = baseStyle.replace("#4a86e8", "derive(#4a86e8, -20%)");

        button.setOnMouseEntered(e -> button.setStyle(hoverStyle));
        button.setOnMouseExited(e -> button.setStyle(baseStyle));
        button.setOnMousePressed(e -> button.setStyle(pressStyle));
        button.setOnMouseReleased(e -> button.setStyle(baseStyle));
    }

    private void updateActiveMenuItem(int newActiveIndex) {
        if (menuItemsBox == null || menuItemsBox.getChildren().isEmpty()) {
            return;
        }

        // Rimuovi lo stato attivo da tutti gli elementi
        for (int i = 0; i < menuItemsBox.getChildren().size(); i++) {
            HBox item = (HBox) menuItemsBox.getChildren().get(i);
            Label label = (Label) item.getChildren().get(0);

            if (i == newActiveIndex) {
                // Imposta come attivo
                item.setStyle("-fx-background-color: #3a3a3c; -fx-background-radius: 5; -fx-cursor: hand;");
                label.setTextFill(Color.WHITE);
            } else {
                // Rimuovi stato attivo
                item.setStyle("-fx-cursor: hand;");
                label.setTextFill(Color.LIGHTGRAY);
            }
        }

        activeMenuIndex = newActiveIndex;
        System.out.println("📋 Menu attivo aggiornato: indice " + newActiveIndex);
    }

    /**
     * Metodo pubblico per aggiornare lo stato attivo dal MainWindow
     */
    public void setActiveMenuItem(int index) {
        updateActiveMenuItem(index);
    }

    /**
     * Ottieni l'indice del menu attivo
     */
    public int getActiveMenuIndex() {
        return activeMenuIndex;
    }
}