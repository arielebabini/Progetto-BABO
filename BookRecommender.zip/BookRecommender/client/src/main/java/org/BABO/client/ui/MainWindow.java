package org.BABO.client.ui;

import org.BABO.shared.model.Book;
import org.BABO.client.service.BookService;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Gestisce la finestra principale dell'applicazione
 * Coordina tutti i componenti UI principali
 */
public class MainWindow {

    private final BookService bookService;
    private final boolean serverAvailable;
    private List<Book> cachedBooks = new ArrayList<>();
    private StackPane mainRoot;
    private Sidebar sidebar;
    private Header header;
    private ContentArea contentArea;
    private AuthenticationManager authManager;

    public MainWindow(BookService bookService, boolean serverAvailable) {
        this.bookService = bookService;
        this.serverAvailable = serverAvailable;
        this.authManager = new AuthenticationManager();

        // Inizializza l'autenticazione
        initializeAuthentication();
    }

    /**
     * Inizializza il sistema di autenticazione e configura i callback
     */
    private void initializeAuthentication() {
        // Configura callback per aggiornare sidebar quando cambia stato auth
        authManager.setOnAuthStateChanged(() -> {
            if (sidebar != null) {
                sidebar.refreshAuthSection();
            }
        });

        // Inizializza auth manager
        authManager.initialize();
    }

    public StackPane createMainLayout() {
        mainRoot = new StackPane();
        BorderPane appRoot = new BorderPane();

        // Crea i componenti principali
        sidebar = new Sidebar(serverAvailable, authManager, this);
        header = new Header();
        contentArea = new ContentArea(bookService, serverAvailable);

        // Handler per i click sui libri
        Consumer<Book> bookClickHandler = selectedBook -> {
            StackPane popupPane = BookDetailsPopup.create(
                    selectedBook,
                    cachedBooks.isEmpty() ? List.of(selectedBook) : cachedBooks,
                    () -> {
                        // Chiudi il popup rimuovendolo dal mainRoot
                        if (mainRoot.getChildren().size() > 1) {
                            mainRoot.getChildren().remove(mainRoot.getChildren().size() - 1);
                        }
                    }
            );
            // Aggiungi il popup sopra l'interfaccia principale
            mainRoot.getChildren().add(popupPane);
        };

        // Configura la ricerca
        header.setSearchHandler((query) -> {
            contentArea.handleSearch(query, bookClickHandler);
        });

        // Configura il content area
        contentArea.setBookClickHandler(bookClickHandler);
        contentArea.setCachedBooksCallback(books -> this.cachedBooks = books);

        // Assembla il layout
        appRoot.setLeft(sidebar.createSidebar());
        VBox centerBox = new VBox();
        centerBox.setStyle("-fx-background-color: #1e1e1e;");
        centerBox.getChildren().addAll(header.createHeader(), contentArea.createContentArea());
        appRoot.setCenter(centerBox);

        // Carica il contenuto DOPO aver creato l'area contenuti
        contentArea.loadInitialContent();

        mainRoot.getChildren().add(appRoot);
        return mainRoot;
    }

    public void showAuthPanel() {
        authManager.showAuthPanel(mainRoot);
    }

    public void showHomePage() {
        // Chiudi eventuali popup aperti
        while (mainRoot.getChildren().size() > 1) {
            mainRoot.getChildren().remove(mainRoot.getChildren().size() - 1);
        }

        // Ricarica il contenuto principale
        contentArea.loadInitialContent();

        // Pulisci il campo di ricerca
        header.clearSearch();

        System.out.println("🏠 Tornato alla home page");
    }

    public void showAdvancedSearch() {
        AdvancedSearchPanel searchPanel = new AdvancedSearchPanel(bookService);

        // Configura il callback per i risultati di ricerca
        searchPanel.setOnSearchExecuted(searchResult -> {
            // Chiudi il pannello di ricerca
            if (mainRoot.getChildren().size() > 1) {
                mainRoot.getChildren().remove(mainRoot.getChildren().size() - 1);
            }

            // Mostra i risultati nell'area contenuti
            contentArea.showSearchResults(searchResult);
        });

        // Crea overlay
        StackPane overlay = new StackPane();
        overlay.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7);");
        overlay.getChildren().add(searchPanel);
        StackPane.setAlignment(searchPanel, javafx.geometry.Pos.CENTER);

        // Chiudi cliccando sullo sfondo
        overlay.setOnMouseClicked(e -> {
            if (e.getTarget() == overlay) {
                if (mainRoot.getChildren().size() > 1) {
                    mainRoot.getChildren().remove(mainRoot.getChildren().size() - 1);
                }
            }
        });

        // Previeni chiusura cliccando sul pannello
        searchPanel.setOnMouseClicked(e -> e.consume());

        mainRoot.getChildren().add(overlay);
        System.out.println("🔍 Pannello ricerca avanzata aperto");
    }

    public StackPane getMainRoot() {
        return mainRoot;
    }
}