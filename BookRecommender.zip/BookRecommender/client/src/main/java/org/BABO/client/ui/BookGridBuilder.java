package org.BABO.client.ui;

import org.BABO.shared.model.Book;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Builder per la creazione e popolamento delle griglie di libri
 */
public class BookGridBuilder {

    private Consumer<Book> bookClickHandler;
    private Consumer<List<Book>> cachedBooksCallback;

    public void setBookClickHandler(Consumer<Book> handler) {
        this.bookClickHandler = handler;
    }

    public void setCachedBooksCallback(Consumer<List<Book>> callback) {
        this.cachedBooksCallback = callback;
    }

    /**
     * Popola la griglia dei libri con i dati ricevuti dal server
     */
    public void populateBookGrid(List<Book> books, FlowPane bookGrid, ScrollPane scroll) {
        bookGrid.getChildren().clear();

        if (books.isEmpty()) {
            if (scroll != null) {
                showNoBooksMessage(scroll);
            }
            return;
        }

        for (Book book : books) {
            VBox bookBox = createBookCard(book);
            bookGrid.getChildren().add(bookBox);
        }

        // Cache dei libri per uso futuro
        if (!books.isEmpty() && cachedBooksCallback != null) {
            cachedBooksCallback.accept(new ArrayList<>(books));
        }

        if (scroll != null) {
            scroll.setContent(bookGrid);
        }
    }

    /**
     * Crea una card per un singolo libro
     */
    private VBox createBookCard(Book book) {
        VBox bookBox = new VBox(8);
        bookBox.setAlignment(Pos.TOP_CENTER);
        bookBox.setMaxWidth(120);

        ImageView cover = ImageUtils.createSafeImageView(book.getImageUrl(), 110, 165);

        Rectangle clip = new Rectangle(110, 165);
        clip.setArcWidth(8);
        clip.setArcHeight(8);
        cover.setClip(clip);

        // Aggiungi click handler
        if (bookClickHandler != null) {
            cover.setOnMouseClicked(e -> bookClickHandler.accept(book));
            cover.setStyle("-fx-cursor: hand;");
        }

        Label bookTitle = new Label(book.getTitle());
        bookTitle.setWrapText(true);
        bookTitle.setMaxWidth(110);
        bookTitle.setTextFill(Color.WHITE);
        bookTitle.setFont(Font.font("System", FontWeight.NORMAL, 13));

        Label bookAuthor = new Label(book.getAuthor());
        bookAuthor.setWrapText(true);
        bookAuthor.setMaxWidth(110);
        bookAuthor.setTextFill(Color.gray(0.7));
        bookAuthor.setFont(Font.font("System", FontWeight.NORMAL, 12));

        bookBox.getChildren().addAll(cover, bookTitle, bookAuthor);
        return bookBox;
    }

    /**
     * Mostra messaggio quando non ci sono libri
     */
    private void showNoBooksMessage(ScrollPane scroll) {
        Label noBooks = new Label("📚 Nessun libro disponibile");
        noBooks.setTextFill(Color.GRAY);
        noBooks.setFont(Font.font("System", 16));

        VBox noBooksBox = new VBox(noBooks);
        noBooksBox.setAlignment(Pos.CENTER);
        noBooksBox.setPrefHeight(280);

        scroll.setContent(noBooksBox);
    }
}