package org.BABO.client.ui;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.BABO.shared.model.Book;
import org.BABO.shared.model.BookRating;
import org.BABO.shared.dto.RatingResponse;
import org.BABO.client.service.LibraryService;
import org.BABO.client.service.ClientRatingService;
import org.BABO.shared.dto.LibraryResponse;
import javafx.application.Platform;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.effect.BoxBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
/**
 * Popup per mostrare i dettagli di un libro
 * Aggiornato per gestire ISBN e titolo separatamente
 * Aggiornato con supporto per le librerie personali
 * Aggiornato con sistema di valutazioni completo
 */
public class BookDetailsPopup {

    private static StackPane root;
    private static List<Book> booksCollection;
    private static int currentBookIndex = 0;
    private static StackPane bookDisplayPane;
    private static VBox nextBookPreview;
    private static VBox prevBookPreview;
    private static Timeline slideAnimation;
    private static Runnable closeHandler;
    private static boolean isTransitioning = false;
    private static Button leftArrowButton;
    private static Button rightArrowButton;

    // Variabili per il sistema di valutazioni
    private static ClientRatingService ratingService = new ClientRatingService();
    private static BookRating currentUserRating = null;
    private static Double averageBookRating = null;
    private static Label averageRatingLabel = null;
    private static VBox userRatingContainer = null;

    private static VBox currentRatingSection = null;
    private static AuthenticationManager currentAuthManager = null;
    private static Book currentBook = null;

    public static StackPane create(Book book, List<Book> collection, Runnable onClose) {
        return createWithLibrarySupport(book, collection, onClose, null);
    }

    public static StackPane createWithLibrarySupport(Book book, List<Book> collection, Runnable onClose,
                                                     AuthenticationManager authManager) {
        booksCollection = collection;
        closeHandler = onClose;

        // Find current book index
        currentBookIndex = collection.indexOf(book);
        if (currentBookIndex == -1) currentBookIndex = 0;

        // Reset valutazioni per il nuovo libro
        resetRatings();

        // Salva riferimenti per il refresh delle valutazioni
        currentBook = book;
        currentAuthManager = authManager;

        // MAIN CONTAINER
        root = new StackPane();

        // Load the cover image for color extraction
        Image coverImage = ImageUtils.loadSafeImage(book.getImageUrl());
        Color dominantColor = extractDominantColor(coverImage);
        Color darkenedColor = darkenColor(dominantColor, 0.7);

        String backgroundColor = toHexString(darkenedColor);

        // Background
        StackPane blurLayer = new StackPane();
        blurLayer.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7);");
        blurLayer.setEffect(new BoxBlur(20, 20, 3));
        blurLayer.setOnMouseClicked((MouseEvent e) -> {
            if (closeHandler != null) {
                closeHandler.run();
            }
        });

        // Book display pane
        bookDisplayPane = new StackPane();

        // Current book container
        VBox currentBookContent = createBookContent(book, backgroundColor, authManager);

        // Carica le valutazioni per il libro se l'utente è autenticato
        loadBookRatingsForAllUsers(book, authManager);

        // Solo crea preview e navigazione se ci sono più libri
        if (collection.size() > 1) {
            // Preview containers
            nextBookPreview = createBookPreview(currentBookIndex + 1);
            nextBookPreview.setTranslateX(1200);

            prevBookPreview = createBookPreview(currentBookIndex - 1);
            prevBookPreview.setTranslateX(-1200);

            bookDisplayPane.getChildren().addAll(prevBookPreview, currentBookContent, nextBookPreview);

            // Solo aggiungi navigazione se ci sono più libri
            addEdgeDetection(bookDisplayPane);
            addNavigationArrows();
        } else {
            // Libro singolo - nessuna navigazione
            bookDisplayPane.getChildren().add(currentBookContent);
            System.out.println("📖 Popup libro singolo: " + book.getTitle() + " (nessuna navigazione)");
        }

        root.getChildren().addAll(blurLayer, bookDisplayPane);

        return root;
    }

    private static VBox createBookContent(Book book, String backgroundColor, AuthenticationManager authManager) {
        VBox popupContent = new VBox();
        popupContent.setMaxWidth(1000);
        popupContent.setMaxHeight(700);
        popupContent.setMinWidth(1000); // AGGIUNGI: Larghezza minima fissa
        popupContent.setStyle(
                "-fx-background-color: " + backgroundColor + ";" +
                        "-fx-background-radius: 10;" +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.4), 15, 0, 0, 5);"
        );

        // TOP BAR WITH CLOSE BUTTON
        HBox topBar = new HBox();
        topBar.setPadding(new Insets(10));
        topBar.setAlignment(Pos.CENTER_RIGHT);

        Button closeButton = new Button("×");
        closeButton.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #999999;" +
                        "-fx-font-size: 20;" +
                        "-fx-cursor: hand;"
        );
        closeButton.setOnAction(e -> {
            if (closeHandler != null) {
                closeHandler.run();
            }
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button addButton = new Button("+");
        addButton.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #999999;" +
                        "-fx-font-size: 20;" +
                        "-fx-cursor: hand;"
        );

        Button shareButton = new Button("⇧");
        shareButton.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #999999;" +
                        "-fx-font-size: 16;" +
                        "-fx-cursor: hand;"
        );

        Button moreButton = new Button("⋯");
        moreButton.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #999999;" +
                        "-fx-font-size: 16;" +
                        "-fx-cursor: hand;"
        );

        topBar.getChildren().addAll(closeButton, spacer, addButton, shareButton, moreButton);

        // BOOK DETAILS SECTION
        HBox detailsSection = new HBox(30);
        detailsSection.setPadding(new Insets(20, 30, 30, 30));
        detailsSection.setAlignment(Pos.TOP_LEFT);

        // Book cover with rounded corners
        ImageView cover = ImageUtils.createSafeImageView(book.getImageUrl(), 180, 270);
        Rectangle coverClip = new Rectangle(180, 270);
        coverClip.setArcWidth(8);
        coverClip.setArcHeight(8);
        cover.setClip(coverClip);

        VBox coverContainer = new VBox(cover);
        coverContainer.setAlignment(Pos.TOP_CENTER);

        // Book info
        VBox infoBox = new VBox(8);
        infoBox.setAlignment(Pos.TOP_LEFT);

        // Category badge
        Label categoryBadge = new Label("#1, BESTSELLER ❯");
        categoryBadge.setStyle(
                "-fx-background-color: #444;" +
                        "-fx-background-radius: 15;" +
                        "-fx-padding: 5 10;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 12;"
        );
        HBox badgeBox = new HBox(categoryBadge);
        badgeBox.setPadding(new Insets(0, 0, 5, 0));

        // Title
        Label title = new Label(book.getTitle());
        title.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 26));
        title.setTextFill(Color.WHITE);
        title.setWrapText(true);

        // Author
        Label author = new Label(book.getAuthor());
        author.setFont(Font.font("SF Pro Text", 18));
        author.setTextFill(Color.LIGHTGRAY);

        // Rating dinamico basato sui dati reali
        HBox ratingBox = new HBox(5);
        ratingBox.setPadding(new Insets(10, 0, 0, 0));

        averageRatingLabel = new Label("⭐ Caricamento...");
        averageRatingLabel.setTextFill(Color.WHITE);
        averageRatingLabel.setFont(Font.font("SF Pro Text", 14));

        Label ratingCategory = new Label("• Narrativa");
        ratingCategory.setTextFill(Color.LIGHTGRAY);
        ratingCategory.setFont(Font.font("SF Pro Text", 14));
        ratingCategory.setPadding(new Insets(0, 0, 0, 5));

        ratingBox.getChildren().addAll(averageRatingLabel, ratingCategory);

        // Book info box con ISBN e anno
        VBox bookInfoBox = new VBox(15);
        bookInfoBox.setPadding(new Insets(20, 0, 0, 0));

        Label infoLabel = new Label("📚 Libro Digitale");
        infoLabel.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 14));
        infoLabel.setTextFill(Color.WHITE);

        // Mostra ISBN se disponibile
        if (book.getIsbn() != null && !book.getIsbn().trim().isEmpty()) {
            Label isbnInfo = new Label("📄 ISBN: " + book.getIsbn());
            isbnInfo.setFont(Font.font("SF Pro Text", 14));
            isbnInfo.setTextFill(Color.LIGHTGRAY);
            bookInfoBox.getChildren().add(isbnInfo);
        }

        // Mostra anno di pubblicazione se disponibile
        if (book.getPublishYear() != null && !book.getPublishYear().trim().isEmpty()) {
            Label yearInfo = new Label("📅 Anno: " + book.getPublishYear());
            yearInfo.setFont(Font.font("SF Pro Text", 14));
            yearInfo.setTextFill(Color.LIGHTGRAY);
            bookInfoBox.getChildren().add(yearInfo);
        }

        Label pagesInfo = new Label("📄 ~300 pagine");
        pagesInfo.setFont(Font.font("SF Pro Text", 14));
        pagesInfo.setTextFill(Color.LIGHTGRAY);

        bookInfoBox.getChildren().addAll(infoLabel, pagesInfo);

        // Buttons
        HBox buttonBox = new HBox(10);
        buttonBox.setPadding(new Insets(20, 0, 0, 0));

        Button getButton = new Button("📖 Ottieni");
        getButton.setStyle(
                "-fx-background-color: white;" +
                        "-fx-text-fill: black;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 20;" +
                        "-fx-padding: 8 25;" +
                        "-fx-cursor: hand;"
        );

        Button previewButton = new Button("👁️ Estratto");
        previewButton.setStyle(
                "-fx-background-color: rgba(255,255,255,0.2);" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 20;" +
                        "-fx-padding: 8 25;" +
                        "-fx-cursor: hand;"
        );

        buttonBox.getChildren().addAll(getButton, previewButton);

        // Pulsante per aggiungere alle librerie (solo se autenticato)
        if (authManager != null && authManager.isAuthenticated()) {
            Button addToLibraryButton = new Button("📚 Aggiungi a Libreria");
            addToLibraryButton.setStyle(
                    "-fx-background-color: #9b59b6;" +
                            "-fx-text-fill: white;" +
                            "-fx-font-weight: bold;" +
                            "-fx-background-radius: 20;" +
                            "-fx-padding: 8 25;" +
                            "-fx-cursor: hand;"
            );

            addToLibraryButton.setOnAction(e -> showAddToLibraryDialog(book, authManager));
            buttonBox.getChildren().add(addToLibraryButton);
        }

        infoBox.getChildren().addAll(badgeBox, title, author, ratingBox, bookInfoBox, buttonBox);
        detailsSection.getChildren().addAll(coverContainer, infoBox);

        // PUBLISHER SECTION
        VBox publisherSection = new VBox(15);
        publisherSection.setPadding(new Insets(0, 30, 30, 30));

        Label publisherHeader = new Label("📝 Dall'editore");
        publisherHeader.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 20));
        publisherHeader.setTextFill(Color.WHITE);

        Text publisherText = new Text(book.getDescription() != null ? book.getDescription() : "Descrizione non disponibile per questo libro.");
        publisherText.setWrappingWidth(940);
        publisherText.setFill(Color.WHITE);
        publisherText.setFont(Font.font("SF Pro Text", 14));

        publisherSection.getChildren().addAll(publisherHeader, publisherText);

        // RATING SECTION
        VBox ratingSection = createRatingSection(book, authManager);

        // REVIEWS SECTION
        VBox reviewsSection = createReviewsSection();

        // Content area with scrollbar
        ScrollPane contentScroll = new ScrollPane() {
            @Override
            protected void layoutChildren() {
                super.layoutChildren();
                // Forza sempre posizione orizzontale a 0
                setHvalue(0.0);
            }
        };

        contentScroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        contentScroll.setFitToWidth(true);
        contentScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        contentScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        contentScroll.setPannable(false);

        // BLOCCO AGGIUNTIVO: Override delle proprietà di scroll orizzontale
        contentScroll.hvalueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.doubleValue() != 0.0) {
                contentScroll.setHvalue(0.0);
            }
        });

        // BLOCCO EVENTI SPECIFICI PER MOVIMENTO ORIZZONTALE
        contentScroll.addEventFilter(MouseEvent.MOUSE_DRAGGED, e -> {
            // Permetti solo drag verticale
            if (Math.abs(e.getX() - e.getSceneX()) > Math.abs(e.getY() - e.getSceneY())) {
                e.consume();
            }
        });

        contentScroll.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            // Salva posizione iniziale per calcolare direzione drag
            contentScroll.setUserData(new double[]{e.getX(), e.getY()});
        });

        VBox scrollContent = new VBox();
        scrollContent.getChildren().addAll(detailsSection, publisherSection, ratingSection, reviewsSection);
        contentScroll.setContent(scrollContent);

        popupContent.getChildren().addAll(topBar, contentScroll);

        return popupContent;
    }

    /**
     * Carica le valutazioni per tutti gli utenti (autenticati e non)
     * - Media del libro: sempre visibile
     * - Valutazione personale: solo se autenticato
     */
    private static void loadBookRatingsForAllUsers(Book book, AuthenticationManager authManager) {
        debugRatings(book, authManager != null && authManager.isAuthenticated() ? authManager.getCurrentUsername() : "GUEST");

        if (book.getIsbn() == null || book.getIsbn().trim().isEmpty()) {
            System.out.println("📝 Impossibile caricare valutazioni: ISBN mancante");
            updateRatingDisplaySafe();
            return;
        }

        System.out.println("⭐ Caricamento valutazioni per ISBN: " + book.getIsbn());

        // SEMPRE carica la media delle valutazioni del libro (pubblica)
        ratingService.getBookAverageRatingAsync(book.getIsbn())
                .thenAccept(response -> {
                    System.out.println("🔍 Callback getAverageRating ricevuto per: " + book.getTitle());
                    Platform.runLater(() -> {
                        if (response.isSuccess() && response.getAverageRating() != null) {
                            averageBookRating = response.getAverageRating();
                            System.out.println("✅ Media libro caricata: " + averageBookRating);
                        } else {
                            averageBookRating = null;
                            System.out.println("📝 Nessuna media disponibile");
                        }

                        // Aggiorna display
                        updateRatingDisplaySafe();

                        // Refresh della sezione valutazioni
                        Platform.runLater(() -> {
                            refreshRatingSection();
                        });
                    });
                })
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        System.err.println("❌ Errore caricamento media libro: " + throwable.getMessage());
                        averageBookRating = null;
                        updateRatingDisplaySafe();
                    });
                    return null;
                });

        // SOLO se autenticato, carica la valutazione personale
        if (authManager != null && authManager.isAuthenticated()) {
            String username = authManager.getCurrentUsername();

            ratingService.getUserRatingForBookAsync(username, book.getIsbn())
                    .thenAccept(response -> {
                        System.out.println("🔍 Callback getUserRating ricevuto per: " + book.getTitle());
                        Platform.runLater(() -> {
                            if (response.isSuccess() && response.getRating() != null) {
                                currentUserRating = response.getRating();
                                System.out.println("✅ Valutazione utente caricata: " + currentUserRating.getDisplayRating());
                            } else {
                                currentUserRating = null;
                                System.out.println("📝 Nessuna valutazione utente trovata");
                            }

                            // Refresh della sezione valutazioni
                            Platform.runLater(() -> {
                                refreshRatingSection();
                            });
                        });
                    })
                    .exceptionally(throwable -> {
                        Platform.runLater(() -> {
                            System.err.println("❌ Errore caricamento valutazione utente: " + throwable.getMessage());
                            currentUserRating = null;
                            refreshRatingSection();
                        });
                        return null;
                    });
        } else {
            System.out.println("👤 Utente non autenticato - solo media pubblica");
            currentUserRating = null;
        }
    }

    //-------------------------------------------
    private static void debugRatings(Book book, String username) {
        System.out.println("=================== DEBUG VALUTAZIONI ===================");
        System.out.println("🔍 Libro: " + book.getTitle());
        System.out.println("🔍 ISBN: " + book.getIsbn());
        System.out.println("🔍 Username: " + username);
        System.out.println("🔍 RatingService inizializzato: " + (ratingService != null));
        System.out.println("🔍 AverageRatingLabel inizializzato: " + (averageRatingLabel != null));
        System.out.println("🔍 CurrentUserRating: " + currentUserRating);
        System.out.println("🔍 AverageBookRating: " + averageBookRating);
        System.out.println("🔍 CurrentBook == book: " + (currentBook != null && currentBook.equals(book)));

        if (book.getIsbn() == null || book.getIsbn().trim().isEmpty()) {
            System.out.println("📝 Impossibile caricare valutazioni: ISBN mancante");
            updateRatingDisplaySafe();
            return;
        }

        // Test connessione diretta
        if (ratingService != null) {
            System.out.println("🔍 Test connessione al server...");
            ratingService.healthCheckAsync()
                    .thenAccept(response -> {
                        Platform.runLater(() -> {
                            System.out.println("🔍 Health check risultato: " + response.isSuccess());
                            System.out.println("🔍 Health check messaggio: " + response.getMessage());
                        });
                    })
                    .exceptionally(ex -> {
                        System.err.println("❌ Errore health check: " + ex.getMessage());
                        return null;
                    });
        }
        System.out.println("=========================================================");
    }

    //-------------------------------------------

    /**
     * Carica le valutazioni per il libro corrente
     */
    private static void loadBookRatings(Book book, String username) {

        debugRatings(book, username);
        if (book.getIsbn() == null || book.getIsbn().trim().isEmpty()) {
            System.out.println("📝 Impossibile caricare valutazioni: ISBN mancante");
            updateRatingDisplaySafe();
            return;
        }

        System.out.println("⭐ Caricamento valutazioni per ISBN: " + book.getIsbn());

        // Carica valutazione dell'utente corrente
        ratingService.getUserRatingForBookAsync(username, book.getIsbn())
                .thenAccept(response -> {
                    System.out.println("🔍 Callback getUserRating ricevuto per: " + book.getTitle());
                    Platform.runLater(() -> {
                        if (response.isSuccess() && response.getRating() != null) {
                            currentUserRating = response.getRating();
                            System.out.println("✅ Valutazione utente caricata: " + currentUserRating.getDisplayRating());
                        } else {
                            currentUserRating = null;
                            System.out.println("📝 Nessuna valutazione utente trovata");
                        }

                        // FORZA L'AGGIORNAMENTO
                        updateRatingDisplaySafe();

                        // Aspetta un momento prima del refresh per dare tempo alla UI
                        Platform.runLater(() -> {
                            refreshRatingSection();
                        });
                    });
                })
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        System.err.println("❌ Errore caricamento valutazione utente: " + throwable.getMessage());
                        currentUserRating = null;
                        updateRatingDisplaySafe();
                    });
                    return null;
                });

        // Carica media delle valutazioni del libro
        ratingService.getBookAverageRatingAsync(book.getIsbn())
                .thenAccept(response -> {
                    System.out.println("🔍 Callback getAverageRating ricevuto per: " + book.getTitle());
                    Platform.runLater(() -> {
                        if (response.isSuccess() && response.getAverageRating() != null) {
                            averageBookRating = response.getAverageRating();
                            System.out.println("✅ Media libro caricata: " + averageBookRating);
                        } else {
                            averageBookRating = null;
                            System.out.println("📝 Nessuna media disponibile");
                        }

                        // FORZA L'AGGIORNAMENTO
                        updateRatingDisplaySafe();

                        // Aspetta un momento prima del refresh
                        Platform.runLater(() -> {
                            refreshRatingSection();
                        });
                    });
                })
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        System.err.println("❌ Errore caricamento media libro: " + throwable.getMessage());
                        averageBookRating = null;
                        updateRatingDisplaySafe();
                    });
                    return null;
                });
    }

    /**
     * Aggiorna la visualizzazione delle valutazioni nel popup
     */
    private static void updateRatingDisplay() {
        // Aggiorna la label della media nella sezione rating principale
        if (averageRatingLabel != null) {
            if (averageBookRating != null && averageBookRating > 0) {
                int stars = (int) Math.round(averageBookRating);
                String starsDisplay = "★".repeat(stars) + "☆".repeat(5 - stars);
                averageRatingLabel.setText(String.format("%s %.1f/5", starsDisplay, averageBookRating));
            } else {
                averageRatingLabel.setText("☆☆☆☆☆ Non ancora valutato");
            }
        }
    }

    private static void updateRatingDisplaySafe() {
        try {
            System.out.println("🔄 Updating rating display...");
            System.out.println("   averageBookRating: " + averageBookRating);
            System.out.println("   currentUserRating: " + (currentUserRating != null ? currentUserRating.getDisplayRating() : "null"));

            // Aggiorna la label della media nella sezione rating principale
            if (averageRatingLabel != null) {
                if (averageBookRating != null && averageBookRating > 0) {
                    int stars = (int) Math.round(averageBookRating);
                    String starsDisplay = "★".repeat(stars) + "☆".repeat(5 - stars);
                    String newText = String.format("%s %.1f/5 (%d recensioni)", starsDisplay, averageBookRating,
                            (int)(Math.random() * 50 + 10)); // Simula numero recensioni
                    averageRatingLabel.setText(newText);
                    System.out.println("✅ Updated average rating label: " + newText);
                } else {
                    averageRatingLabel.setText("☆☆☆☆☆ Non ancora valutato");
                    System.out.println("✅ Set to 'not rated'");
                }
            } else {
                System.out.println("❌ averageRatingLabel is null");
            }
        } catch (Exception e) {
            System.err.println("❌ Errore aggiornamento display rating: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void refreshRatingSection() {
        if (currentRatingSection != null && currentBook != null && currentAuthManager != null) {
            try {
                System.out.println("🔄 Refreshing rating section...");

                // Trova il parent container
                Parent parent = currentRatingSection.getParent();
                if (parent instanceof VBox) {
                    VBox parentVBox = (VBox) parent;
                    int index = parentVBox.getChildren().indexOf(currentRatingSection);

                    if (index >= 0) {
                        // Rimuovi la sezione vecchia
                        parentVBox.getChildren().remove(index);

                        // Crea la nuova sezione
                        VBox newRatingSection = createRatingSection(currentBook, currentAuthManager);

                        // Inserisci la nuova sezione nella stessa posizione
                        parentVBox.getChildren().add(index, newRatingSection);

                        System.out.println("✅ Rating section refreshed successfully");
                    } else {
                        System.out.println("❌ Could not find rating section index");
                    }
                } else {
                    System.out.println("❌ Parent is not a VBox: " + (parent != null ? parent.getClass() : "null"));
                }
            } catch (Exception e) {
                System.err.println("❌ Errore refresh sezione rating: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            System.out.println("❌ Missing references for refresh - currentRatingSection: " + (currentRatingSection != null) +
                    ", currentBook: " + (currentBook != null) +
                    ", currentAuthManager: " + (currentAuthManager != null));
        }
    }

    /**
     * Crea la sezione delle valutazioni
     */
    private static VBox createRatingSection(Book book, AuthenticationManager authManager) {
        VBox ratingSection = new VBox(15);
        ratingSection.setPadding(new Insets(0, 30, 30, 30));

        // Salva riferimento per il refresh
        currentRatingSection = ratingSection;

        // Header sezione
        HBox ratingHeaderBox = new HBox();
        Label ratingsHeader = new Label("⭐ Valutazioni");
        ratingsHeader.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 20));
        ratingsHeader.setTextFill(Color.WHITE);

        Region ratingSpacer = new Region();
        HBox.setHgrow(ratingSpacer, Priority.ALWAYS);
        ratingHeaderBox.getChildren().addAll(ratingsHeader, ratingSpacer);

        // Container per le valutazioni
        VBox ratingsContent = new VBox(12);

        // Media generale del libro (SEMPRE VISIBILE)
        HBox averageRatingBox = createAverageRatingDisplay();
        ratingsContent.getChildren().add(averageRatingBox);

        // Valutazione dell'utente corrente (SOLO SE AUTENTICATO)
        if (authManager != null && authManager.isAuthenticated()) {
            userRatingContainer = createUserRatingSection(book, authManager);
            ratingsContent.getChildren().add(userRatingContainer);
        } else {
            // Messaggio per invitare alla registrazione/login
            VBox guestInvite = createGuestInviteSection();
            ratingsContent.getChildren().add(guestInvite);
        }

        ratingSection.getChildren().addAll(ratingHeaderBox, ratingsContent);
        return ratingSection;
    }

    /**
     * Crea sezione per invitare gli utenti non autenticati a registrarsi
     */
    private static VBox createGuestInviteSection() {
        VBox guestSection = new VBox(10);
        guestSection.setStyle(
                "-fx-background-color: #444448;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;"
        );

        // Header
        HBox guestHeader = new HBox();
        guestHeader.setAlignment(Pos.CENTER_LEFT);

        Label guestTitle = new Label("🔐 Vuoi valutare questo libro?");
        guestTitle.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 16));
        guestTitle.setTextFill(Color.WHITE);

        guestHeader.getChildren().add(guestTitle);

        // Contenuto invito
        VBox guestContent = new VBox(8);

        Label inviteMessage = new Label("Registrati o accedi per valutare e recensire i tuoi libri preferiti");
        inviteMessage.setFont(Font.font("SF Pro Text", 14));
        inviteMessage.setTextFill(Color.LIGHTGRAY);
        inviteMessage.setWrapText(true);

        Label benefitMessage = new Label("✨ Condividi le tue opinioni con la community di lettori!");
        benefitMessage.setFont(Font.font("SF Pro Text", 12));
        benefitMessage.setTextFill(Color.LIGHTBLUE);

        guestContent.getChildren().addAll(inviteMessage, benefitMessage);

        guestSection.getChildren().addAll(guestHeader, guestContent);
        return guestSection;
    }

    /**
     * Crea la visualizzazione della media delle valutazioni
     */
    private static HBox createAverageRatingDisplay() {
        HBox averageBox = new HBox(15);
        averageBox.setStyle(
                "-fx-background-color: #3a3a3c;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;"
        );
        averageBox.setAlignment(Pos.CENTER_LEFT);

        VBox averageInfo = new VBox(5);

        Label averageTitle = new Label("📊 Valutazione della Community");
        averageTitle.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 16));
        averageTitle.setTextFill(Color.WHITE);

        Label averageValue = new Label("⭐ Caricamento...");
        averageValue.setFont(Font.font("SF Pro Text", 14));
        averageValue.setTextFill(Color.GRAY);

        // Aggiorna subito se i dati sono già disponibili
        if (averageBookRating != null && averageBookRating > 0) {
            int stars = (int) Math.round(averageBookRating);
            String starsDisplay = "★".repeat(stars) + "☆".repeat(5 - stars);
            averageValue.setText(String.format("%s %.1f/5", starsDisplay, averageBookRating));
            averageValue.setTextFill(Color.GOLD);
        }

        Label publicNote = new Label("Basata su tutte le recensioni degli utenti registrati");
        publicNote.setFont(Font.font("SF Pro Text", 12));
        publicNote.setTextFill(Color.GRAY);

        averageInfo.getChildren().addAll(averageTitle, averageValue, publicNote);
        averageBox.getChildren().add(averageInfo);

        return averageBox;
    }

    /**
     * Crea la sezione per la valutazione dell'utente
     */
    private static VBox createUserRatingSection(Book book, AuthenticationManager authManager) {
        VBox userSection = new VBox(10);
        userSection.setStyle(
                "-fx-background-color: #444448;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;"
        );

        // Header con titolo e pulsante azione
        HBox userHeader = new HBox();
        userHeader.setAlignment(Pos.CENTER_LEFT);

        Label userTitle = new Label("👤 La tua valutazione");
        userTitle.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 16));
        userTitle.setTextFill(Color.WHITE);

        Region userSpacer = new Region();
        HBox.setHgrow(userSpacer, Priority.ALWAYS);

        Button ratingActionButton = new Button();
        updateRatingButton(ratingActionButton);

        userHeader.getChildren().addAll(userTitle, userSpacer, ratingActionButton);

        // Contenuto valutazione utente
        VBox userContent = new VBox(8);
        updateUserContent(userContent);

        // Event handler per il pulsante
        ratingActionButton.setOnAction(e -> {
            if (book.getIsbn() == null || book.getIsbn().trim().isEmpty()) {
                showAlert("Errore", "Impossibile valutare: ISBN del libro mancante");
                return;
            }

            if (currentUserRating != null) {
                // Modifica valutazione esistente
                RatingDialog.showEditRatingDialog(book, authManager.getCurrentUsername(),
                        currentUserRating, updatedRating -> {
                            if (updatedRating == null) {
                                // Valutazione eliminata
                                currentUserRating = null;
                            } else {
                                // Valutazione aggiornata
                                currentUserRating = updatedRating;
                            }
                            // Ricarica le valutazioni per aggiornare anche la media
                            loadBookRatings(book, authManager.getCurrentUsername());
                        });
            } else {
                // Nuova valutazione
                RatingDialog.showRatingDialog(book, authManager.getCurrentUsername(),
                        newRating -> {
                            if (newRating != null) {
                                currentUserRating = newRating;
                                // Ricarica le valutazioni per aggiornare anche la media
                                loadBookRatings(book, authManager.getCurrentUsername());
                            }
                        });
            }
        });

        userSection.getChildren().addAll(userHeader, userContent);
        return userSection;
    }

    private static void updateRatingButton(Button ratingActionButton) {
        if (currentUserRating != null) {
            ratingActionButton.setText("Modifica");
            ratingActionButton.setStyle(
                    "-fx-background-color: #9b59b6;" +
                            "-fx-text-fill: white;" +
                            "-fx-font-weight: bold;" +
                            "-fx-background-radius: 15;" +
                            "-fx-padding: 5 15;" +
                            "-fx-cursor: hand;"
            );
        } else {
            ratingActionButton.setText("Valuta");
            ratingActionButton.setStyle(
                    "-fx-background-color: #4CAF50;" +
                            "-fx-text-fill: white;" +
                            "-fx-font-weight: bold;" +
                            "-fx-background-radius: 15;" +
                            "-fx-padding: 5 15;" +
                            "-fx-cursor: hand;"
            );
        }
    }

    private static void updateUserContent(VBox userContent) {
        userContent.getChildren().clear();

        if (currentUserRating != null) {
            // Mostra valutazione esistente
            Label userRatingDisplay = new Label(currentUserRating.getDisplayRating());
            userRatingDisplay.setFont(Font.font("SF Pro Text", 14));
            userRatingDisplay.setTextFill(Color.LIGHTGREEN);

            Label ratingBreakdown = new Label(String.format(
                    "Stile: %d★ | Contenuto: %d★ | Piacevolezza: %d★ | Originalità: %d★ | Edizione: %d★",
                    currentUserRating.getStyle(), currentUserRating.getContent(),
                    currentUserRating.getPleasantness(), currentUserRating.getOriginality(),
                    currentUserRating.getEdition()
            ));
            ratingBreakdown.setFont(Font.font("SF Pro Text", 12));
            ratingBreakdown.setTextFill(Color.LIGHTGRAY);

            userContent.getChildren().addAll(userRatingDisplay, ratingBreakdown);

            // Mostra recensione se presente
            if (currentUserRating.getReview() != null && !currentUserRating.getReview().trim().isEmpty()) {
                Label reviewLabel = new Label("💭 La tua recensione:");
                reviewLabel.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 12));
                reviewLabel.setTextFill(Color.WHITE);

                Text reviewText = new Text(currentUserRating.getReview());
                reviewText.setFont(Font.font("SF Pro Text", 12));
                reviewText.setFill(Color.LIGHTGRAY);
                reviewText.setWrappingWidth(400);

                userContent.getChildren().addAll(reviewLabel, reviewText);
            }
        } else {
            // Messaggio per invitare a valutare
            Label inviteLabel = new Label("Non hai ancora valutato questo libro");
            inviteLabel.setFont(Font.font("SF Pro Text", 14));
            inviteLabel.setTextFill(Color.LIGHTGRAY);

            Label benefitLabel = new Label("Condividi la tua opinione con altri lettori!");
            benefitLabel.setFont(Font.font("SF Pro Text", 12));
            benefitLabel.setTextFill(Color.GRAY);

            userContent.getChildren().addAll(inviteLabel, benefitLabel);
        }
    }

    // METODI PER LE LIBRERIE

    private static void showAddToLibraryDialog(Book book, AuthenticationManager authManager) {
        if (book.getIsbn() == null || book.getIsbn().trim().isEmpty()) {
            showAlert("❌ Errore", "Impossibile aggiungere il libro: ISBN mancante");
            return;
        }

        String username = authManager.getCurrentUsername();
        LibraryService libraryService = new LibraryService();

        libraryService.getUserLibrariesAsync(username)
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        if (response.isSuccess() && response.getLibraries() != null) {
                            List<String> libraries = response.getLibraries();

                            if (libraries.isEmpty()) {
                                showCreateFirstLibraryDialog(book, username, libraryService);
                            } else {
                                showChooseLibraryDialog(book, username, libraries, libraryService);
                            }
                        } else {
                            showAlert("❌ Errore", "Errore nel recupero delle librerie: " + response.getMessage());
                        }
                    });
                })
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        showAlert("❌ Errore", "Errore di connessione: " + throwable.getMessage());
                    });
                    return null;
                });
    }

    private static void showCreateFirstLibraryDialog(Book book, String username, LibraryService libraryService) {
        TextInputDialog dialog = new TextInputDialog("La mia libreria");
        dialog.setTitle("Crea la tua prima libreria");
        dialog.setHeaderText("Non hai ancora librerie. Creane una per '" + book.getTitle() + "'");
        dialog.setContentText("Nome libreria:");

        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e1e1e; -fx-text-fill: white;");

        dialog.showAndWait().ifPresent(libraryName -> {
            if (!libraryName.trim().isEmpty()) {
                libraryService.createLibraryAsync(username, libraryName.trim())
                        .thenCompose(createResponse -> {
                            if (createResponse.isSuccess()) {
                                return libraryService.addBookToLibraryAsync(username, libraryName.trim(), book.getIsbn());
                            } else {
                                return CompletableFuture.completedFuture(
                                        new LibraryResponse(false, "Errore nella creazione: " + createResponse.getMessage())
                                );
                            }
                        })
                        .thenAccept(addResponse -> {
                            Platform.runLater(() -> {
                                if (addResponse.isSuccess()) {
                                    showAlert("✅ Successo",
                                            "Libreria '" + libraryName.trim() + "' creata e libro aggiunto!");
                                } else {
                                    showAlert("❌ Errore", addResponse.getMessage());
                                }
                            });
                        });
            }
        });
    }

    private static void showChooseLibraryDialog(Book book, String username, List<String> libraries,
                                                LibraryService libraryService) {
        List<String> choices = new ArrayList<>(libraries);
        choices.add(0, "➕ Crea nuova libreria...");

        ChoiceDialog<String> dialog = new ChoiceDialog<>(libraries.get(0), choices);
        dialog.setTitle("Aggiungi a Libreria");
        dialog.setHeaderText("Scegli dove aggiungere '" + book.getTitle() + "'");
        dialog.setContentText("Libreria:");

        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e1e1e; -fx-text-fill: white;");

        dialog.showAndWait().ifPresent(choice -> {
            if (choice.startsWith("➕")) {
                showCreateNewLibraryDialog(book, username, libraryService);
            } else {
                addBookToExistingLibrary(book, username, choice, libraryService);
            }
        });
    }

    private static void showCreateNewLibraryDialog(Book book, String username, LibraryService libraryService) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Crea Nuova Libreria");
        dialog.setHeaderText("Crea una nuova libreria per '" + book.getTitle() + "'");
        dialog.setContentText("Nome libreria:");

        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e1e1e; -fx-text-fill: white;");

        dialog.showAndWait().ifPresent(libraryName -> {
            if (!libraryName.trim().isEmpty()) {
                libraryService.createLibraryAsync(username, libraryName.trim())
                        .thenCompose(createResponse -> {
                            if (createResponse.isSuccess()) {
                                return libraryService.addBookToLibraryAsync(username, libraryName.trim(), book.getIsbn());
                            } else {
                                return CompletableFuture.completedFuture(
                                        new LibraryResponse(false, "Errore nella creazione: " + createResponse.getMessage())
                                );
                            }
                        })
                        .thenAccept(addResponse -> {
                            Platform.runLater(() -> {
                                if (addResponse.isSuccess()) {
                                    showAlert("✅ Successo",
                                            "Libreria '" + libraryName.trim() + "' creata e libro aggiunto!");
                                } else {
                                    showAlert("❌ Errore", addResponse.getMessage());
                                }
                            });
                        });
            }
        });
    }

    private static void addBookToExistingLibrary(Book book, String username, String libraryName,
                                                 LibraryService libraryService) {
        libraryService.addBookToLibraryAsync(username, libraryName, book.getIsbn())
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        if (response.isSuccess()) {
                            showAlert("✅ Successo", "Libro aggiunto alla libreria '" + libraryName + "'!");
                        } else {
                            showAlert("❌ Errore", response.getMessage());
                        }
                    });
                });
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);

        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e1e1e; -fx-text-fill: white;");

        alert.showAndWait();
    }

    // METODI PER PREVIEW E NAVIGAZIONE

    private static VBox createBookPreview(int bookIndex) {
        if (bookIndex < 0 || booksCollection == null || bookIndex >= booksCollection.size()) {
            VBox emptyPreview = new VBox();
            emptyPreview.setVisible(false);
            emptyPreview.setManaged(false);
            return emptyPreview;
        }

        Book previewBook = booksCollection.get(bookIndex);

        Image coverImage = ImageUtils.loadSafeImage(previewBook.getImageUrl());
        Color dominantColor = extractDominantColor(coverImage);
        Color darkenedColor = darkenColor(dominantColor, 0.7);
        String backgroundColor = toHexString(darkenedColor);

        VBox previewContent = new VBox();
        previewContent.setMaxWidth(1000);
        previewContent.setMaxHeight(700);
        previewContent.setOpacity(0.95);
        previewContent.setStyle(
                "-fx-background-color: " + backgroundColor + ";" +
                        "-fx-background-radius: 10;" +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.4), 15, 0, 0, 5);"
        );

        HBox topBar = new HBox();
        topBar.setPadding(new Insets(10));

        HBox detailsSection = new HBox(30);
        detailsSection.setPadding(new Insets(20, 30, 30, 30));
        detailsSection.setAlignment(Pos.TOP_LEFT);

        ImageView cover = ImageUtils.createSafeImageView(previewBook.getImageUrl(), 180, 270);
        Rectangle coverClip = new Rectangle(180, 270);
        coverClip.setArcWidth(8);
        coverClip.setArcHeight(8);
        cover.setClip(coverClip);

        VBox coverContainer = new VBox(cover);
        coverContainer.setAlignment(Pos.TOP_CENTER);

        VBox infoBox = new VBox(8);
        infoBox.setAlignment(Pos.TOP_LEFT);

        Label title = new Label(previewBook.getTitle());
        title.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 26));
        title.setTextFill(Color.WHITE);
        title.setWrapText(true);

        Label author = new Label(previewBook.getAuthor());
        author.setFont(Font.font("SF Pro Text", 18));
        author.setTextFill(Color.LIGHTGRAY);

        infoBox.getChildren().addAll(title, author);
        detailsSection.getChildren().addAll(coverContainer, infoBox);

        ScrollPane contentScroll = new ScrollPane();
        contentScroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        contentScroll.setFitToWidth(true);

        VBox scrollContent = new VBox();
        scrollContent.getChildren().addAll(detailsSection);
        contentScroll.setContent(scrollContent);

        previewContent.getChildren().addAll(topBar, contentScroll);
        return previewContent;
    }

    private static VBox createReviewsSection() {
        VBox reviewsSection = new VBox(15);
        reviewsSection.setPadding(new Insets(0, 30, 30, 30));

        HBox reviewHeaderBox = new HBox();
        Label reviewsHeader = new Label("💬 Recensioni della community");
        reviewsHeader.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 20));
        reviewsHeader.setTextFill(Color.WHITE);

        Label seeMoreReviews = new Label("Vedi tutte ❯");
        seeMoreReviews.setFont(Font.font("SF Pro Text", 14));
        seeMoreReviews.setTextFill(Color.LIGHTBLUE);
        seeMoreReviews.setStyle("-fx-cursor: hand;");
        seeMoreReviews.setOnMouseClicked(e -> {
            if (currentBook != null) {
                showAllReviewsDialog(currentBook);
            }
        });

        Region reviewSpacer = new Region();
        HBox.setHgrow(reviewSpacer, Priority.ALWAYS);
        reviewHeaderBox.getChildren().addAll(reviewsHeader, reviewSpacer, seeMoreReviews);

        // Container per le recensioni con scroll orizzontale
        ScrollPane reviewsScrollPane = new ScrollPane();
        reviewsScrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        reviewsScrollPane.setFitToHeight(true);
        reviewsScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER); // No scroll verticale
        reviewsScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED); // Scroll orizzontale quando necessario
        reviewsScrollPane.setPannable(true); // Permetti panning per touch devices
        reviewsScrollPane.setPrefHeight(200); // Altezza fissa

        HBox reviewsContainer = new HBox(15); // Cambiato da VBox a HBox per layout orizzontale
        reviewsContainer.setPadding(new Insets(10, 0, 10, 0));

        reviewsScrollPane.setContent(reviewsContainer);

        // Carica e mostra le recensioni reali
        loadCommunityReviews(reviewsContainer); // Passa HBox invece di VBox

        reviewsSection.getChildren().addAll(reviewHeaderBox, reviewsScrollPane);
        return reviewsSection;
    }


    /**
     * Carica le recensioni della community per il libro corrente
     */
    private static void loadCommunityReviews(HBox container) { // Cambiato da VBox a HBox
        if (currentBook == null || currentBook.getIsbn() == null) {
            showNoReviewsMessage(container);
            return;
        }

        System.out.println("📖 Caricamento recensioni community per: " + currentBook.getTitle());

        // Mostra messaggio di caricamento temporaneo
        Label loadingLabel = new Label("📖 Caricamento recensioni...");
        loadingLabel.setFont(Font.font("SF Pro Text", 14));
        loadingLabel.setTextFill(Color.GRAY);
        loadingLabel.setStyle("-fx-padding: 20;");
        container.getChildren().add(loadingLabel);

        // Carica recensioni dal server
        ratingService.getBookRatingsAsync(currentBook.getIsbn())
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        container.getChildren().clear(); // Rimuovi messaggio caricamento

                        if (response.isSuccess() && response.getRatings() != null && !response.getRatings().isEmpty()) {
                            // Filtra recensioni con testo
                            List<BookRating> reviewsWithText = response.getRatings().stream()
                                    .filter(rating -> rating.getReview() != null && !rating.getReview().trim().isEmpty())
                                    .filter(rating -> currentAuthManager == null ||
                                            !rating.getUsername().equals(currentAuthManager.getCurrentUsername()))
                                    .sorted((r1, r2) -> Double.compare(r2.getAverage(), r1.getAverage()))
                                    .limit(5) // Aumentato da 3 a 5 per il layout orizzontale
                                    .collect(Collectors.toList());

                            if (!reviewsWithText.isEmpty()) {
                                // Aggiungi le recensioni direttamente all'HBox
                                for (BookRating rating : reviewsWithText) {
                                    VBox reviewCard = createCommunityReviewCard(rating);
                                    container.getChildren().add(reviewCard);
                                }

                                System.out.println("✅ Mostrate " + reviewsWithText.size() + " recensioni community");
                            } else {
                                showNoReviewsMessage(container);
                            }
                        } else {
                            showNoReviewsMessage(container);
                        }
                    });
                })
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        container.getChildren().clear();
                        showErrorMessage(container, "Errore nel caricamento delle recensioni");
                        System.err.println("❌ Errore caricamento recensioni: " + throwable.getMessage());
                    });
                    return null;
                });
    }


    /**
     * Crea una card per una recensione della community
     */
    private static VBox createCommunityReviewCard(BookRating rating) {
        VBox card = new VBox(8);
        card.setStyle(
                "-fx-background-color: #3a3a3c;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;"
        );
        card.setPrefWidth(280); // Ridotto da 350 per permettere più cards visibili
        card.setMaxWidth(280);
        card.setPrefHeight(180); // Altezza fissa per uniformità

        // Header con rating e username
        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);

        // Stelle del rating
        String stars = "★".repeat(rating.getStarRating()) + "☆".repeat(5 - rating.getStarRating());
        Label starsLabel = new Label(stars);
        starsLabel.setFont(Font.font("SF Pro Text", 14)); // Ridotto da 16
        starsLabel.setTextFill(Color.GOLD);

        // Username (anonimizzato)
        String displayName = rating.getUsername().length() > 3 ?
                rating.getUsername().substring(0, 3) + "***" :
                "***";
        Label usernameLabel = new Label("di " + displayName);
        usernameLabel.setFont(Font.font("SF Pro Text", 10)); // Ridotto da 12
        usernameLabel.setTextFill(Color.LIGHTGRAY);

        header.getChildren().addAll(starsLabel, usernameLabel);

        // Testo della recensione (troncato per il layout orizzontale)
        String reviewText = rating.getReview();
        if (reviewText.length() > 120) { // Ridotto da 150
            reviewText = reviewText.substring(0, 117) + "...";
        }

        Text reviewContent = new Text(reviewText);
        reviewContent.setFont(Font.font("SF Pro Text", 12)); // Ridotto da 14
        reviewContent.setFill(Color.WHITE);
        reviewContent.setWrappingWidth(250); // Ridotto da 320

        // Data
        Label dateLabel = new Label(getRelativeDate(rating.getData()));
        dateLabel.setFont(Font.font("SF Pro Text", 10)); // Ridotto da 12
        dateLabel.setTextFill(Color.GRAY);

        card.getChildren().addAll(header, reviewContent, dateLabel);
        return card;
    }

    /**
     * Mostra messaggio quando non ci sono recensioni
     */
    private static void showNoReviewsMessage(HBox container) { // Cambiato da VBox a HBox
        Label noReviewsLabel = new Label("📝 Nessuna recensione ancora disponibile");
        noReviewsLabel.setFont(Font.font("SF Pro Text", 14));
        noReviewsLabel.setTextFill(Color.GRAY);
        noReviewsLabel.setStyle("-fx-padding: 20;");
        container.getChildren().add(noReviewsLabel);
    }

    /**
     * Mostra messaggio di errore
     */
    private static void showErrorMessage(HBox container, String message) { // Cambiato da VBox a HBox
        Label errorLabel = new Label("❌ " + message);
        errorLabel.setFont(Font.font("SF Pro Text", 14));
        errorLabel.setTextFill(Color.LIGHTCORAL);
        errorLabel.setStyle("-fx-padding: 20;");
        container.getChildren().add(errorLabel);
    }

    /**
     * Converte data in formato relativo (es. "2 giorni fa")
     */
    private static String getRelativeDate(String dateStr) {
        try {
            if (dateStr == null) return "Di recente";

            // Per ora restituisce date simulate, poi implementeremo il calcolo reale
            String[] samples = {"Oggi", "Ieri", "2 giorni fa", "1 settimana fa", "2 settimane fa"};
            return samples[(int) (Math.random() * samples.length)];
        } catch (Exception e) {
            return "Di recente";
        }
    }

    /**
     * Mostra dialog con tutte le recensioni
     */
    private static void showAllReviewsDialog(Book book) {
        System.out.println("📖 Apertura dialog tutte le recensioni per: " + book.getTitle());

        // Crea dialog
        Stage dialogStage = new Stage();
        dialogStage.initStyle(StageStyle.DECORATED);
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.setTitle("Recensioni - " + book.getTitle());

        VBox dialogContent = new VBox(15);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setStyle("-fx-background-color: #2b2b2b;");

        // Header
        Label headerLabel = new Label("📖 Tutte le recensioni di \"" + book.getTitle() + "\"");
        headerLabel.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 18));
        headerLabel.setTextFill(Color.WHITE);

        // Lista recensioni scrollabile
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(400);
        scrollPane.setStyle("-fx-background: #2b2b2b; -fx-background-color: #2b2b2b;");

        VBox reviewsList = new VBox(10);
        reviewsList.setPadding(new Insets(10));

        // Carica tutte le recensioni
        loadAllReviews(reviewsList, book);

        scrollPane.setContent(reviewsList);

        // Pulsante chiudi
        Button closeButton = new Button("Chiudi");
        closeButton.setStyle(
                "-fx-background-color: #606060;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 20;" +
                        "-fx-padding: 10 20;" +
                        "-fx-cursor: hand;"
        );
        closeButton.setOnAction(e -> dialogStage.close());

        HBox buttonBox = new HBox();
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().add(closeButton);

        dialogContent.getChildren().addAll(headerLabel, scrollPane, buttonBox);

        Scene scene = new Scene(dialogContent, 600, 500);
        dialogStage.setScene(scene);
        dialogStage.show();
    }

    /**
     * Carica tutte le recensioni nel dialog
     */
    private static void loadAllReviews(VBox container, Book book) {
        // Messaggio caricamento
        Label loadingLabel = new Label("📖 Caricamento di tutte le recensioni...");
        loadingLabel.setFont(Font.font("SF Pro Text", 14));
        loadingLabel.setTextFill(Color.WHITE);
        container.getChildren().add(loadingLabel);

        ratingService.getBookRatingsAsync(book.getIsbn())
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        container.getChildren().clear();

                        if (response.isSuccess() && response.getRatings() != null && !response.getRatings().isEmpty()) {
                            // Mostra tutte le recensioni con testo
                            List<BookRating> allReviews = response.getRatings().stream()
                                    .filter(rating -> rating.getReview() != null && !rating.getReview().trim().isEmpty())
                                    .sorted((r1, r2) -> Double.compare(r2.getAverage(), r1.getAverage()))
                                    .collect(Collectors.toList());

                            if (!allReviews.isEmpty()) {
                                for (BookRating rating : allReviews) {
                                    VBox fullReviewCard = createFullReviewCard(rating);
                                    container.getChildren().add(fullReviewCard);
                                }

                                System.out.println("✅ Mostrate " + allReviews.size() + " recensioni complete");
                            } else {
                                Label noReviewsLabel = new Label("📝 Non ci sono ancora recensioni testuali per questo libro");
                                noReviewsLabel.setFont(Font.font("SF Pro Text", 14));
                                noReviewsLabel.setTextFill(Color.LIGHTGRAY);
                                container.getChildren().add(noReviewsLabel);
                            }
                        } else {
                            Label errorLabel = new Label("❌ Errore nel caricamento delle recensioni");
                            errorLabel.setFont(Font.font("SF Pro Text", 14));
                            errorLabel.setTextFill(Color.LIGHTCORAL);
                            container.getChildren().add(errorLabel);
                        }
                    });
                })
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        container.getChildren().clear();
                        Label errorLabel = new Label("❌ Errore di connessione: " + throwable.getMessage());
                        errorLabel.setFont(Font.font("SF Pro Text", 14));
                        errorLabel.setTextFill(Color.LIGHTCORAL);
                        container.getChildren().add(errorLabel);
                    });
                    return null;
                });
    }

    /**
     * Crea card completa per recensione nel dialog
     */
    private static VBox createFullReviewCard(BookRating rating) {
        VBox card = new VBox(10);
        card.setStyle(
                "-fx-background-color: #383838;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;" +
                        "-fx-border-color: #555555;" +
                        "-fx-border-width: 1;" +
                        "-fx-border-radius: 10;"
        );

        // Header con rating dettagliato
        HBox header = new HBox(15);
        header.setAlignment(Pos.CENTER_LEFT);

        // Stelle principali
        String mainStars = "★".repeat(rating.getStarRating()) + "☆".repeat(5 - rating.getStarRating());
        Label mainStarsLabel = new Label(mainStars + " " + String.format("%.1f/5", rating.getAverage()));
        mainStarsLabel.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 16));
        mainStarsLabel.setTextFill(Color.GOLD);

        // Username anonimizzato
        String displayName = rating.getUsername().length() > 4 ?
                rating.getUsername().substring(0, 4) + "***" :
                "Utente***";
        Label usernameLabel = new Label("di " + displayName);
        usernameLabel.setFont(Font.font("SF Pro Text", 14));
        usernameLabel.setTextFill(Color.LIGHTBLUE);

        header.getChildren().addAll(mainStarsLabel, usernameLabel);

        // Dettaglio rating per categoria
        Label detailRating = new Label(String.format(
                "Stile: %d★ | Contenuto: %d★ | Piacevolezza: %d★ | Originalità: %d★ | Edizione: %d★",
                rating.getStyle(), rating.getContent(), rating.getPleasantness(),
                rating.getOriginality(), rating.getEdition()
        ));
        detailRating.setFont(Font.font("SF Pro Text", 12));
        detailRating.setTextFill(Color.LIGHTGRAY);

        // Testo recensione completo
        Text reviewText = new Text(rating.getReview());
        reviewText.setFont(Font.font("SF Pro Text", 14));
        reviewText.setFill(Color.WHITE);
        reviewText.setWrappingWidth(550);

        // Data
        Label dateLabel = new Label(getRelativeDate(rating.getData()));
        dateLabel.setFont(Font.font("SF Pro Text", 12));
        dateLabel.setTextFill(Color.GRAY);

        card.getChildren().addAll(header, detailRating, reviewText, dateLabel);
        return card;
    }

    private static VBox createReviewCard(String title, String content, String rating, String date) {
        VBox card = new VBox(8);
        card.setStyle(
                "-fx-background-color: #3a3a3c;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;"
        );
        card.setPrefWidth(450);

        Label reviewTitle = new Label(title);
        reviewTitle.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 16));
        reviewTitle.setTextFill(Color.WHITE);

        Text reviewContent = new Text(content);
        reviewContent.setFont(Font.font("SF Pro Text", 14));
        reviewContent.setFill(Color.LIGHTGRAY);
        reviewContent.setWrappingWidth(420);

        HBox footer = new HBox(10);
        Label ratingLabel = new Label(rating);
        ratingLabel.setTextFill(Color.WHITE);

        Label dateLabel = new Label(date);
        dateLabel.setTextFill(Color.GRAY);
        dateLabel.setFont(Font.font("SF Pro Text", 12));

        footer.getChildren().addAll(ratingLabel, dateLabel);

        card.getChildren().addAll(reviewTitle, reviewContent, footer);
        return card;
    }

    // METODI PER ANIMAZIONI E NAVIGAZIONE

    private static void addEdgeDetection(StackPane container) {
        if (booksCollection == null || booksCollection.size() <= 1) {
            System.out.println("🔍 Nessuna edge detection: collezione singola o vuota");
            return;
        }

        Rectangle leftEdge = new Rectangle(100, 700, Color.TRANSPARENT);
        leftEdge.setOpacity(0.01);

        Rectangle rightEdge = new Rectangle(100, 700, Color.TRANSPARENT);
        rightEdge.setOpacity(0.01);

        StackPane.setAlignment(leftEdge, Pos.CENTER_LEFT);
        StackPane.setAlignment(rightEdge, Pos.CENTER_RIGHT);

        rightEdge.setOnMouseEntered(e -> {
            if (currentBookIndex < booksCollection.size() - 1 && !isTransitioning) {
                showBookPreview(true, false);
            }
        });

        rightEdge.setOnMouseExited(e -> {
            if (!isTransitioning) {
                showBookPreview(false, false);
            }
        });

        leftEdge.setOnMouseEntered(e -> {
            if (currentBookIndex > 0 && !isTransitioning) {
                showBookPreview(true, true);
            }
        });

        leftEdge.setOnMouseExited(e -> {
            if (!isTransitioning) {
                showBookPreview(false, true);
            }
        });

        rightEdge.setOnMouseClicked(e -> {
            if (currentBookIndex < booksCollection.size() - 1 && !isTransitioning) {
                slideToBook(currentBookIndex + 1);
            }
        });

        leftEdge.setOnMouseClicked(e -> {
            if (currentBookIndex > 0 && !isTransitioning) {
                slideToBook(currentBookIndex - 1);
            }
        });

        container.getChildren().addAll(leftEdge, rightEdge);
    }

    private static void addNavigationArrows() {
        if (booksCollection == null || booksCollection.size() <= 1) {
            System.out.println("🔍 Nessuna freccia navigazione: collezione singola o vuota");
            return;
        }

        leftArrowButton = new Button("❮");
        leftArrowButton.setStyle(
                "-fx-background-color: rgba(0, 0, 0, 0.5);" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 24px;" +
                        "-fx-background-radius: 50%;" +
                        "-fx-min-width: 50px;" +
                        "-fx-min-height: 50px;" +
                        "-fx-max-width: 50px;" +
                        "-fx-max-height: 50px;" +
                        "-fx-padding: 0;" +
                        "-fx-cursor: hand;" +
                        "-fx-opacity: 0.8;"
        );

        rightArrowButton = new Button("❯");
        rightArrowButton.setStyle(
                "-fx-background-color: rgba(0, 0, 0, 0.5);" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 24px;" +
                        "-fx-background-radius: 50%;" +
                        "-fx-min-width: 50px;" +
                        "-fx-min-height: 50px;" +
                        "-fx-max-width: 50px;" +
                        "-fx-max-height: 50px;" +
                        "-fx-padding: 0;" +
                        "-fx-cursor: hand;" +
                        "-fx-opacity: 0.8;"
        );

        StackPane.setAlignment(leftArrowButton, Pos.CENTER_LEFT);
        StackPane.setAlignment(rightArrowButton, Pos.CENTER_RIGHT);

        StackPane.setMargin(leftArrowButton, new Insets(0, 0, 0, 20));
        StackPane.setMargin(rightArrowButton, new Insets(0, 20, 0, 0));

        leftArrowButton.setOpacity(0);
        rightArrowButton.setOpacity(0);

        root.setOnMouseEntered(e -> updateArrowVisibility());
        root.setOnMouseExited(e -> {
            if (leftArrowButton != null) leftArrowButton.setOpacity(0);
            if (rightArrowButton != null) rightArrowButton.setOpacity(0);
        });

        leftArrowButton.setOnMouseClicked(e -> {
            if (currentBookIndex > 0 && !isTransitioning) {
                slideToBook(currentBookIndex - 1);
            }
        });

        rightArrowButton.setOnMouseClicked(e -> {
            if (currentBookIndex < booksCollection.size() - 1 && !isTransitioning) {
                slideToBook(currentBookIndex + 1);
            }
        });

        leftArrowButton.setOnMousePressed(e -> e.consume());
        rightArrowButton.setOnMousePressed(e -> e.consume());

        root.getChildren().addAll(leftArrowButton, rightArrowButton);
    }

    private static void updateArrowVisibility() {
        if (booksCollection == null || booksCollection.size() <= 1) {
            if (leftArrowButton != null) leftArrowButton.setOpacity(0);
            if (rightArrowButton != null) rightArrowButton.setOpacity(0);
            return;
        }

        if (currentBookIndex > 0) {
            leftArrowButton.setOpacity(0.8);
        } else {
            leftArrowButton.setOpacity(0);
        }

        if (currentBookIndex < booksCollection.size() - 1) {
            rightArrowButton.setOpacity(0.8);
        } else {
            rightArrowButton.setOpacity(0);
        }
    }

    private static void showBookPreview(boolean show, boolean isPrevious) {
        if (slideAnimation != null && slideAnimation.getStatus().equals(javafx.animation.Animation.Status.RUNNING)) {
            slideAnimation.stop();
        }

        VBox previewToShow = isPrevious ? prevBookPreview : nextBookPreview;

        if (previewToShow == null || !previewToShow.isVisible()) {
            return;
        }

        double targetX;
        if (isPrevious) {
            targetX = show ? -950 : -1200;
        } else {
            targetX = show ? 950 : 1200;
        }

        slideAnimation = new Timeline(
                new KeyFrame(Duration.millis(300),
                        new KeyValue(previewToShow.translateXProperty(), targetX)
                )
        );
        slideAnimation.play();
    }

    private static void slideToBook(int newIndex) {
        if (newIndex < 0 || newIndex >= booksCollection.size() || newIndex == currentBookIndex || isTransitioning) {
            return;
        }

        isTransitioning = true;

        Book targetBook = booksCollection.get(newIndex);
        boolean isForward = newIndex > currentBookIndex;

        // *** IMPORTANTE: RESET COMPLETO DELLE VALUTAZIONI ***
        System.out.println("🔄 Navigazione verso libro: " + targetBook.getTitle());
        currentUserRating = null;
        averageBookRating = null;
        averageRatingLabel = null;
        currentRatingSection = null;
        userRatingContainer = null;

        // Aggiorna i riferimenti globali
        currentBook = targetBook;
        // currentAuthManager rimane lo stesso

        Image coverImage = ImageUtils.loadSafeImage(targetBook.getImageUrl());
        Color dominantColor = extractDominantColor(coverImage);
        Color darkenedColor = darkenColor(dominantColor, 0.7);
        String backgroundColor = toHexString(darkenedColor);

        VBox newBookContent = createBookContent(targetBook, backgroundColor, currentAuthManager);
        newBookContent.setTranslateX(isForward ? 1200 : -1200);

        bookDisplayPane.getChildren().add(newBookContent);

        VBox currentContent = (VBox) bookDisplayPane.getChildren().get(1);

        if (slideAnimation != null && slideAnimation.getStatus().equals(javafx.animation.Animation.Status.RUNNING)) {
            slideAnimation.stop();
        }

        slideAnimation = new Timeline(
                new KeyFrame(Duration.millis(500),
                        new KeyValue(currentContent.translateXProperty(),
                                isForward ? -1200 : 1200)
                ),
                new KeyFrame(Duration.millis(500),
                        new KeyValue(newBookContent.translateXProperty(), 0)
                )
        );

        slideAnimation.setOnFinished(e -> {
            currentBookIndex = newIndex;

            bookDisplayPane.getChildren().clear();

            prevBookPreview = createBookPreview(currentBookIndex - 1);
            prevBookPreview.setTranslateX(-1200);

            nextBookPreview = createBookPreview(currentBookIndex + 1);
            nextBookPreview.setTranslateX(1200);

            bookDisplayPane.getChildren().addAll(prevBookPreview, newBookContent, nextBookPreview);

            updateArrowVisibility();
            addEdgeDetection(bookDisplayPane);

            // *** IMPORTANTE: RICARICA LE VALUTAZIONI DOPO L'ANIMAZIONE ***
            System.out.println("🔄 Ricarico valutazioni per nuovo libro: " + targetBook.getTitle());
            loadBookRatingsForAllUsers(targetBook, currentAuthManager);

            isTransitioning = false;
        });

        slideAnimation.play();
    }

    private static void resetRatings() {
        System.out.println("🧹 Reset completo delle valutazioni");
        currentUserRating = null;
        averageBookRating = null;
        averageRatingLabel = null;
        currentRatingSection = null;
        userRatingContainer = null;
    }

    // METODI HELPER PER COLORI E GRAFICA

    private static Color extractDominantColor(Image image) {
        if (image == null || image.isError()) {
            return Color.rgb(41, 35, 46);
        }

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        if (width <= 0 || height <= 0) {
            return Color.rgb(41, 35, 46);
        }

        int sampleSize = 5;
        Map<Integer, Integer> colorCounts = new HashMap<>();
        PixelReader pixelReader = image.getPixelReader();

        for (int y = 0; y < height; y += sampleSize) {
            for (int x = 0; x < width; x += sampleSize) {
                Color color = pixelReader.getColor(x, y);

                int rgb = ((int) (color.getRed() * 255) << 16) |
                        ((int) (color.getGreen() * 255) << 8) |
                        ((int) (color.getBlue() * 255));

                colorCounts.put(rgb, colorCounts.getOrDefault(rgb, 0) + 1);
            }
        }

        int dominantRGB = 0;
        int maxCount = 0;

        for (Map.Entry<Integer, Integer> entry : colorCounts.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                dominantRGB = entry.getKey();
            }
        }

        int red = (dominantRGB >> 16) & 0xFF;
        int green = (dominantRGB >> 8) & 0xFF;
        int blue = dominantRGB & 0xFF;

        return Color.rgb(red, green, blue);
    }

    private static Color darkenColor(Color color, double factor) {
        return new Color(
                Math.max(0, color.getRed() * factor),
                Math.max(0, color.getGreen() * factor),
                Math.max(0, color.getBlue() * factor),
                color.getOpacity()
        );
    }

    private static String toHexString(Color color) {
        int r = ((int) (color.getRed() * 255)) & 0xFF;
        int g = ((int) (color.getGreen() * 255)) & 0xFF;
        int b = ((int) (color.getBlue() * 255)) & 0xFF;

        return String.format("#%02X%02X%02X", r, g, b);
    }
}