package org.BABO.client.ui;

import javafx.animation.Interpolator;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.BABO.shared.model.Book;
import org.BABO.shared.model.BookRating;
import org.BABO.shared.dto.RatingResponse;
import org.BABO.client.service.LibraryService;
import org.BABO.client.service.ClientRatingService;
import org.BABO.shared.dto.LibraryResponse;
import javafx.application.Platform;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.effect.BoxBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Popup per mostrare i dettagli di un libro con supporto per navigazione,
 * valutazioni e librerie personali
 */
public class BookDetailsPopup {

    // Core components
    private static StackPane root;
    private static List<Book> booksCollection;
    private static int currentBookIndex = 0;
    private static StackPane bookDisplayPane;
    private static VBox nextBookPreview;
    private static VBox prevBookPreview;
    private static Timeline slideAnimation;
    private static Runnable closeHandler;
    private static boolean isTransitioning = false;
    private static Button leftArrowButton;
    private static Button rightArrowButton;

    // Rating system variables
    private static final ClientRatingService ratingService = new ClientRatingService();
    private static BookRating currentUserRating = null;
    private static Double averageBookRating = null;
    private static Label averageRatingLabel = null;
    private static VBox currentRatingSection = null;
    private static AuthenticationManager currentAuthManager = null;
    private static Book currentBook = null;

    // Public API methods
    public static StackPane create(Book book, List<Book> collection, Runnable onClose) {
        return createWithLibrarySupport(book, collection, onClose, null);
    }

    public static StackPane createWithLibrarySupport(Book book, List<Book> collection, Runnable onClose,
                                                     AuthenticationManager authManager) {
        initializePopup(book, collection, onClose, authManager);
        return createMainContainer(book);
    }

    // Initialization methods
    private static void initializePopup(Book book, List<Book> collection, Runnable onClose,
                                        AuthenticationManager authManager) {
        booksCollection = collection;
        closeHandler = onClose;
        currentBookIndex = Math.max(0, collection.indexOf(book));

        resetRatings();
        currentBook = book;
        currentAuthManager = authManager;
    }

    private static StackPane createMainContainer(Book book) {
        root = new StackPane();

        // Background
        StackPane blurLayer = createBackgroundLayer();

        // Book display pane
        bookDisplayPane = new StackPane();
        VBox currentBookContent = createBookContent(book, getBookBackgroundColor(book), currentAuthManager);

        // Load ratings
        loadBookRatingsForAllUsers(book, currentAuthManager);

        // Setup navigation for multiple books
        if (booksCollection.size() > 1) {
            setupMultiBookNavigation(currentBookContent);
        } else {
            bookDisplayPane.getChildren().add(currentBookContent);
        }

        root.getChildren().addAll(blurLayer, bookDisplayPane);
        return root;
    }

    private static StackPane createBackgroundLayer() {
        StackPane blurLayer = new StackPane();
        blurLayer.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7);");
        blurLayer.setEffect(new BoxBlur(20, 20, 3));
        blurLayer.setOnMouseClicked(e -> {
            if (closeHandler != null) closeHandler.run();
        });
        return blurLayer;
    }

    private static void setupMultiBookNavigation(VBox currentBookContent) {
        nextBookPreview = createBookPreview(currentBookIndex + 1);
        nextBookPreview.setTranslateX(1200);

        prevBookPreview = createBookPreview(currentBookIndex - 1);
        prevBookPreview.setTranslateX(-1200);

        bookDisplayPane.getChildren().addAll(prevBookPreview, currentBookContent, nextBookPreview);
        addEdgeDetection(bookDisplayPane);
        addNavigationArrows();
    }

    private static String getBookBackgroundColor(Book book) {
        Image coverImage = ImageUtils.loadSafeImage(book.getImageUrl());
        Color dominantColor = extractDominantColor(coverImage);
        Color darkenedColor = darkenColor(dominantColor, 0.7);
        return toHexString(darkenedColor);
    }

    // Book content creation
    private static VBox createBookContent(Book book, String backgroundColor, AuthenticationManager authManager) {
        VBox popupContent = new VBox();
        popupContent.setMaxWidth(1000);
        popupContent.setMaxHeight(700);
        popupContent.setMinWidth(1000);
        popupContent.setStyle(createPopupStyle(backgroundColor));

        HBox topBar = createTopBar();
        ScrollPane contentScroll = createContentScrollPane(book, authManager);

        popupContent.getChildren().addAll(topBar, contentScroll);
        return popupContent;
    }

    private static String createPopupStyle(String backgroundColor) {
        return "-fx-background-color: " + backgroundColor + ";" +
                "-fx-background-radius: 10;" +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.4), 15, 0, 0, 5);";
    }

    private static HBox createTopBar() {
        HBox topBar = new HBox();
        topBar.setPadding(new Insets(10));
        topBar.setAlignment(Pos.CENTER_RIGHT);

        Button closeButton = createTopBarButton("×", 20);
        closeButton.setOnAction(e -> {
            if (closeHandler != null) closeHandler.run();
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button addButton = createTopBarButton("+", 20);
        Button shareButton = createTopBarButton("⇧", 16);
        Button moreButton = createTopBarButton("⋯", 16);

        topBar.getChildren().addAll(closeButton, spacer, addButton, shareButton, moreButton);
        return topBar;
    }

    private static Button createTopBarButton(String text, int fontSize) {
        Button button = new Button(text);
        button.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-text-fill: #999999;" +
                        "-fx-font-size: " + fontSize + ";" +
                        "-fx-cursor: hand;"
        );
        return button;
    }

    private static ScrollPane createContentScrollPane(Book book, AuthenticationManager authManager) {
        ScrollPane contentScroll = new ScrollPane();
        contentScroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        contentScroll.setFitToWidth(true);
        contentScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        contentScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        contentScroll.setPannable(false);

        // Prevent horizontal scrolling
        setupScrollConstraints(contentScroll);

        VBox scrollContent = new VBox();
        scrollContent.getChildren().addAll(
                createDetailsSection(book, authManager),
                createPublisherSection(book),
                createRatingSection(book, authManager),
                createReviewsSection()
        );

        contentScroll.setContent(scrollContent);
        return contentScroll;
    }

    private static void setupScrollConstraints(ScrollPane scrollPane) {
        scrollPane.hvalueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.doubleValue() != 0.0) {
                scrollPane.setHvalue(0.0);
            }
        });

        scrollPane.addEventFilter(MouseEvent.MOUSE_DRAGGED, e -> {
            if (Math.abs(e.getX() - e.getSceneX()) > Math.abs(e.getY() - e.getSceneY())) {
                e.consume();
            }
        });
    }

    // Book details sections
    private static HBox createDetailsSection(Book book, AuthenticationManager authManager) {
        HBox detailsSection = new HBox(30);
        detailsSection.setPadding(new Insets(20, 30, 30, 30));
        detailsSection.setAlignment(Pos.TOP_LEFT);

        VBox coverContainer = createCoverContainer(book);
        VBox infoBox = createInfoBox(book, authManager);

        detailsSection.getChildren().addAll(coverContainer, infoBox);
        return detailsSection;
    }

    private static VBox createCoverContainer(Book book) {
        ImageView cover = ImageUtils.createSafeImageView(book.getImageUrl(), 180, 270);
        Rectangle coverClip = new Rectangle(180, 270);
        coverClip.setArcWidth(8);
        coverClip.setArcHeight(8);
        cover.setClip(coverClip);

        VBox coverContainer = new VBox(cover);
        coverContainer.setAlignment(Pos.TOP_CENTER);
        return coverContainer;
    }

    private static VBox createInfoBox(Book book, AuthenticationManager authManager) {
        VBox infoBox = new VBox(8);
        infoBox.setAlignment(Pos.TOP_LEFT);

        infoBox.getChildren().addAll(
                createCategoryBadge(),
                createTitleLabel(book.getTitle()),
                createAuthorLabel(book.getAuthor()),
                createRatingBox(),
                createBookInfoBox(book),
                createButtonBox(book, authManager)
        );

        return infoBox;
    }

    private static Label createCategoryBadge() {
        Label categoryBadge = new Label("#1, BESTSELLER ❯");
        categoryBadge.setStyle(
                "-fx-background-color: #444;" +
                        "-fx-background-radius: 15;" +
                        "-fx-padding: 5 10;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 12;"
        );
        return categoryBadge;
    }

    private static Label createTitleLabel(String title) {
        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 26));
        titleLabel.setTextFill(Color.WHITE);
        titleLabel.setWrapText(true);
        return titleLabel;
    }

    private static Label createAuthorLabel(String author) {
        Label authorLabel = new Label(author);
        authorLabel.setFont(Font.font("SF Pro Text", 18));
        authorLabel.setTextFill(Color.LIGHTGRAY);
        return authorLabel;
    }

    private static HBox createRatingBox() {
        HBox ratingBox = new HBox(5);
        ratingBox.setPadding(new Insets(10, 0, 0, 0));

        averageRatingLabel = new Label("⭐ Caricamento...");
        averageRatingLabel.setTextFill(Color.WHITE);
        averageRatingLabel.setFont(Font.font("SF Pro Text", 14));

        Label ratingCategory = new Label("• Narrativa");
        ratingCategory.setTextFill(Color.LIGHTGRAY);
        ratingCategory.setFont(Font.font("SF Pro Text", 14));
        ratingCategory.setPadding(new Insets(0, 0, 0, 5));

        ratingBox.getChildren().addAll(averageRatingLabel, ratingCategory);
        return ratingBox;
    }

    private static VBox createBookInfoBox(Book book) {
        VBox bookInfoBox = new VBox(15);
        bookInfoBox.setPadding(new Insets(20, 0, 0, 0));

        Label infoLabel = new Label("📚 Libro Digitale");
        infoLabel.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 14));
        infoLabel.setTextFill(Color.WHITE);
        bookInfoBox.getChildren().add(infoLabel);

        if (isNotEmpty(book.getIsbn())) {
            Label isbnInfo = new Label("📄 ISBN: " + book.getIsbn());
            isbnInfo.setFont(Font.font("SF Pro Text", 14));
            isbnInfo.setTextFill(Color.LIGHTGRAY);
            bookInfoBox.getChildren().add(isbnInfo);
        }

        if (isNotEmpty(book.getPublishYear())) {
            Label yearInfo = new Label("📅 Anno: " + book.getPublishYear());
            yearInfo.setFont(Font.font("SF Pro Text", 14));
            yearInfo.setTextFill(Color.LIGHTGRAY);
            bookInfoBox.getChildren().add(yearInfo);
        }

        Label pagesInfo = new Label("📄 ~300 pagine");
        pagesInfo.setFont(Font.font("SF Pro Text", 14));
        pagesInfo.setTextFill(Color.LIGHTGRAY);
        bookInfoBox.getChildren().add(pagesInfo);

        return bookInfoBox;
    }

    private static HBox createButtonBox(Book book, AuthenticationManager authManager) {
        HBox buttonBox = new HBox(10);
        buttonBox.setPadding(new Insets(20, 0, 0, 0));

        Button getButton = createStyledButton("📖 Ottieni", "white", "black");
        Button previewButton = createStyledButton("👁️ Estratto", "rgba(255,255,255,0.2)", "white");

        buttonBox.getChildren().addAll(getButton, previewButton);

        if (authManager != null && authManager.isAuthenticated()) {
            Button addToLibraryButton = createStyledButton("📚 Aggiungi a Libreria", "#9b59b6", "white");
            addToLibraryButton.setOnAction(e -> showAddToLibraryDialog(book, authManager));
            buttonBox.getChildren().add(addToLibraryButton);
        }

        return buttonBox;
    }

    private static Button createStyledButton(String text, String bgColor, String textColor) {
        Button button = new Button(text);
        button.setStyle(
                "-fx-background-color: " + bgColor + ";" +
                        "-fx-text-fill: " + textColor + ";" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 20;" +
                        "-fx-padding: 8 25;" +
                        "-fx-cursor: hand;"
        );
        return button;
    }

    private static VBox createPublisherSection(Book book) {
        VBox publisherSection = new VBox(15);
        publisherSection.setPadding(new Insets(0, 30, 30, 30));

        Label publisherHeader = new Label("📝 Dall'editore");
        publisherHeader.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 20));
        publisherHeader.setTextFill(Color.WHITE);

        String description = isNotEmpty(book.getDescription()) ?
                book.getDescription() : "Descrizione non disponibile per questo libro.";

        Text publisherText = new Text(description);
        publisherText.setWrappingWidth(940);
        publisherText.setFill(Color.WHITE);
        publisherText.setFont(Font.font("SF Pro Text", 14));

        publisherSection.getChildren().addAll(publisherHeader, publisherText);
        return publisherSection;
    }

    // Rating system methods
    private static void loadBookRatingsForAllUsers(Book book, AuthenticationManager authManager) {
        if (isEmpty(book.getIsbn())) {
            updateRatingDisplaySafe();
            return;
        }

        // Load average rating (always visible)
        loadAverageRating(book);

        // Load user rating (only if authenticated)
        if (authManager != null && authManager.isAuthenticated()) {
            loadUserRating(book, authManager.getCurrentUsername());
        }
    }

    private static void loadAverageRating(Book book) {
        ratingService.getBookAverageRatingAsync(book.getIsbn())
                .thenAccept(response -> Platform.runLater(() -> {
                    averageBookRating = response.isSuccess() ? response.getAverageRating() : null;
                    updateRatingDisplaySafe();
                    refreshRatingSection();
                }))
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        averageBookRating = null;
                        updateRatingDisplaySafe();
                    });
                    return null;
                });
    }

    private static void loadUserRating(Book book, String username) {
        ratingService.getUserRatingForBookAsync(username, book.getIsbn())
                .thenAccept(response -> Platform.runLater(() -> {
                    currentUserRating = response.isSuccess() ? response.getRating() : null;
                    refreshRatingSection();
                }))
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        currentUserRating = null;
                        refreshRatingSection();
                    });
                    return null;
                });
    }

    private static void updateRatingDisplaySafe() {
        if (averageRatingLabel != null) {
            if (averageBookRating != null && averageBookRating > 0) {
                int stars = (int) Math.round(averageBookRating);
                String starsDisplay = "★".repeat(stars) + "☆".repeat(5 - stars);
                String text = String.format("%s %.1f/5 (%d recensioni)",
                        starsDisplay, averageBookRating, (int)(Math.random() * 50 + 10));
                averageRatingLabel.setText(text);
            } else {
                averageRatingLabel.setText("☆☆☆☆☆ Non ancora valutato");
            }
        }
    }

    private static void refreshRatingSection() {
        if (currentRatingSection != null && currentBook != null && currentAuthManager != null) {
            Parent parent = currentRatingSection.getParent();
            if (parent instanceof VBox) {
                VBox parentVBox = (VBox) parent;
                int index = parentVBox.getChildren().indexOf(currentRatingSection);

                if (index >= 0) {
                    parentVBox.getChildren().remove(index);
                    VBox newRatingSection = createRatingSection(currentBook, currentAuthManager);
                    parentVBox.getChildren().add(index, newRatingSection);
                }
            }
        }
    }

    private static VBox createRatingSection(Book book, AuthenticationManager authManager) {
        VBox ratingSection = new VBox(15);
        ratingSection.setPadding(new Insets(0, 30, 30, 30));
        currentRatingSection = ratingSection;

        // Header
        Label ratingsHeader = new Label("⭐ Valutazioni");
        ratingsHeader.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 20));
        ratingsHeader.setTextFill(Color.WHITE);

        // Content
        VBox ratingsContent = new VBox(12);
        ratingsContent.getChildren().add(createAverageRatingDisplay());

        if (authManager != null && authManager.isAuthenticated()) {
            ratingsContent.getChildren().add(createUserRatingSection(book, authManager));
        } else {
            ratingsContent.getChildren().add(createGuestInviteSection());
        }

        ratingSection.getChildren().addAll(ratingsHeader, ratingsContent);
        return ratingSection;
    }

    private static HBox createAverageRatingDisplay() {
        HBox averageBox = new HBox(15);
        averageBox.setStyle(
                "-fx-background-color: #3a3a3c;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;"
        );
        averageBox.setAlignment(Pos.CENTER_LEFT);

        VBox averageInfo = new VBox(5);

        Label averageTitle = new Label("📊 Valutazione della Community");
        averageTitle.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 16));
        averageTitle.setTextFill(Color.WHITE);

        Label averageValue = new Label("⭐ Caricamento...");
        averageValue.setFont(Font.font("SF Pro Text", 14));
        averageValue.setTextFill(Color.GRAY);

        if (averageBookRating != null && averageBookRating > 0) {
            int stars = (int) Math.round(averageBookRating);
            String starsDisplay = "★".repeat(stars) + "☆".repeat(5 - stars);
            averageValue.setText(String.format("%s %.1f/5", starsDisplay, averageBookRating));
            averageValue.setTextFill(Color.GOLD);
        }

        Label publicNote = new Label("Basata su tutte le recensioni degli utenti registrati");
        publicNote.setFont(Font.font("SF Pro Text", 12));
        publicNote.setTextFill(Color.GRAY);

        averageInfo.getChildren().addAll(averageTitle, averageValue, publicNote);
        averageBox.getChildren().add(averageInfo);

        return averageBox;
    }

    private static VBox createGuestInviteSection() {
        VBox guestSection = new VBox(10);
        guestSection.setStyle(
                "-fx-background-color: #444448;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;"
        );

        Label guestTitle = new Label("🔐 Vuoi valutare questo libro?");
        guestTitle.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 16));
        guestTitle.setTextFill(Color.WHITE);

        Label inviteMessage = new Label("Registrati o accedi per valutare e recensire i tuoi libri preferiti");
        inviteMessage.setFont(Font.font("SF Pro Text", 14));
        inviteMessage.setTextFill(Color.LIGHTGRAY);
        inviteMessage.setWrapText(true);

        Label benefitMessage = new Label("✨ Condividi le tue opinioni con la community di lettori!");
        benefitMessage.setFont(Font.font("SF Pro Text", 12));
        benefitMessage.setTextFill(Color.LIGHTBLUE);

        guestSection.getChildren().addAll(guestTitle, inviteMessage, benefitMessage);
        return guestSection;
    }

    private static VBox createUserRatingSection(Book book, AuthenticationManager authManager) {
        VBox userSection = new VBox(10);
        userSection.setStyle(
                "-fx-background-color: #444448;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;"
        );

        // Header with action button
        HBox userHeader = new HBox();
        userHeader.setAlignment(Pos.CENTER_LEFT);

        Label userTitle = new Label("👤 La tua valutazione");
        userTitle.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 16));
        userTitle.setTextFill(Color.WHITE);

        Region userSpacer = new Region();
        HBox.setHgrow(userSpacer, Priority.ALWAYS);

        Button ratingActionButton = createRatingActionButton(book, authManager);
        userHeader.getChildren().addAll(userTitle, userSpacer, ratingActionButton);

        // Content
        VBox userContent = new VBox(8);
        updateUserContent(userContent);

        userSection.getChildren().addAll(userHeader, userContent);
        return userSection;
    }

    private static Button createRatingActionButton(Book book, AuthenticationManager authManager) {
        Button button = new Button();
        updateRatingButton(button);

        button.setOnAction(e -> {
            if (isEmpty(book.getIsbn())) {
                showAlert("Errore", "Impossibile valutare: ISBN del libro mancante");
                return;
            }

            if (currentUserRating != null) {
                RatingDialog.showEditRatingDialog(book, authManager.getCurrentUsername(),
                        currentUserRating, updatedRating -> {
                            currentUserRating = updatedRating;
                            loadBookRatingsForAllUsers(book, authManager);
                        });
            } else {
                RatingDialog.showRatingDialog(book, authManager.getCurrentUsername(),
                        newRating -> {
                            if (newRating != null) {
                                currentUserRating = newRating;
                                loadBookRatingsForAllUsers(book, authManager);
                            }
                        });
            }
        });

        return button;
    }

    private static void updateRatingButton(Button button) {
        if (currentUserRating != null) {
            button.setText("Modifica");
            button.setStyle(
                    "-fx-background-color: #9b59b6;" +
                            "-fx-text-fill: white;" +
                            "-fx-font-weight: bold;" +
                            "-fx-background-radius: 15;" +
                            "-fx-padding: 5 15;" +
                            "-fx-cursor: hand;"
            );
        } else {
            button.setText("Valuta");
            button.setStyle(
                    "-fx-background-color: #4CAF50;" +
                            "-fx-text-fill: white;" +
                            "-fx-font-weight: bold;" +
                            "-fx-background-radius: 15;" +
                            "-fx-padding: 5 15;" +
                            "-fx-cursor: hand;"
            );
        }
    }

    private static void updateUserContent(VBox userContent) {
        userContent.getChildren().clear();

        if (currentUserRating != null) {
            Label userRatingDisplay = new Label(currentUserRating.getDisplayRating());
            userRatingDisplay.setFont(Font.font("SF Pro Text", 14));
            userRatingDisplay.setTextFill(Color.LIGHTGREEN);

            Label ratingBreakdown = new Label(String.format(
                    "Stile: %d★ | Contenuto: %d★ | Piacevolezza: %d★ | Originalità: %d★ | Edizione: %d★",
                    currentUserRating.getStyle(), currentUserRating.getContent(),
                    currentUserRating.getPleasantness(), currentUserRating.getOriginality(),
                    currentUserRating.getEdition()
            ));
            ratingBreakdown.setFont(Font.font("SF Pro Text", 12));
            ratingBreakdown.setTextFill(Color.LIGHTGRAY);

            userContent.getChildren().addAll(userRatingDisplay, ratingBreakdown);

            if (isNotEmpty(currentUserRating.getReview())) {
                Label reviewLabel = new Label("💭 La tua recensione:");
                reviewLabel.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 12));
                reviewLabel.setTextFill(Color.WHITE);

                Text reviewText = new Text(currentUserRating.getReview());
                reviewText.setFont(Font.font("SF Pro Text", 12));
                reviewText.setFill(Color.LIGHTGRAY);
                reviewText.setWrappingWidth(400);

                userContent.getChildren().addAll(reviewLabel, reviewText);
            }
        } else {
            Label inviteLabel = new Label("Non hai ancora valutato questo libro");
            inviteLabel.setFont(Font.font("SF Pro Text", 14));
            inviteLabel.setTextFill(Color.LIGHTGRAY);

            Label benefitLabel = new Label("Condividi la tua opinione con altri lettori!");
            benefitLabel.setFont(Font.font("SF Pro Text", 12));
            benefitLabel.setTextFill(Color.GRAY);

            userContent.getChildren().addAll(inviteLabel, benefitLabel);
        }
    }

    // Library management methods (simplified)
    private static void showAddToLibraryDialog(Book book, AuthenticationManager authManager) {
        if (isEmpty(book.getIsbn())) {
            showAlert("❌ Errore", "Impossibile aggiungere il libro: ISBN mancante");
            return;
        }

        LibraryService libraryService = new LibraryService();
        libraryService.getUserLibrariesAsync(authManager.getCurrentUsername())
                .thenAccept(response -> Platform.runLater(() -> {
                    if (response.isSuccess() && response.getLibraries() != null) {
                        List<String> libraries = response.getLibraries();
                        if (libraries.isEmpty()) {
                            showCreateFirstLibraryDialog(book, authManager.getCurrentUsername(), libraryService);
                        } else {
                            showChooseLibraryDialog(book, authManager.getCurrentUsername(), libraries, libraryService);
                        }
                    } else {
                        showAlert("❌ Errore", "Errore nel recupero delle librerie: " + response.getMessage());
                    }
                }))
                .exceptionally(throwable -> {
                    Platform.runLater(() -> showAlert("❌ Errore", "Errore di connessione: " + throwable.getMessage()));
                    return null;
                });
    }

    private static void showCreateFirstLibraryDialog(Book book, String username, LibraryService libraryService) {
        TextInputDialog dialog = new TextInputDialog("La mia libreria");
        dialog.setTitle("Crea la tua prima libreria");
        dialog.setHeaderText("Non hai ancora librerie. Creane una per '" + book.getTitle() + "'");
        dialog.setContentText("Nome libreria:");

        styleDialog(dialog);

        dialog.showAndWait().ifPresent(libraryName -> {
            if (isNotEmpty(libraryName)) {
                createLibraryAndAddBook(book, username, libraryName.trim(), libraryService);
            }
        });
    }

    private static void showChooseLibraryDialog(Book book, String username, List<String> libraries, LibraryService libraryService) {
        List<String> choices = new ArrayList<>(libraries);
        choices.add(0, "➕ Crea nuova libreria...");

        ChoiceDialog<String> dialog = new ChoiceDialog<>(libraries.get(0), choices);
        dialog.setTitle("Aggiungi a Libreria");
        dialog.setHeaderText("Scegli dove aggiungere '" + book.getTitle() + "'");
        dialog.setContentText("Libreria:");

        styleDialog(dialog);

        dialog.showAndWait().ifPresent(choice -> {
            if (choice.startsWith("➕")) {
                showCreateNewLibraryDialog(book, username, libraryService);
            } else {
                addBookToExistingLibrary(book, username, choice, libraryService);
            }
        });
    }

    private static void showCreateNewLibraryDialog(Book book, String username, LibraryService libraryService) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Crea Nuova Libreria");
        dialog.setHeaderText("Crea una nuova libreria per '" + book.getTitle() + "'");
        dialog.setContentText("Nome libreria:");

        styleDialog(dialog);

        dialog.showAndWait().ifPresent(libraryName -> {
            if (isNotEmpty(libraryName)) {
                createLibraryAndAddBook(book, username, libraryName.trim(), libraryService);
            }
        });
    }

    private static void createLibraryAndAddBook(Book book, String username, String libraryName, LibraryService libraryService) {
        libraryService.createLibraryAsync(username, libraryName)
                .thenCompose(createResponse -> {
                    if (createResponse.isSuccess()) {
                        return libraryService.addBookToLibraryAsync(username, libraryName, book.getIsbn());
                    } else {
                        return CompletableFuture.completedFuture(
                                new LibraryResponse(false, "Errore nella creazione: " + createResponse.getMessage())
                        );
                    }
                })
                .thenAccept(addResponse -> Platform.runLater(() -> {
                    if (addResponse.isSuccess()) {
                        showAlert("✅ Successo", "Libreria '" + libraryName + "' creata e libro aggiunto!");
                    } else {
                        showAlert("❌ Errore", addResponse.getMessage());
                    }
                }));
    }

    private static void addBookToExistingLibrary(Book book, String username, String libraryName, LibraryService libraryService) {
        libraryService.addBookToLibraryAsync(username, libraryName, book.getIsbn())
                .thenAccept(response -> Platform.runLater(() -> {
                    if (response.isSuccess()) {
                        showAlert("✅ Successo", "Libro aggiunto alla libreria '" + libraryName + "'!");
                    } else {
                        showAlert("❌ Errore", response.getMessage());
                    }
                }));
    }

    private static void styleDialog(Dialog<?> dialog) {
        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e1e1e; -fx-text-fill: white;");
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        styleDialog(alert);
        alert.showAndWait();
    }

    // Reviews section
    private static VBox createReviewsSection() {
        VBox reviewsSection = new VBox(15);
        reviewsSection.setPadding(new Insets(0, 30, 30, 30));

        HBox reviewHeaderBox = createReviewsHeader();
        ScrollPane reviewsScrollPane = createReviewsScrollPane();

        reviewsSection.getChildren().addAll(reviewHeaderBox, reviewsScrollPane);
        return reviewsSection;
    }

    private static HBox createReviewsHeader() {
        HBox reviewHeaderBox = new HBox();

        Label reviewsHeader = new Label("💬 Recensioni della community");
        reviewsHeader.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 20));
        reviewsHeader.setTextFill(Color.WHITE);

        Label seeMoreReviews = new Label("Vedi tutte ❯");
        seeMoreReviews.setFont(Font.font("SF Pro Text", 14));
        seeMoreReviews.setTextFill(Color.LIGHTBLUE);
        seeMoreReviews.setStyle("-fx-cursor: hand;");
        seeMoreReviews.setOnMouseClicked(e -> {
            if (currentBook != null) {
                showAllReviewsDialog(currentBook);
            }
        });

        Region reviewSpacer = new Region();
        HBox.setHgrow(reviewSpacer, Priority.ALWAYS);
        reviewHeaderBox.getChildren().addAll(reviewsHeader, reviewSpacer, seeMoreReviews);

        return reviewHeaderBox;
    }

    private static ScrollPane createReviewsScrollPane() {
        ScrollPane reviewsScrollPane = new ScrollPane();
        reviewsScrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        reviewsScrollPane.setFitToHeight(true);
        reviewsScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        reviewsScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        reviewsScrollPane.setPannable(true);
        reviewsScrollPane.setPrefHeight(200);

        HBox reviewsContainer = new HBox(15);
        reviewsContainer.setPadding(new Insets(10, 0, 10, 0));
        reviewsScrollPane.setContent(reviewsContainer);

        loadCommunityReviews(reviewsContainer);
        return reviewsScrollPane;
    }

    private static void loadCommunityReviews(HBox container) {
        if (currentBook == null || isEmpty(currentBook.getIsbn())) {
            showNoReviewsMessage(container);
            return;
        }

        Label loadingLabel = new Label("📖 Caricamento recensioni...");
        loadingLabel.setFont(Font.font("SF Pro Text", 14));
        loadingLabel.setTextFill(Color.GRAY);
        loadingLabel.setStyle("-fx-padding: 20;");
        container.getChildren().add(loadingLabel);

        ratingService.getBookRatingsAsync(currentBook.getIsbn())
                .thenAccept(response -> Platform.runLater(() -> {
                    container.getChildren().clear();

                    if (response.isSuccess() && response.getRatings() != null && !response.getRatings().isEmpty()) {
                        List<BookRating> reviewsWithText = response.getRatings().stream()
                                .filter(rating -> isNotEmpty(rating.getReview()))
                                .filter(rating -> currentAuthManager == null ||
                                        !rating.getUsername().equals(currentAuthManager.getCurrentUsername()))
                                .sorted((r1, r2) -> Double.compare(r2.getAverage(), r1.getAverage()))
                                .limit(5)
                                .collect(Collectors.toList());

                        if (!reviewsWithText.isEmpty()) {
                            for (BookRating rating : reviewsWithText) {
                                VBox reviewCard = createCommunityReviewCard(rating);
                                container.getChildren().add(reviewCard);
                            }
                        } else {
                            showNoReviewsMessage(container);
                        }
                    } else {
                        showNoReviewsMessage(container);
                    }
                }))
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        container.getChildren().clear();
                        showErrorMessage(container, "Errore nel caricamento delle recensioni");
                    });
                    return null;
                });
    }

    private static VBox createCommunityReviewCard(BookRating rating) {
        VBox card = new VBox(8);
        card.setStyle(
                "-fx-background-color: #3a3a3c;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;"
        );
        card.setPrefWidth(280);
        card.setMaxWidth(280);
        card.setPrefHeight(180);

        // Header with rating and username
        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);

        String stars = "★".repeat(rating.getStarRating()) + "☆".repeat(5 - rating.getStarRating());
        Label starsLabel = new Label(stars);
        starsLabel.setFont(Font.font("SF Pro Text", 14));
        starsLabel.setTextFill(Color.GOLD);

        String displayName = rating.getUsername().length() > 3 ?
                rating.getUsername().substring(0, 3) + "***" : "***";
        Label usernameLabel = new Label("di " + displayName);
        usernameLabel.setFont(Font.font("SF Pro Text", 10));
        usernameLabel.setTextFill(Color.LIGHTGRAY);

        header.getChildren().addAll(starsLabel, usernameLabel);

        // Review text (truncated)
        String reviewText = rating.getReview();
        if (reviewText.length() > 120) {
            reviewText = reviewText.substring(0, 117) + "...";
        }

        Text reviewContent = new Text(reviewText);
        reviewContent.setFont(Font.font("SF Pro Text", 12));
        reviewContent.setFill(Color.WHITE);
        reviewContent.setWrappingWidth(250);

        // Date
        Label dateLabel = new Label(getRelativeDate(rating.getData()));
        dateLabel.setFont(Font.font("SF Pro Text", 10));
        dateLabel.setTextFill(Color.GRAY);

        card.getChildren().addAll(header, reviewContent, dateLabel);
        return card;
    }

    private static void showNoReviewsMessage(HBox container) {
        Label noReviewsLabel = new Label("📝 Nessuna recensione ancora disponibile");
        noReviewsLabel.setFont(Font.font("SF Pro Text", 14));
        noReviewsLabel.setTextFill(Color.GRAY);
        noReviewsLabel.setStyle("-fx-padding: 20;");
        container.getChildren().add(noReviewsLabel);
    }

    private static void showErrorMessage(HBox container, String message) {
        Label errorLabel = new Label("❌ " + message);
        errorLabel.setFont(Font.font("SF Pro Text", 14));
        errorLabel.setTextFill(Color.LIGHTCORAL);
        errorLabel.setStyle("-fx-padding: 20;");
        container.getChildren().add(errorLabel);
    }

    private static String getRelativeDate(String dateStr) {
        if (isEmpty(dateStr)) return "Di recente";

        String[] samples = {"Oggi", "Ieri", "2 giorni fa", "1 settimana fa", "2 settimane fa"};
        return samples[(int) (Math.random() * samples.length)];
    }

    private static void showAllReviewsDialog(Book book) {
        Stage dialogStage = new Stage();
        dialogStage.initStyle(StageStyle.DECORATED);
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.setTitle("Recensioni - " + book.getTitle());

        VBox dialogContent = new VBox(15);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setStyle("-fx-background-color: #2b2b2b;");

        Label headerLabel = new Label("📖 Tutte le recensioni di \"" + book.getTitle() + "\"");
        headerLabel.setFont(Font.font("SF Pro Display", FontWeight.BOLD, 18));
        headerLabel.setTextFill(Color.WHITE);

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(400);
        scrollPane.setStyle("-fx-background: #2b2b2b; -fx-background-color: #2b2b2b;");

        VBox reviewsList = new VBox(10);
        reviewsList.setPadding(new Insets(10));
        loadAllReviews(reviewsList, book);
        scrollPane.setContent(reviewsList);

        Button closeButton = new Button("Chiudi");
        closeButton.setStyle(
                "-fx-background-color: #606060;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 20;" +
                        "-fx-padding: 10 20;" +
                        "-fx-cursor: hand;"
        );
        closeButton.setOnAction(e -> dialogStage.close());

        HBox buttonBox = new HBox();
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().add(closeButton);

        dialogContent.getChildren().addAll(headerLabel, scrollPane, buttonBox);

        Scene scene = new Scene(dialogContent, 600, 500);
        dialogStage.setScene(scene);
        dialogStage.show();
    }

    private static void loadAllReviews(VBox container, Book book) {
        Label loadingLabel = new Label("📖 Caricamento di tutte le recensioni...");
        loadingLabel.setFont(Font.font("SF Pro Text", 14));
        loadingLabel.setTextFill(Color.WHITE);
        container.getChildren().add(loadingLabel);

        ratingService.getBookRatingsAsync(book.getIsbn())
                .thenAccept(response -> Platform.runLater(() -> {
                    container.getChildren().clear();

                    if (response.isSuccess() && response.getRatings() != null && !response.getRatings().isEmpty()) {
                        List<BookRating> allReviews = response.getRatings().stream()
                                .filter(rating -> isNotEmpty(rating.getReview()))
                                .sorted((r1, r2) -> Double.compare(r2.getAverage(), r1.getAverage()))
                                .collect(Collectors.toList());

                        if (!allReviews.isEmpty()) {
                            for (BookRating rating : allReviews) {
                                VBox fullReviewCard = createFullReviewCard(rating);
                                container.getChildren().add(fullReviewCard);
                            }
                        } else {
                            Label noReviewsLabel = new Label("📝 Non ci sono ancora recensioni testuali per questo libro");
                            noReviewsLabel.setFont(Font.font("SF Pro Text", 14));
                            noReviewsLabel.setTextFill(Color.LIGHTGRAY);
                            container.getChildren().add(noReviewsLabel);
                        }
                    } else {
                        Label errorLabel = new Label("❌ Errore nel caricamento delle recensioni");
                        errorLabel.setFont(Font.font("SF Pro Text", 14));
                        errorLabel.setTextFill(Color.LIGHTCORAL);
                        container.getChildren().add(errorLabel);
                    }
                }))
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        container.getChildren().clear();
                        Label errorLabel = new Label("❌ Errore di connessione: " + throwable.getMessage());
                        errorLabel.setFont(Font.font("SF Pro Text", 14));
                        errorLabel.setTextFill(Color.LIGHTCORAL);
                        container.getChildren().add(errorLabel);
                    });
                    return null;
                });
    }

    private static VBox createFullReviewCard(BookRating rating) {
        VBox card = new VBox(10);
        card.setStyle(
                "-fx-background-color: #383838;" +
                        "-fx-background-radius: 10;" +
                        "-fx-padding: 15;" +
                        "-fx-border-color: #555555;" +
                        "-fx-border-width: 1;" +
                        "-fx-border-radius: 10;"
        );

        // Header with detailed rating
        HBox header = new HBox(15);
        header.setAlignment(Pos.CENTER_LEFT);

        String mainStars = "★".repeat(rating.getStarRating()) + "☆".repeat(5 - rating.getStarRating());
        Label mainStarsLabel = new Label(mainStars + " " + String.format("%.1f/5", rating.getAverage()));
        mainStarsLabel.setFont(Font.font("SF Pro Text", FontWeight.BOLD, 16));
        mainStarsLabel.setTextFill(Color.GOLD);

        String displayName = rating.getUsername().length() > 4 ?
                rating.getUsername().substring(0, 4) + "***" : "Utente***";
        Label usernameLabel = new Label("di " + displayName);
        usernameLabel.setFont(Font.font("SF Pro Text", 14));
        usernameLabel.setTextFill(Color.LIGHTBLUE);

        header.getChildren().addAll(mainStarsLabel, usernameLabel);

        // Rating breakdown
        Label detailRating = new Label(String.format(
                "Stile: %d★ | Contenuto: %d★ | Piacevolezza: %d★ | Originalità: %d★ | Edizione: %d★",
                rating.getStyle(), rating.getContent(), rating.getPleasantness(),
                rating.getOriginality(), rating.getEdition()
        ));
        detailRating.setFont(Font.font("SF Pro Text", 12));
        detailRating.setTextFill(Color.LIGHTGRAY);

        // Full review text
        Text reviewText = new Text(rating.getReview());
        reviewText.setFont(Font.font("SF Pro Text", 14));
        reviewText.setFill(Color.WHITE);
        reviewText.setWrappingWidth(550);

        // Date
        Label dateLabel = new Label(getRelativeDate(rating.getData()));
        dateLabel.setFont(Font.font("SF Pro Text", 12));
        dateLabel.setTextFill(Color.GRAY);

        card.getChildren().addAll(header, detailRating, reviewText, dateLabel);
        return card;
    }

    // Preview and navigation methods
    private static VBox createBookPreview(int bookIndex) {
        if (bookIndex < 0 || booksCollection == null || bookIndex >= booksCollection.size()) {
            VBox emptyPreview = new VBox();
            emptyPreview.setVisible(false);
            emptyPreview.setManaged(false);
            return emptyPreview;
        }

        Book previewBook = booksCollection.get(bookIndex);
        VBox previewContent = new VBox();
        previewContent.setMaxWidth(1000);
        previewContent.setMaxHeight(700);
        previewContent.setOpacity(0.0);
        previewContent.setStyle(createPopupStyle(getBookBackgroundColor(previewBook)));

        // Simplified content for performance
        HBox topBar = new HBox();
        topBar.setPadding(new Insets(10));

        HBox detailsSection = new HBox(30);
        detailsSection.setPadding(new Insets(20, 30, 30, 30));
        detailsSection.setAlignment(Pos.TOP_LEFT);

        VBox coverContainer = createCoverContainer(previewBook);
        VBox infoBox = createBasicInfoBox(previewBook);

        detailsSection.getChildren().addAll(coverContainer, infoBox);

        ScrollPane contentScroll = new ScrollPane();
        contentScroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        contentScroll.setFitToWidth(true);
        contentScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        contentScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        VBox scrollContent = new VBox();
        scrollContent.getChildren().add(detailsSection);
        contentScroll.setContent(scrollContent);

        previewContent.getChildren().addAll(topBar, contentScroll);
        return previewContent;
    }

    private static VBox createBasicInfoBox(Book book) {
        VBox infoBox = new VBox(8);
        infoBox.setAlignment(Pos.TOP_LEFT);

        infoBox.getChildren().addAll(
                createTitleLabel(book.getTitle()),
                createAuthorLabel(book.getAuthor())
        );

        return infoBox;
    }

    // Navigation methods
    private static void addEdgeDetection(StackPane container) {
        if (booksCollection == null || booksCollection.size() <= 1) {
            return;
        }

        Rectangle leftEdge = createEdgeZone(120, 700);
        Rectangle rightEdge = createEdgeZone(120, 700);

        StackPane.setAlignment(leftEdge, Pos.CENTER_LEFT);
        StackPane.setAlignment(rightEdge, Pos.CENTER_RIGHT);

        setupEdgeEvents(leftEdge, rightEdge);
        container.getChildren().addAll(leftEdge, rightEdge);
    }

    private static Rectangle createEdgeZone(int width, int height) {
        Rectangle edge = new Rectangle(width, height, Color.TRANSPARENT);
        edge.setOpacity(0.01);
        return edge;
    }

    private static void setupEdgeEvents(Rectangle leftEdge, Rectangle rightEdge) {
        Timeline leftHoverDelay = new Timeline();
        Timeline rightHoverDelay = new Timeline();

        // Right edge events
        rightEdge.setOnMouseEntered(e -> {
            if (currentBookIndex < booksCollection.size() - 1 && !isTransitioning) {
                rightHoverDelay.stop();
                rightHoverDelay.getKeyFrames().clear();
                rightHoverDelay.getKeyFrames().add(
                        new KeyFrame(Duration.millis(100), event -> showBookPreview(true, false))
                );
                rightHoverDelay.play();
            }
        });

        rightEdge.setOnMouseExited(e -> {
            rightHoverDelay.stop();
            if (!isTransitioning) {
                Timeline exitDelay = new Timeline(
                        new KeyFrame(Duration.millis(50), event -> showBookPreview(false, false))
                );
                exitDelay.play();
            }
        });

        rightEdge.setOnMouseClicked(e -> {
            rightHoverDelay.stop();
            if (currentBookIndex < booksCollection.size() - 1 && !isTransitioning) {
                slideToBook(currentBookIndex + 1);
            }
        });

        // Left edge events
        leftEdge.setOnMouseEntered(e -> {
            if (currentBookIndex > 0 && !isTransitioning) {
                leftHoverDelay.stop();
                leftHoverDelay.getKeyFrames().clear();
                leftHoverDelay.getKeyFrames().add(
                        new KeyFrame(Duration.millis(100), event -> showBookPreview(true, true))
                );
                leftHoverDelay.play();
            }
        });

        leftEdge.setOnMouseExited(e -> {
            leftHoverDelay.stop();
            if (!isTransitioning) {
                Timeline exitDelay = new Timeline(
                        new KeyFrame(Duration.millis(50), event -> showBookPreview(false, true))
                );
                exitDelay.play();
            }
        });

        leftEdge.setOnMouseClicked(e -> {
            leftHoverDelay.stop();
            if (currentBookIndex > 0 && !isTransitioning) {
                slideToBook(currentBookIndex - 1);
            }
        });
    }

    private static void addNavigationArrows() {
        if (booksCollection == null || booksCollection.size() <= 1) {
            return;
        }

        leftArrowButton = createArrowButton("❮");
        rightArrowButton = createArrowButton("❯");

        StackPane.setAlignment(leftArrowButton, Pos.CENTER_LEFT);
        StackPane.setAlignment(rightArrowButton, Pos.CENTER_RIGHT);
        StackPane.setMargin(leftArrowButton, new Insets(0, 0, 0, 30));
        StackPane.setMargin(rightArrowButton, new Insets(0, 30, 0, 0));

        setupArrowEvents();
        root.getChildren().addAll(leftArrowButton, rightArrowButton);
    }

    private static Button createArrowButton(String text) {
        Button button = new Button(text);
        button.setStyle(
                "-fx-background-color: rgba(0, 0, 0, 0.3);" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 20px;" +
                        "-fx-background-radius: 50%;" +
                        "-fx-min-width: 44px;" +
                        "-fx-min-height: 44px;" +
                        "-fx-max-width: 44px;" +
                        "-fx-max-height: 44px;" +
                        "-fx-padding: 0;" +
                        "-fx-cursor: hand;" +
                        "-fx-opacity: 0;" +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 4, 0, 0, 1);"
        );
        return button;
    }

    private static void setupArrowEvents() {
        // Root hover events for showing/hiding arrows
        root.setOnMouseEntered(e -> {
            Timeline fadeIn = new Timeline(
                    new KeyFrame(Duration.millis(200),
                            new KeyValue(leftArrowButton.opacityProperty(),
                                    currentBookIndex > 0 ? 0.7 : 0, Interpolator.EASE_OUT),
                            new KeyValue(rightArrowButton.opacityProperty(),
                                    currentBookIndex < booksCollection.size() - 1 ? 0.7 : 0, Interpolator.EASE_OUT)
                    )
            );
            fadeIn.play();
        });

        root.setOnMouseExited(e -> {
            Timeline fadeOut = new Timeline(
                    new KeyFrame(Duration.millis(300),
                            new KeyValue(leftArrowButton.opacityProperty(), 0, Interpolator.EASE_OUT),
                            new KeyValue(rightArrowButton.opacityProperty(), 0, Interpolator.EASE_OUT)
                    )
            );
            fadeOut.play();
        });

        // Button hover effects
        setupButtonHoverEffect(leftArrowButton, () -> currentBookIndex > 0);
        setupButtonHoverEffect(rightArrowButton, () -> currentBookIndex < booksCollection.size() - 1);

        // Click handlers
        leftArrowButton.setOnMouseClicked(e -> {
            if (currentBookIndex > 0 && !isTransitioning) {
                slideToBook(currentBookIndex - 1);
            }
        });

        rightArrowButton.setOnMouseClicked(e -> {
            if (currentBookIndex < booksCollection.size() - 1 && !isTransitioning) {
                slideToBook(currentBookIndex + 1);
            }
        });
    }

    private static void setupButtonHoverEffect(Button button, java.util.function.Supplier<Boolean> condition) {
        button.setOnMouseEntered(e -> {
            if (condition.get()) {
                button.setStyle(button.getStyle().replace("0.3", "0.5"));
            }
        });

        button.setOnMouseExited(e -> {
            button.setStyle(button.getStyle().replace("0.5", "0.3"));
        });
    }

    private static void updateArrowVisibility() {
        if (booksCollection == null || booksCollection.size() <= 1) {
            return;
        }

        Timeline updateVisibility = new Timeline();

        updateVisibility.getKeyFrames().addAll(
                new KeyFrame(Duration.millis(150),
                        new KeyValue(leftArrowButton.opacityProperty(),
                                currentBookIndex > 0 ? 0.7 : 0, Interpolator.EASE_OUT)),
                new KeyFrame(Duration.millis(150),
                        new KeyValue(rightArrowButton.opacityProperty(),
                                currentBookIndex < booksCollection.size() - 1 ? 0.7 : 0, Interpolator.EASE_OUT))
        );

        updateVisibility.play();
    }

    private static void showBookPreview(boolean show, boolean isPrevious) {
        if (slideAnimation != null && slideAnimation.getStatus().equals(javafx.animation.Animation.Status.RUNNING)) {
            slideAnimation.stop();
        }

        VBox previewToShow = isPrevious ? prevBookPreview : nextBookPreview;

        if (previewToShow == null || !previewToShow.isVisible()) {
            return;
        }

        double targetX = isPrevious ?
                (show ? -1050 : -1200) :
                (show ? 1050 : 1200);
        double targetOpacity = show ? 0.6 : 0.0;
        double targetScale = show ? 0.95 : 0.9;

        slideAnimation = new Timeline(
                new KeyFrame(Duration.millis(250),
                        new KeyValue(previewToShow.translateXProperty(), targetX, Interpolator.EASE_OUT),
                        new KeyValue(previewToShow.opacityProperty(), targetOpacity, Interpolator.EASE_OUT),
                        new KeyValue(previewToShow.scaleXProperty(), targetScale, Interpolator.EASE_OUT),
                        new KeyValue(previewToShow.scaleYProperty(), targetScale, Interpolator.EASE_OUT)
                )
        );
        slideAnimation.play();
    }

    private static void slideToBook(int newIndex) {
        if (newIndex < 0 || newIndex >= booksCollection.size() || newIndex == currentBookIndex || isTransitioning) {
            return;
        }

        isTransitioning = true;
        Book targetBook = booksCollection.get(newIndex);
        boolean isForward = newIndex > currentBookIndex;

        // Reset ratings for new book
        resetRatings();
        currentBook = targetBook;

        // Create new book content
        VBox newBookContent = createBookContent(targetBook, getBookBackgroundColor(targetBook), currentAuthManager);

        // Set initial animation state
        newBookContent.setTranslateX(isForward ? 1200 : -1200);
        newBookContent.setOpacity(0.0);
        newBookContent.setScaleX(0.95);
        newBookContent.setScaleY(0.95);

        bookDisplayPane.getChildren().add(newBookContent);
        VBox currentContent = (VBox) bookDisplayPane.getChildren().get(1);

        if (slideAnimation != null && slideAnimation.getStatus().equals(javafx.animation.Animation.Status.RUNNING)) {
            slideAnimation.stop();
        }

        // Apple-style smooth transition
        slideAnimation = new Timeline(
                new KeyFrame(Duration.millis(0),
                        new KeyValue(currentContent.opacityProperty(), 1.0),
                        new KeyValue(currentContent.scaleXProperty(), 1.0),
                        new KeyValue(currentContent.scaleYProperty(), 1.0),
                        new KeyValue(currentContent.translateXProperty(), 0),
                        new KeyValue(newBookContent.opacityProperty(), 0.0),
                        new KeyValue(newBookContent.scaleXProperty(), 0.95),
                        new KeyValue(newBookContent.scaleYProperty(), 0.95)
                ),
                new KeyFrame(Duration.millis(200),
                        new KeyValue(currentContent.opacityProperty(), 0.3, Interpolator.EASE_BOTH),
                        new KeyValue(currentContent.scaleXProperty(), 0.95, Interpolator.EASE_BOTH),
                        new KeyValue(currentContent.scaleYProperty(), 0.95, Interpolator.EASE_BOTH),
                        new KeyValue(currentContent.translateXProperty(),
                                isForward ? -200 : 200, Interpolator.EASE_BOTH),
                        new KeyValue(newBookContent.opacityProperty(), 0.7, Interpolator.EASE_BOTH),
                        new KeyValue(newBookContent.scaleXProperty(), 0.98, Interpolator.EASE_BOTH),
                        new KeyValue(newBookContent.scaleYProperty(), 0.98, Interpolator.EASE_BOTH),
                        new KeyValue(newBookContent.translateXProperty(),
                                isForward ? 200 : -200, Interpolator.EASE_BOTH)
                ),
                new KeyFrame(Duration.millis(400),
                        new KeyValue(currentContent.opacityProperty(), 0.0, Interpolator.EASE_OUT),
                        new KeyValue(currentContent.scaleXProperty(), 0.9, Interpolator.EASE_OUT),
                        new KeyValue(currentContent.scaleYProperty(), 0.9, Interpolator.EASE_OUT),
                        new KeyValue(currentContent.translateXProperty(),
                                isForward ? -400 : 400, Interpolator.EASE_OUT),
                        new KeyValue(newBookContent.opacityProperty(), 1.0, Interpolator.EASE_OUT),
                        new KeyValue(newBookContent.scaleXProperty(), 1.0, Interpolator.EASE_OUT),
                        new KeyValue(newBookContent.scaleYProperty(), 1.0, Interpolator.EASE_OUT),
                        new KeyValue(newBookContent.translateXProperty(), 0, Interpolator.EASE_OUT)
                )
        );

        slideAnimation.setOnFinished(e -> {
            currentBookIndex = newIndex;
            bookDisplayPane.getChildren().clear();

            // Reset previews
            prevBookPreview = createBookPreview(currentBookIndex - 1);
            prevBookPreview.setTranslateX(-1200);
            prevBookPreview.setOpacity(0.0);
            prevBookPreview.setScaleX(0.9);
            prevBookPreview.setScaleY(0.9);

            nextBookPreview = createBookPreview(currentBookIndex + 1);
            nextBookPreview.setTranslateX(1200);
            nextBookPreview.setOpacity(0.0);
            nextBookPreview.setScaleX(0.9);
            nextBookPreview.setScaleY(0.9);

            // Reset main content
            newBookContent.setOpacity(1.0);
            newBookContent.setTranslateX(0);
            newBookContent.setScaleX(1.0);
            newBookContent.setScaleY(1.0);

            bookDisplayPane.getChildren().addAll(prevBookPreview, newBookContent, nextBookPreview);

            updateArrowVisibility();
            addEdgeDetection(bookDisplayPane);

            // Load ratings for new book
            loadBookRatingsForAllUsers(targetBook, currentAuthManager);

            isTransitioning = false;
        });

        slideAnimation.play();
    }

    // Utility methods
    private static void resetRatings() {
        currentUserRating = null;
        averageBookRating = null;
        averageRatingLabel = null;
        currentRatingSection = null;
    }

    private static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    private static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }

    // Color extraction methods
    private static Color extractDominantColor(Image image) {
        if (image == null || image.isError()) {
            return Color.rgb(41, 35, 46);
        }

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        if (width <= 0 || height <= 0) {
            return Color.rgb(41, 35, 46);
        }

        int sampleSize = 5;
        Map<Integer, Integer> colorCounts = new HashMap<>();
        PixelReader pixelReader = image.getPixelReader();

        for (int y = 0; y < height; y += sampleSize) {
            for (int x = 0; x < width; x += sampleSize) {
                Color color = pixelReader.getColor(x, y);

                int rgb = ((int) (color.getRed() * 255) << 16) |
                        ((int) (color.getGreen() * 255) << 8) |
                        ((int) (color.getBlue() * 255));

                colorCounts.put(rgb, colorCounts.getOrDefault(rgb, 0) + 1);
            }
        }

        int dominantRGB = 0;
        int maxCount = 0;

        for (Map.Entry<Integer, Integer> entry : colorCounts.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                dominantRGB = entry.getKey();
            }
        }

        int red = (dominantRGB >> 16) & 0xFF;
        int green = (dominantRGB >> 8) & 0xFF;
        int blue = dominantRGB & 0xFF;

        return Color.rgb(red, green, blue);
    }

    private static Color darkenColor(Color color, double factor) {
        return new Color(
                Math.max(0, color.getRed() * factor),
                Math.max(0, color.getGreen() * factor),
                Math.max(0, color.getBlue() * factor),
                color.getOpacity()
        );
    }

    private static String toHexString(Color color) {
        int r = ((int) (color.getRed() * 255)) & 0xFF;
        int g = ((int) (color.getGreen() * 255)) & 0xFF;
        int b = ((int) (color.getBlue() * 255)) & 0xFF;

        return String.format("#%02X%02X%02X", r, g, b);
    }
}