package org.BABO.client.ui;

import org.BABO.client.service.LibraryService;
import org.BABO.shared.model.Book;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Pannello per gestire le librerie personali dell'utente
 * Permette di creare, visualizzare, modificare ed eliminare le librerie
 */
public class LibraryPanel extends VBox {

    private final LibraryService libraryService;
    private final String username;
    private Consumer<Book> onBookClick;
    private Runnable onClosePanel;

    // UI Components
    private VBox librariesContainer;
    private TextField newLibraryField;
    private Button createLibraryButton;
    private Label titleLabel;
    private ScrollPane scrollPane;
    private VBox currentLibraryContent;
    private String currentLibraryName;

    public LibraryPanel(String username) {
        this.libraryService = new LibraryService();
        this.username = username;

        setupUI();
        loadUserLibraries();
    }

    private void setupUI() {
        this.setSpacing(20);
        this.setPadding(new Insets(30));
        this.setAlignment(Pos.TOP_CENTER);
        this.setMaxWidth(900);
        this.setMaxHeight(700);
        this.setStyle(
                "-fx-background-color: #1e1e1e;" +
                        "-fx-background-radius: 15;" +
                        "-fx-border-color: #333;" +
                        "-fx-border-radius: 15;" +
                        "-fx-border-width: 1;"
        );

        // Header con titolo e pulsante chiudi
        HBox header = createHeader();
        this.getChildren().add(header);

        // Sezione creazione nuova libreria
        VBox createSection = createNewLibrarySection();
        this.getChildren().add(createSection);

        // Separatore
        Separator separator = new Separator();
        separator.setStyle("-fx-background-color: #444;");
        this.getChildren().add(separator);

        // Container per le librerie
        librariesContainer = new VBox(15);
        librariesContainer.setAlignment(Pos.TOP_CENTER);

        scrollPane = new ScrollPane(librariesContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setStyle(
                "-fx-background: #1e1e1e;" +
                        "-fx-background-color: transparent;" +
                        "-fx-border-color: transparent;"
        );
        scrollPane.setPrefHeight(400);

        this.getChildren().add(scrollPane);
    }

    private HBox createHeader() {
        HBox header = new HBox();
        header.setAlignment(Pos.CENTER_LEFT);
        header.setSpacing(10);

        titleLabel = new Label("📚 Le Tue Librerie");
        titleLabel.setFont(Font.font("System", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.WHITE);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button closeButton = new Button("✕");
        closeButton.setStyle(
                "-fx-background-color: #e74c3c;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 50;" +
                        "-fx-min-width: 30;" +
                        "-fx-min-height: 30;" +
                        "-fx-max-width: 30;" +
                        "-fx-max-height: 30;"
        );
        closeButton.setOnAction(e -> {
            if (onClosePanel != null) {
                onClosePanel.run();
            }
        });

        header.getChildren().addAll(titleLabel, spacer, closeButton);
        return header;
    }

    private VBox createNewLibrarySection() {
        VBox section = new VBox(10);
        section.setAlignment(Pos.CENTER);

        Label createLabel = new Label("Crea Nuova Libreria");
        createLabel.setFont(Font.font("System", FontWeight.BOLD, 16));
        createLabel.setTextFill(Color.WHITE);

        HBox createBox = new HBox(10);
        createBox.setAlignment(Pos.CENTER);

        newLibraryField = new TextField();
        newLibraryField.setPromptText("Nome della libreria...");
        newLibraryField.setPrefWidth(250);
        newLibraryField.setStyle(
                "-fx-background-color: #333;" +
                        "-fx-text-fill: white;" +
                        "-fx-border-color: #555;" +
                        "-fx-border-radius: 5;" +
                        "-fx-background-radius: 5;"
        );

        createLibraryButton = new Button("Crea Libreria");
        createLibraryButton.setStyle(
                "-fx-background-color: #3498db;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 5;"
        );

        // Enter per creare libreria
        newLibraryField.setOnAction(e -> createNewLibrary());
        createLibraryButton.setOnAction(e -> createNewLibrary());

        createBox.getChildren().addAll(newLibraryField, createLibraryButton);
        section.getChildren().addAll(createLabel, createBox);

        return section;
    }

    private void createNewLibrary() {
        String libraryName = newLibraryField.getText().trim();

        if (libraryName.isEmpty()) {
            showAlert("⚠️ Attenzione", "Inserisci un nome per la libreria");
            return;
        }

        if (libraryName.length() > 50) {
            showAlert("⚠️ Attenzione", "Il nome della libreria è troppo lungo (max 50 caratteri)");
            return;
        }

        createLibraryButton.setDisable(true);
        createLibraryButton.setText("Creazione...");

        libraryService.createLibraryAsync(username, libraryName)
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        createLibraryButton.setDisable(false);
                        createLibraryButton.setText("Crea Libreria");

                        if (response.isSuccess()) {
                            newLibraryField.clear();
                            showAlert("✅ Successo", "Libreria '" + libraryName + "' creata con successo!");
                            loadUserLibraries(); // Ricarica la lista
                        } else {
                            showAlert("❌ Errore", "Errore nella creazione: " + response.getMessage());
                        }
                    });
                })
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        createLibraryButton.setDisable(false);
                        createLibraryButton.setText("Crea Libreria");
                        showAlert("❌ Errore", "Errore di connessione: " + throwable.getMessage());
                    });
                    return null;
                });
    }

    private void loadUserLibraries() {
        librariesContainer.getChildren().clear();

        // Mostra loading
        Label loadingLabel = new Label("📚 Caricamento librerie...");
        loadingLabel.setFont(Font.font("System", FontWeight.NORMAL, 14));
        loadingLabel.setTextFill(Color.LIGHTGRAY);
        librariesContainer.getChildren().add(loadingLabel);

        libraryService.getUserLibrariesAsync(username)
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        librariesContainer.getChildren().clear();

                        if (response.isSuccess() && response.getLibraries() != null) {
                            List<String> libraries = response.getLibraries();

                            if (libraries.isEmpty()) {
                                showEmptyLibrariesMessage();
                            } else {
                                for (String libraryName : libraries) {
                                    VBox libraryCard = createLibraryCard(libraryName);
                                    librariesContainer.getChildren().add(libraryCard);
                                }
                            }
                        } else {
                            showErrorMessage("Errore nel caricamento: " + response.getMessage());
                        }
                    });
                })
                .exceptionally(throwable -> {
                    Platform.runLater(() -> {
                        librariesContainer.getChildren().clear();
                        showErrorMessage("Errore di connessione: " + throwable.getMessage());
                    });
                    return null;
                });
    }

    private VBox createLibraryCard(String libraryName) {
        VBox card = new VBox(10);
        card.setPadding(new Insets(15));
        card.setStyle(
                "-fx-background-color: #2c2c2c;" +
                        "-fx-background-radius: 10;" +
                        "-fx-border-color: #444;" +
                        "-fx-border-radius: 10;" +
                        "-fx-border-width: 1;"
        );

        // Header della card con nome e azioni
        HBox cardHeader = new HBox();
        cardHeader.setAlignment(Pos.CENTER_LEFT);
        cardHeader.setSpacing(10);

        Label nameLabel = new Label("📚 " + libraryName);
        nameLabel.setFont(Font.font("System", FontWeight.BOLD, 16));
        nameLabel.setTextFill(Color.WHITE);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button viewButton = new Button("Visualizza");
        viewButton.setStyle(
                "-fx-background-color: #27ae60;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 5;" +
                        "-fx-font-size: 12;"
        );
        viewButton.setOnAction(e -> viewLibraryBooks(libraryName));

        Button renameButton = new Button("Rinomina");
        renameButton.setStyle(
                "-fx-background-color: #f39c12;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 5;" +
                        "-fx-font-size: 12;"
        );
        renameButton.setOnAction(e -> renameLibrary(libraryName));

        Button deleteButton = new Button("Elimina");
        deleteButton.setStyle(
                "-fx-background-color: #e74c3c;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 5;" +
                        "-fx-font-size: 12;"
        );
        deleteButton.setOnAction(e -> deleteLibrary(libraryName));

        cardHeader.getChildren().addAll(nameLabel, spacer, viewButton, renameButton, deleteButton);

        // Info sulla libreria (numero di libri)
        Label infoLabel = new Label("Caricamento...");
        infoLabel.setFont(Font.font("System", FontWeight.NORMAL, 12));
        infoLabel.setTextFill(Color.LIGHTGRAY);

        // Carica il numero di libri
        libraryService.getBooksInLibraryAsync(username, libraryName)
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        if (response.isSuccess() && response.getBooks() != null) {
                            int bookCount = response.getBooks().size();
                            String text = bookCount == 0 ? "Nessun libro" :
                                    bookCount == 1 ? "1 libro" :
                                            bookCount + " libri";
                            infoLabel.setText("📖 " + text);
                        } else {
                            infoLabel.setText("❌ Errore nel caricamento");
                        }
                    });
                });

        card.getChildren().addAll(cardHeader, infoLabel);
        return card;
    }

    private void viewLibraryBooks(String libraryName) {
        currentLibraryName = libraryName;

        // Nascondi il contenuto principale e mostra i libri della libreria
        scrollPane.setContent(createLibraryBooksView(libraryName));
        titleLabel.setText("📚 Libreria: " + libraryName);
    }

    private VBox createLibraryBooksView(String libraryName) {
        VBox booksView = new VBox(15);
        booksView.setAlignment(Pos.TOP_CENTER);
        booksView.setPadding(new Insets(20));

        // Pulsante per tornare alle librerie
        Button backButton = new Button("← Torna alle Librerie");
        backButton.setStyle(
                "-fx-background-color: #3498db;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 5;" +
                        "-fx-font-weight: bold;"
        );
        backButton.setOnAction(e -> {
            scrollPane.setContent(librariesContainer);
            titleLabel.setText("📚 Le Tue Librerie");
        });

        Label libraryTitle = new Label("Libri in: " + libraryName);
        libraryTitle.setFont(Font.font("System", FontWeight.BOLD, 18));
        libraryTitle.setTextFill(Color.WHITE);

        VBox booksContainer = new VBox(10);
        booksContainer.setAlignment(Pos.TOP_CENTER);

        // Carica i libri
        Label loadingLabel = new Label("📖 Caricamento libri...");
        loadingLabel.setTextFill(Color.LIGHTGRAY);
        booksContainer.getChildren().add(loadingLabel);

        libraryService.getBooksInLibraryAsync(username, libraryName)
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        booksContainer.getChildren().clear();

                        if (response.isSuccess() && response.getBooks() != null) {
                            List<Book> books = response.getBooks();

                            if (books.isEmpty()) {
                                Label emptyLabel = new Label("📭 Questa libreria è vuota");
                                emptyLabel.setFont(Font.font("System", FontWeight.NORMAL, 14));
                                emptyLabel.setTextFill(Color.LIGHTGRAY);
                                booksContainer.getChildren().add(emptyLabel);

                                Label hintLabel = new Label("Aggiungi libri dalle sezioni del catalogo!");
                                hintLabel.setFont(Font.font("System", FontWeight.NORMAL, 12));
                                hintLabel.setTextFill(Color.GRAY);
                                booksContainer.getChildren().add(hintLabel);
                            } else {
                                for (Book book : books) {
                                    HBox bookCard = createBookCard(book, libraryName);
                                    booksContainer.getChildren().add(bookCard);
                                }
                            }
                        } else {
                            Label errorLabel = new Label("❌ Errore nel caricamento: " + response.getMessage());
                            errorLabel.setTextFill(Color.web("#e74c3c"));
                            booksContainer.getChildren().add(errorLabel);
                        }
                    });
                });

        booksView.getChildren().addAll(backButton, libraryTitle, booksContainer);
        return booksView;
    }

    private HBox createBookCard(Book book, String libraryName) {
        HBox card = new HBox(15);
        card.setPadding(new Insets(10));
        card.setAlignment(Pos.CENTER_LEFT);
        card.setStyle(
                "-fx-background-color: #2c2c2c;" +
                        "-fx-background-radius: 8;" +
                        "-fx-border-color: #444;" +
                        "-fx-border-radius: 8;" +
                        "-fx-border-width: 1;"
        );

        // Info del libro
        VBox bookInfo = new VBox(5);
        bookInfo.setAlignment(Pos.CENTER_LEFT);

        Label titleLabel = new Label(book.getTitle());
        titleLabel.setFont(Font.font("System", FontWeight.BOLD, 14));
        titleLabel.setTextFill(Color.WHITE);

        Label authorLabel = new Label("di " + book.getAuthor());
        authorLabel.setFont(Font.font("System", FontWeight.NORMAL, 12));
        authorLabel.setTextFill(Color.LIGHTGRAY);

        if (book.getPublishYear() != null && !book.getPublishYear().isEmpty()) {
            Label yearLabel = new Label("Anno: " + book.getPublishYear());
            yearLabel.setFont(Font.font("System", FontWeight.NORMAL, 10));
            yearLabel.setTextFill(Color.GRAY);
            bookInfo.getChildren().add(yearLabel);
        }

        bookInfo.getChildren().addAll(titleLabel, authorLabel);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Pulsanti azione
        Button viewButton = new Button("Dettagli");
        viewButton.setStyle(
                "-fx-background-color: #3498db;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 5;" +
                        "-fx-font-size: 11;"
        );
        viewButton.setOnAction(e -> {
            if (onBookClick != null) {
                onBookClick.accept(book);
            }
        });

        Button removeButton = new Button("Rimuovi");
        removeButton.setStyle(
                "-fx-background-color: #e74c3c;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 5;" +
                        "-fx-font-size: 11;"
        );
        removeButton.setOnAction(e -> removeBookFromLibrary(book, libraryName));

        VBox buttonsBox = new VBox(5);
        buttonsBox.setAlignment(Pos.CENTER);
        buttonsBox.getChildren().addAll(viewButton, removeButton);

        card.getChildren().addAll(bookInfo, spacer, buttonsBox);
        return card;
    }

    private void removeBookFromLibrary(Book book, String libraryName) {
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Conferma Rimozione");
        confirmAlert.setHeaderText("Rimuovere il libro dalla libreria?");
        confirmAlert.setContentText("Vuoi rimuovere '" + book.getTitle() + "' dalla libreria '" + libraryName + "'?");

        // Styling
        DialogPane dialogPane = confirmAlert.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e1e1e; -fx-text-fill: white;");

        confirmAlert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                libraryService.removeBookFromLibraryAsync(username, libraryName, book.getIsbn())
                        .thenAccept(libResponse -> {
                            Platform.runLater(() -> {
                                if (libResponse.isSuccess()) {
                                    showAlert("✅ Successo", "Libro rimosso dalla libreria");
                                    // Ricarica la vista dei libri
                                    viewLibraryBooks(libraryName);
                                } else {
                                    showAlert("❌ Errore", "Errore nella rimozione: " + libResponse.getMessage());
                                }
                            });
                        });
            }
        });
    }

    private void renameLibrary(String currentName) {
        TextInputDialog dialog = new TextInputDialog(currentName);
        dialog.setTitle("Rinomina Libreria");
        dialog.setHeaderText("Rinomina la libreria '" + currentName + "'");
        dialog.setContentText("Nuovo nome:");

        // Styling
        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e1e1e; -fx-text-fill: white;");

        dialog.showAndWait().ifPresent(newName -> {
            if (!newName.trim().isEmpty() && !newName.equals(currentName)) {
                libraryService.renameLibraryAsync(username, currentName, newName.trim())
                        .thenAccept(response -> {
                            Platform.runLater(() -> {
                                if (response.isSuccess()) {
                                    showAlert("✅ Successo", "Libreria rinominata con successo");
                                    loadUserLibraries(); // Ricarica la lista
                                } else {
                                    showAlert("❌ Errore", "Errore nella rinomina: " + response.getMessage());
                                }
                            });
                        });
            }
        });
    }

    private void deleteLibrary(String libraryName) {
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Conferma Eliminazione");
        confirmAlert.setHeaderText("Eliminare la libreria '" + libraryName + "'?");
        confirmAlert.setContentText("Questa azione non può essere annullata. Tutti i libri nella libreria saranno rimossi.");

        // Styling
        DialogPane dialogPane = confirmAlert.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e1e1e; -fx-text-fill: white;");

        confirmAlert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                libraryService.deleteLibraryAsync(username, libraryName)
                        .thenAccept(libResponse -> {
                            Platform.runLater(() -> {
                                if (libResponse.isSuccess()) {
                                    showAlert("✅ Successo", "Libreria eliminata con successo");
                                    loadUserLibraries(); // Ricarica la lista
                                } else {
                                    showAlert("❌ Errore", "Errore nell'eliminazione: " + libResponse.getMessage());
                                }
                            });
                        });
            }
        });
    }

    private void showEmptyLibrariesMessage() {
        VBox emptyBox = new VBox(10);
        emptyBox.setAlignment(Pos.CENTER);

        Label emptyLabel = new Label("📭 Non hai ancora librerie");
        emptyLabel.setFont(Font.font("System", FontWeight.BOLD, 16));
        emptyLabel.setTextFill(Color.LIGHTGRAY);

        Label hintLabel = new Label("Crea la tua prima libreria per organizzare i tuoi libri!");
        hintLabel.setFont(Font.font("System", FontWeight.NORMAL, 12));
        hintLabel.setTextFill(Color.GRAY);

        emptyBox.getChildren().addAll(emptyLabel, hintLabel);
        librariesContainer.getChildren().add(emptyBox);
    }

    private void showErrorMessage(String message) {
        Label errorLabel = new Label("❌ " + message);
        errorLabel.setFont(Font.font("System", FontWeight.NORMAL, 14));
        errorLabel.setTextFill(Color.web("#e74c3c"));
        librariesContainer.getChildren().add(errorLabel);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);

        // Styling
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e1e1e; -fx-text-fill: white;");

        alert.showAndWait();
    }

    // Setters per i callback
    public void setOnBookClick(Consumer<Book> onBookClick) {
        this.onBookClick = onBookClick;
    }

    public void setOnClosePanel(Runnable onClosePanel) {
        this.onClosePanel = onClosePanel;
    }

    // Metodo pubblico per aggiungere un libro a una libreria (chiamato da altre parti dell'app)
    public void addBookToLibrary(Book book, String libraryName) {
        if (book.getIsbn() == null || book.getIsbn().trim().isEmpty()) {
            showAlert("❌ Errore", "Impossibile aggiungere il libro: ISBN mancante");
            return;
        }

        libraryService.addBookToLibraryAsync(username, libraryName, book.getIsbn())
                .thenAccept(response -> {
                    Platform.runLater(() -> {
                        if (response.isSuccess()) {
                            showAlert("✅ Successo", "Libro aggiunto alla libreria '" + libraryName + "'");
                            // Se stiamo visualizzando quella libreria, ricarica la vista
                            if (libraryName.equals(currentLibraryName)) {
                                viewLibraryBooks(libraryName);
                            }
                        } else {
                            showAlert("❌ Errore", "Errore nell'aggiunta: " + response.getMessage());
                        }
                    });
                });
    }

    // Metodo per ottenere la lista delle librerie dell'utente (per uso esterno)
    public CompletableFuture<List<String>> getUserLibraries() {
        return libraryService.getUserLibrariesAsync(username)
                .thenApply(response -> {
                    if (response.isSuccess() && response.getLibraries() != null) {
                        return response.getLibraries();
                    }
                    return List.of();
                });
    }
}