package com.mycompany.mavenproject1;

// Importazioni necessarie per JavaFX e altre librerie
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.shape.Circle;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javafx.scene.effect.BoxBlur;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

// Classe principale che estende Application per creare un'applicazione JavaFX
public class AppleBooksClone extends Application {

    // Metodo per creare un separatore con un gradiente
    private Region createGradientSeparator() {
        Region separator = new Region();
        separator.setPrefHeight(30); // Altezza del separatore
        separator.setStyle(
            "-fx-background-color: linear-gradient(from 0% 0% to 0% 100%, transparent, #1e1e1e);"
        );
        return separator;
    }

    // Metodo per creare un ImageView sicuro, con gestione degli errori
    public static ImageView createSafeImageView(String isbnFileName, double width, double height) {
        Image image;
        try {
            // Carica l'immagine dalla risorsa
            InputStream stream = AppleBooksClone.class.getResourceAsStream("/books_covers/" + isbnFileName);
            if (stream == null) {
                System.out.println("File non trovato: " + isbnFileName);
            }
            image = new Image(stream, width, height, true, true);
            if (image.isError()) {
                throw new Exception("Errore nel caricamento dell'immagine.");
            }
        } catch (Exception e) {
            // Fallback su un'immagine placeholder in caso di errore
            System.out.println("Errore caricamento immagine da risorsa, fallback su placeholder: " + isbnFileName);
            image = new Image("https://via.placeholder.com/100x150", width, height, true, true);
        }

        return new ImageView(image);
    }

    // Metodo per creare una sezione di libri
    private VBox createBookSection(String sectionTitle, List<Book> books, Consumer<Book> onBookClick) {
        Label title = new Label(sectionTitle); // Titolo della sezione
        title.setFont(Font.font("New York Extra Large", FontWeight.BOLD, 20));
        title.setTextFill(Color.WHITE);

        HBox bookRow = new HBox(10); // Contenitore orizzontale per i libri
        bookRow.setPadding(new Insets(10));

        for (Book book : books) {
            VBox bookBox = new VBox(5); // Contenitore verticale per ogni libro
            bookBox.setAlignment(Pos.CENTER);

            // Creazione della copertina del libro
            ImageView cover = createSafeImageView(book.imageUrl, 100, 150);

            // Aggiunge un evento di click sulla copertina
            cover.setOnMouseClicked(e -> onBookClick.accept(book));

            // Titolo del libro
            Label bookTitle = new Label(book.title);
            bookTitle.setWrapText(true);
            bookTitle.setMaxWidth(100);
            bookTitle.setTextFill(Color.WHITE);

            bookBox.getChildren().addAll(cover, bookTitle); // Aggiunge copertina e titolo
            bookRow.getChildren().add(bookBox); // Aggiunge il libro alla riga
        }

        // ScrollPane per scorrere i libri
        ScrollPane scroll = new ScrollPane(bookRow);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setPannable(true);
        scroll.setFitToHeight(true);
        scroll.setPrefHeight(220);
        scroll.setStyle("-fx-background: #1e1e1e; -fx-border-color: transparent;");

        VBox section = new VBox(5, title, scroll); // Contenitore verticale per la sezione
        section.setPadding(new Insets(10, 20, 10, 20));
        return section;
    }

    // Metodo per creare una sezione di categorie
    private VBox createCategorySection(String sectionTitle, List<Category> categories) {
        Label title = new Label(sectionTitle); // Titolo della sezione
        title.setFont(Font.font("New York Extra Large", FontWeight.BOLD, 20));
        title.setTextFill(Color.WHITE);

        HBox categoryRow = new HBox(20); // Contenitore orizzontale per le categorie
        categoryRow.setPadding(new Insets(10));
        categoryRow.setAlignment(Pos.CENTER_LEFT);

        for (Category category : categories) {
            // Creazione dell'immagine della categoria
            Image image = new Image(category.getImageUrl(), 290, 155, false, true);
            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(290);
            imageView.setFitHeight(155);
            imageView.setPreserveRatio(false);
            imageView.setSmooth(true);
            imageView.setStyle("-fx-background-radius: 8; -fx-border-radius: 8;");

            // Aggiunge un clip con angoli arrotondati
            Rectangle clip = new Rectangle(290, 155);
            clip.setArcWidth(16);
            clip.setArcHeight(16);
            imageView.setClip(clip);

            // Contenitore per la card della categoria
            StackPane card = new StackPane(imageView);
            card.setPrefSize(290, 155);
            card.setMaxSize(290, 155);
            card.setStyle(
                "-fx-background-radius: 8;" +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 8, 0.3, 0, 3);"
            );

            categoryRow.getChildren().add(card); // Aggiunge la card alla riga
        }

        // ScrollPane per scorrere le categorie
        ScrollPane scroll = new ScrollPane(categoryRow);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setPannable(true);
        scroll.setFitToHeight(true);
        scroll.setPrefHeight(220);
        scroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        VBox section = new VBox(10, title, scroll); // Contenitore verticale per la sezione
        section.setPadding(new Insets(20));
        section.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #2c2c2c, #1e1e1e);" +
            "-fx-background-radius: 10;"
        );

        return section;
    }

    // Metodo per recuperare i libri dal database
    private List<Book> fetchBooksFromDB() {
        List<Book> books = new ArrayList<>();
        String url = "jdbc:postgresql://localhost:5432/DataProva"; // URL del database
        String user = "postgres"; // Utente del database
        String password = "postgress"; // Password del database

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String query = "SELECT \"isbn\", \"book_author\", \"description\" FROM books";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {

                while (rs.next()) {
                    String title = rs.getString("isbn");
                    String author = rs.getString("book_author");
                    String description = rs.getString("description");

                    // Costruisce il nome del file immagine
                    String fileName = title.replaceAll("[^a-zA-Z0-9]", "") + ".jpg";

                    books.add(new Book(title, author, description, fileName));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return books;
    }

    // Metodo principale per avviare l'applicazione
    @Override
    public void start(Stage stage) {
        // Carica i font personalizzati
        Font.loadFont(getClass().getResource("/fonts/NewYorkExtraLarge-Heavy.otf").toExternalForm(), 14);
        Font.loadFont(getClass().getResource("/fonts/NewYorkLarge-Medium.otf").toExternalForm(), 14);

        BorderPane root = new BorderPane(); // Layout principale

        // === SIDEBAR ===
        VBox sidebar = new VBox(10); // Barra laterale
        sidebar.setPadding(new Insets(15));
        sidebar.setStyle("-fx-background-color: #2c2c2e;");
        sidebar.setPrefWidth(180);
        sidebar.setPrefHeight(700);

        VBox menuItemsBox = new VBox(10); // Contenitore per i menu
        String[] menuItems = {"Home", "Book Store", "Audiobook Store", "Tutto", "Da leggere", "Letti", "PDF"};
        for (String item : menuItems) {
            Label label = new Label(item);
            label.setTextFill(Color.WHITE);
            menuItemsBox.getChildren().add(label);
        }
        menuItemsBox.setAlignment(Pos.TOP_LEFT);

        // Avatar dell'utente
        Image avatarImage = new Image(getClass().getResource("/logReg/white_logo.png").toExternalForm());
        ImageView avatar = new ImageView(avatarImage);
        avatar.setFitWidth(40);
        avatar.setFitHeight(40);
        avatar.setStyle("-fx-cursor: hand;");
        Circle clip = new Circle(20, 20, 20);
        avatar.setClip(clip);

        StackPane avatarPane = new StackPane(avatar);
        avatarPane.setPadding(new Insets(10));
        avatarPane.setAlignment(Pos.CENTER_LEFT);

        Region spacer = new Region(); // Spaziatore per allineare gli elementi
        VBox.setVgrow(spacer, Priority.ALWAYS);

        sidebar.getChildren().addAll(menuItemsBox, spacer, avatarPane);
        root.setLeft(sidebar);

        // === HEADER ===
        Label header = new Label("Book Recommender"); // Intestazione
        header.setFont(Font.font("New York Extra Large", FontWeight.BOLD, 28));
        header.setTextFill(Color.WHITE);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setMaxWidth(Double.MAX_VALUE);
        header.setStyle(
            "-fx-padding: 20 30 20 30;" +
            "-fx-background-color: #1e1e1e;" +
            "-fx-border-color: transparent;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.4), 5, 0.0, 0, 2);" +
            "-fx-font-smoothing-type: lcd;"
        );

        // === CONTENUTO CENTRALE ===
        VBox content = new VBox(20); // Contenitore per il contenuto principale
        content.setStyle("-fx-background-color: #1e1e1e;");

        List<Book> books = fetchBooksFromDB(); // Recupera i libri dal database
        int splitIndex = Math.min(8, books.size()); // Divide i libri in due sezioni

        List<Category> categories = List.of( // Categorie predefinite
            new Category("Thriller", "/categories/Thriller_Gialli.jpg", getClass().getResource("/categories/Thriller_Gialli.jpg").toExternalForm()),
            new Category("Romance", "/categories/Romanzi_Rosa.jpg", getClass().getResource("/categories/Romanzi_Rosa.jpg").toExternalForm()),
            new Category("Horror", "/categories/Narrativa_Letteratura.jpg", getClass().getResource("/categories/Narrativa_Letteratura.jpg").toExternalForm()),
            new Category("Sci-Fi", "/categories/Saggistica.jpg", getClass().getResource("/categories/Saggistica.jpg").toExternalForm()),
            new Category("Fantasy", "/categories/Fantascienza_Fantasy.jpg", getClass().getResource("/categories/Fantascienza_Fantasy.jpg").toExternalForm())
        );

        // === OVERLAY PANNELLO DETTAGLI LIBRO ===
        StackPane mainStack = new StackPane(); // Contenitore principale con overlay
        VBox centerBox = new VBox(header, new ScrollPane(content));
        mainStack.getChildren().add(centerBox); // Livello base

        Consumer<Book> clickHandler = selectedBook -> { // Gestore del click sui libri
            BoxBlur blur = new BoxBlur(30, 30, 5);
            centerBox.setEffect(blur);

            StackPane overlay = new StackPane();
            overlay.setStyle("-fx-background-color: rgba(0,0,0,0.25);");
            overlay.setPickOnBounds(true);
            overlay.setPrefSize(Double.MAX_VALUE, Double.MAX_VALUE);

            // Trucchetto per usare la variabile nella lambda
            final StackPane[] detailsPaneRef = new StackPane[1];

            detailsPaneRef[0] = BookDetailsPopup.create(selectedBook, () -> {
                mainStack.getChildren().removeAll(overlay, detailsPaneRef[0]);
                centerBox.setEffect(null);
            });

            overlay.setOnMouseClicked(e -> {
                if (!detailsPaneRef[0].getBoundsInParent().contains(e.getX(), e.getY())) {
                    mainStack.getChildren().removeAll(overlay, detailsPaneRef[0]);
                    centerBox.setEffect(null);
                }
            });

            overlay.getChildren().add(detailsPaneRef[0]);
            StackPane.setAlignment(detailsPaneRef[0], Pos.CENTER);
            mainStack.getChildren().add(overlay);
        };

        // Aggiunge sezioni al contenuto
        content.getChildren().addAll(
            createGradientSeparator(),
            createBookSection("Libri gratuiti", books.subList(0, splitIndex), clickHandler),
            createGradientSeparator(),
            createBookSection("Nuove uscite", books.subList(splitIndex, books.size()), clickHandler),
            createGradientSeparator(),
            createCategorySection("Scopri per genere", categories)
        );

        ScrollPane scrollPane = new ScrollPane(content); // ScrollPane per il contenuto
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setFitToWidth(true);
        centerBox.getChildren().set(1, scrollPane);
        root.setCenter(mainStack);

        // === ACCOUNT POPUP ===
        Stage accountStage = new Stage(); // Finestra per l'account
        accountStage.initStyle(StageStyle.DECORATED);
        accountStage.initModality(Modality.NONE);
        accountStage.setTitle("Account");
        accountStage.setMinWidth(320);
        accountStage.setMinHeight(280);

        AccountPanel accountPanel = new AccountPanel(); // Pannello dell'account
        Scene accountScene = new Scene(accountPanel, 320, 280);
        accountStage.setScene(accountScene);

        avatar.setOnMouseClicked(e -> { // Mostra/nasconde la finestra dell'account
            if (accountStage.isShowing()) {
                accountStage.hide();
            } else {
                accountStage.show();
            }
        });

        // Configura la scena principale
        Scene scene = new Scene(root, 1000, 700);
        scene.getStylesheets().add(getClass().getResource("/css/scrollbar.css").toExternalForm());

        stage.setScene(scene);
        stage.setTitle("Apple Books Clone");
        stage.show();
    }

    // Metodo main per avviare l'applicazione
    public static void main(String[] args) {
        launch(args);
    }
}