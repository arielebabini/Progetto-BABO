package com.mycompany.mavenproject1;

import java.io.InputStream;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.effect.BoxBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

// Classe che rappresenta un popup per mostrare i dettagli di un libro
public class BookDetailsPopup {

    // Metodo per creare il popup con i dettagli del libro
    public static StackPane create(Book book, Runnable onClose) {
        // Estrae il colore dominante dall'immagine del libro
        Color dominantColor = DominantColorExtractor.extractDominantColor(book.imageUrl);

        // --- COVER ---
        // Crea un'immagine sicura per la copertina del libro
        ImageView cover = createSafeImageView(book.imageUrl, 140, 210);
        VBox coverBox = new VBox(cover); // Contenitore per la copertina
        coverBox.setAlignment(Pos.CENTER); // Allineamento al centro
        coverBox.setPadding(new Insets(30)); // Margini interni

        // --- TITLE, AUTHOR & BUTTONS ---
        // Etichetta per il titolo del libro
        Label title = new Label(book.getTitle());
        title.setFont(Font.font("New York Large", FontWeight.BOLD, 26)); // Font e dimensione
        title.setTextFill(Color.WHITE); // Colore del testo

        // Etichetta per l'autore del libro
        Label author = new Label(book.getAuthor());
        author.setFont(Font.font("New York Large", FontWeight.NORMAL, 18)); // Font e dimensione
        author.setTextFill(Color.LIGHTGRAY); // Colore del testo

        // Pulsanti per ottenere il libro e visualizzare un estratto
        Button getButton = new Button("Ottieni");
        Button previewButton = new Button("Estratto");
        getButton.setStyle("-fx-background-color: white; -fx-text-fill: black; -fx-font-weight: bold; -fx-background-radius: 8;");
        previewButton.setStyle("-fx-background-color: #3b2e58; -fx-text-fill: white; -fx-background-radius: 8;");
        HBox buttonBox = new HBox(10, getButton, previewButton); // Contenitore orizzontale per i pulsanti
        buttonBox.setAlignment(Pos.CENTER_LEFT); // Allineamento a sinistra
        buttonBox.setPadding(new Insets(10, 0, 0, 0)); // Margini interni

        // Contenitore verticale per titolo, autore e pulsanti
        VBox infoBox = new VBox(title, author, buttonBox);
        infoBox.setSpacing(10); // Spaziatura tra gli elementi
        infoBox.setPadding(new Insets(30)); // Margini interni
        infoBox.setAlignment(Pos.TOP_LEFT); // Allineamento in alto a sinistra

        // Contenitore orizzontale per copertina e informazioni
        HBox topContent = new HBox(coverBox, infoBox);
        topContent.setBackground(new Background(new BackgroundFill(dominantColor, new CornerRadii(20, 20, 0, 0, false), Insets.EMPTY)));

        // --- DESCRIPTION (BOTTOM) ---
        // Testo per la descrizione del libro
        Text description = new Text(book.getDescription());
        description.setWrappingWidth(740); // Larghezza massima del testo
        description.setFill(Color.WHITE); // Colore del testo
        description.setFont(Font.font("New York", 14)); // Font e dimensione

        // ScrollPane per la descrizione
        ScrollPane descriptionPane = new ScrollPane(description);
        descriptionPane.setFitToWidth(true); // Adatta alla larghezza
        descriptionPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        descriptionPane.setMaxHeight(200); // Altezza massima
        descriptionPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED); // Barra di scorrimento verticale

        // Contenitore per la descrizione
        VBox bottomContent = new VBox(descriptionPane);
        bottomContent.setBackground(new Background(new BackgroundFill(Color.web("#1e1e1e"), new CornerRadii(0, 0, 20, 20, false), Insets.EMPTY)));
        bottomContent.setPadding(new Insets(20)); // Margini interni

        // Contenitore principale del popup
        VBox popupContent = new VBox(topContent, bottomContent);
        popupContent.setMaxWidth(800); // Larghezza massima
        popupContent.setEffect(new javafx.scene.effect.DropShadow(20, Color.BLACK)); // Effetto ombra

        // --- LAYER CON SFOCATURA CLICCABILE ---
        // Layer sfocato per chiudere il popup
        StackPane blurLayer = new StackPane();
        blurLayer.setStyle("-fx-background-color: rgba(0, 0, 0, 0.6);"); // Sfondo trasparente
        blurLayer.setEffect(new BoxBlur(20, 20, 3)); // Effetto sfocatura
        blurLayer.setOnMouseClicked((MouseEvent e) -> {
            onClose.run(); // Chiama il callback di chiusura
        });

        // --- ROOT CON CENTRATURA ---
        // Contenitore principale con centratura
        StackPane root = new StackPane(blurLayer, popupContent);
        StackPane.setAlignment(popupContent, Pos.CENTER); // Allineamento al centro
        root.setPadding(new Insets(50)); // Margini interni

        return root; // Ritorna il contenitore principale
    }

    // Metodo per creare un'immagine sicura con gestione degli errori
    public static ImageView createSafeImageView(String isbnFileName, double width, double height) {
        Image image;
        try {
            // Carica l'immagine dal percorso specificato
            InputStream stream = AppleBooksClone.class.getResourceAsStream("/books_covers/" + isbnFileName);
            if (stream == null) {
                System.out.println("File non trovato: " + isbnFileName); // Messaggio di errore
            }
            image = new Image(stream, width, height, true, true); // Crea l'immagine
            if (image.isError()) throw new Exception("Errore immagine."); // Gestisce errori di caricamento
        } catch (Exception e) {
            System.out.println("Errore caricamento immagine: fallback."); // Messaggio di fallback
            image = new Image("https://via.placeholder.com/140x210", width, height, true, true); // Immagine di fallback
        }
        return new ImageView(image); // Ritorna l'ImageView
    }
}